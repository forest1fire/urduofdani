# UrduOfDani 0.6.0
Created by Muhammad Danish [Dani] · DaniLabs — free and open-source Urdu publishing

**UrduOfDani — Designed and Developed by Muhammad Danish [Dani].** An Urdu publishing application by DaniLabs.

> UrduOfDani is an independent application, inspired by the Urdu publishing workflow of InPage but not affiliated with, endorsed by, or a product of InPage or its owners. No InPage code, fonts or files are included.
Offline Urdu publishing app. Electron (Chromium: HarfBuzz shaping + Unicode bidi), vanilla JS, no account.

## Run
    npm install
    npm start          # development
    npm test           # format/phonetic/round-trip tests
    npm run dist       # Windows installer (build on Windows)

## Layout
- `main.js` window, file I/O, PDF (printToPDF), autosave/recovery  · `lib/format.js` versioned `.udani` format
- `renderer/` UI + editor · `lib/phonetic.js` keyboard map · `fonts/` Noto Nastaliq Urdu + Naskh (SIL OFL)

## New in 0.6 — your fonts, styles, smarter typing
- **Font Manager** (`Fonts…`, or drag .ttf/.otf/.woff files onto the window). Fonts are copied into the app's data folder, previewed in Urdu, and checked: *does it contain the Urdu letters?* (reads the font's cmap; a Latin-only font is flagged "No Urdu") and *may it be embedded?* (OS/2 `fsType`; fonts whose licence forbids embedding are never put into documents or web pages). A per-document default font, "Windows fonts" list (Chromium `queryLocalFonts`, opt-in click), and a missing-font warning that really detects missing fonts (the old `document.fonts.check` returned "true" for unknown names).
- **Fonts travel with the document.** Saving embeds the installed fonts the text uses into the `.udani` (file version 2; files without fonts stay version 1, so 0.5 can still open them). On a computer without the font the text still looks right; "Install" in the manager makes it permanent. Autosave never embeds (too heavy every 3 s).
- **Paragraph styles** (`Styles…`): named styles (font, size, line height, colour, alignment, bold/italic, spacing) saved in the file. Edit a style and every paragraph using it changes. "From selection" copies the look of the paragraph at the cursor. Style values from files are validated before they reach any stylesheet.
- **Smart Roman-Urdu keyboard** (Alt+K): `sh kh gh ch zh aa oo ee bh ph th jh dh Th Dh Rh chh`, `H` = ھ. Replaces the previous letters in one step. Plus an Urdu / Western digits switch, and a **Marks & symbols** panel: harakat, ﷲ ﷺ ﷽, ؐ ؑ ؒ ؓ ؔ, punctuation.
- **Sher**: select two (or more) lines → each pair becomes a centred couplet; with nothing selected, inserts an empty one. "Poetry (ghazal)" template.
- **Ctrl+K command palette**, **focus mode** (Ctrl+Shift+F / Esc), text and highlight colour, **Recent files**, **double-click a .udani** to open it (declared in the installer since 0.1 but never wired up), single window, **Export HTML** (self-contained, fonts embedded, scripts stripped).
- Fixes: `window.prompt` does not exist in Electron, so *Table* never worked → proper dialog. The Find bar and on-screen keyboard were permanently visible (CSS beat the `hidden` attribute). Line spacing was never saved. *New* inherited the previous document's settings.
- Hardening: dropped files/links can no longer navigate the editor away; renderer stays sandboxed/context-isolated.

### Testing (all run on Linux; the Windows `.exe` itself has not been run on Windows)
`node test/run.js` (format, fonts, font store, styles, keyboard) · `python3 test/ui.py` (73 browser checks of the real renderer, with screenshots) · `python3 test/electron_smoke.py` (the real Electron app: real IPC, font store on disk, save/open/recent, plugins, printToPDF; start the app first with `xvfb-run electron . --no-sandbox --user-data-dir=/tmp/udtest --remote-debugging-port=9333 file.udani`) · `python3 test/bench.py 10 100 500`.
Typing latency on a 500-page document is unchanged (about 2 ms median); cold start of the page rose from ~115 ms to ~160 ms (more scripts, bigger logo).
Known limits: applying/editing a paragraph style or converting to couplets is not in the Ctrl+Z history; fonts are TTF/OTF/WOFF only (no WOFF2/TTC); the PDF footer page numbers are still Western digits.

## Building the Windows program
On Windows: `npm install` then `npm run dist` → `dist/UrduOfDani-Setup-0.6.0.exe` (installer, file association for `.udani`) and `dist/UrduOfDani-Portable-0.6.0.exe` (no install). The same command works on Linux if Wine (with 32-bit support) is installed. Unsigned: Windows SmartScreen will warn until you sign the exe with a code-signing certificate. `.github/workflows/build-windows.yml` builds both on GitHub's Windows runners.

## New in 0.6 (part 2) — text engine, Python plugins, EPUB
- **Text tools…** (also in Ctrl+K): *Roman Urdu → Urdu* (`DaniLabs kamaal hai` → `ڈانی لیبز کمال ہے`; ~250 common words from a dictionary, the rest guessed by spelling rules — proofread; capital T/D/R give ٹ ڈ ڑ), *Imla clean-up* (Arabic ي ك ه → ی ک ہ, word-initial ھ → ہ, a list of unambiguous mistakes such as اسلئے → اس لیے, Urdu punctuation ، ؟ ؛ ۔, spacing, Urdu digits, canonical order of aerab marks with shadda first; letters that depend on meaning such as ہ/ح are never guessed), *Prose / Book* (joins broken lines into paragraphs, closes long sentences with ۔), *Poetry* (two lines → one couplet block, or tab-separated text; a blank line starts a new poem). Output stays in U+0600–U+06FF, so it pastes into Word, InDesign, Photoshop and WhatsApp as normal Unicode.
- **Python plugins…**: drop a `.py` file in the plugins folder (button opens it). Each plugin subclasses `UrduOfDaniPlugin` and follows the template in `plugins/urduofdani_plugin.py` (`name`, `version`, `author`, `description`, `execute(text, context)`). Plugins run in a **separate Python process** with a 15 s limit and a 64 MB output cap; exceptions, `sys.exit`, syntax errors and hangs are contained and the document is left untouched. Needs Python 3 installed on the PC (python.org, free). Plugins are ordinary programs that run with the user's permissions: only use ones you trust. Examples: punctuation fixer, aerab remover, statistics, and an optional Urdu Hack normaliser (`pip install urduhack` — untested here, needs the library).
- **Export EPUB** (EPUB 3, right-to-left, fonts and images embedded, a chapter per top-level heading). Structure is checked by `test/epub_check.py`; it has not been through the official epubcheck tool or real readers yet.
- Fonts: built-in guidance for adding Jameel Noori Nastaleeq / Mehr Nastaleeq (you supply the file; their licences are not checked by us) and a taller default line spacing for those fonts.
- Credits now read **Muhammad Danish [Dani] · DaniLabs** everywhere (splash, About, installer metadata, README).

### Ideas from the tech list, and what was done
Bundled Noto Nastaliq ✔ already · phonetic layout ✔ (own mapping; the exact CRULP / InPage layout tables are not included — send the tables and they can be added as selectable layouts) · Urdu Hack ✔ as an optional plugin · EPUB ✔ native · spell-check ✔ engine built (you supply the word list: none is bundled) · cloud sync ✘ needs your own Supabase/Firebase project and keys, and conflicts with the "no account, fully offline" design (today: save `.udani` in a OneDrive/Google Drive/Dropbox folder) · ReportLab/WeasyPrint ✘ not needed: PDF export uses Chromium's text shaping, which already renders Nastaliq correctly · Flet/Flutter UI ✘ would mean rewriting the whole tested app.

## New in 0.6 (part 3) — your own keyboard layouts, spell-check
- **Layouts…**: keyboard layouts are small `.json` files in the app's `layouts` folder (button opens it; an editable example is created). `{"name": "...", "map": {"a": "ا", "A": "آ"}}` — each key is the character the keyboard types, each value 1–8 characters of Arabic-script text. Files are validated (size, shape, allowed characters) and listed in the Keyboard menu. The exact CRULP/InPage layout tables are **not** included; if you have a table you may use, it can be turned into a layout file.
- **Spell-check** (button): underlines unknown words with a wavy line, right-click gives up to 5 suggestions (one edit away), "add to my dictionary", "ignore". **No word list is bundled** — put UTF-8 `.txt` files (one word per line) in the `dictionary` folder (button offers to open it); use a list whose licence allows it. Marks and Arabic-form letters are ignored when matching. Disabled live checking above 300k characters. Words you add are saved to `user-words.txt`.

## Done (v0.1)
RTL/mixed editing, Nastaliq/Naskh + fallback, font/size/styles/alignment/line spacing/direction, page size/margins/columns/landscape,
zoom (Ctrl+wheel), page count + thumbnails, tables, images, page breaks, find/replace, light/dark, templates, `.udani` save/open (atomic write),
autosave every 3 s + crash recovery, TXT import/export (UTF-8), PDF export, phonetic keyboard (Alt+K), on-screen keyboard, live key→paint readout.

## New in 0.2
PDF header/footer text and page numbers ("n / total"), Preview button (renders the real PDF export in a window), Replace All is now undoable, per-document page-number toggle.

## New in 0.3 — speed
- Big documents (single column, >150k chars) use CSS `content-visibility` so Chromium skips rendering off-screen paragraphs; page count shows `~` while estimated (calibrated from real paragraph heights).
- Layout, word count and autosave run on idle after typing pauses; word count no longer forces a layout; autosave/save writes are async (don't block the UI).
- Splash closes as soon as fonts are ready (no fixed delay).
- `python3 test/bench.py 10 100 500` (needs `pip install playwright && playwright install chromium`) benchmarks the real renderer.

### Measured (headless Chromium, software rendering, sandbox — NOT the reference PC; use for before/after only)
| Doc | Open+first layout before → after | Typing median / p95 before → after |
|---|---|---|
| 10 pages | 62 ms → 66 ms | 1.6 / 2.3 ms → 1.6 / 8 ms |
| 100 pages | 570 ms → 31 ms | 5.1 / 16.7 ms → 3.7 / 13.6 ms |
| 500 pages | 2600 ms → 150 ms | 23.7 / 30.8 ms → 12.7 / 28.5 ms |
Cold start of the page (no Electron) ≈ 160–210 ms. Remaining bottleneck: typing p95 at 500 pages is still above one 60 Hz frame (16.7 ms). PDF export time is not measured yet (needs real Electron on Windows).

## New in 0.4 — typing speed on huge documents
Profiling showed typing cost grew with the number of sibling paragraphs (1.6 ms at 10 pages, ~14–17 ms at 500). When a big document is opened, paragraphs are now grouped in `<section class="chunk">` blocks of 25 (each a layout/paint boundary). Wrappers are stripped on save/autosave, so `.udani` files are unchanged and round-trip byte-identical (checked). Grouping happens at open time only (not mid-session) to keep undo intact.

| 500 pages (headless Chromium, sandbox) | v0.2 | v0.3 | v0.4 |
|---|---|---|---|
| Open + first layout | 2600 ms | 150 ms | ~60 ms |
| Typing median / p95 | 23.7 / 30.8 ms | 12.7 / 28.5 ms | **1.7 / 3.1 ms** |
Checked: Backspace/Enter/typing/undo across chunk boundaries, no errors. Not yet measured: real Electron on a Windows reference PC, PDF export time, 500 pages with multiple columns (no chunking there), a doc that grows past the size threshold by typing/pasting (stays unchunked until reopened).

## New in 0.5 — PDF correctness + speed (found by measuring)
Benchmarking the PDF path (`python3 test/pdfbench.py 10 100 500`, same Chromium print engine) exposed real bugs from v0.2–0.4, now fixed:
1. Print layout had a shrink-to-fit width, so Chromium **scaled text down** in PDFs → fixed (fixed print width, no forced screen min-heights).
2. A CSS `@page{margin:0}` **overrode the 20 mm margins**, so text ran edge to edge and the header/footer overlapped content → page size and margins now come from one CSS `@page` rule (`preferCSSPageSize`).
3. On-screen page count ignored margins and under-counted; it now uses printable page height (typically within ~8% of the real PDF: 12/116/580 vs 13/125/625 pages for the 10/100/500 test docs; PDF breaks between lines so it needs slightly more pages). Page guides are approximate.

PDF export time (headless Chromium, sandbox; real Electron/Windows not measured): 10 pages 0.28 s · 100 pages (125 pdf pages) 1.7 s · 500 pages (625 pdf pages) 12.3 s, 1.5 MB. Footer "n / total" and Urdu text verified present via pdftotext; left text edge sits inside the 20 mm margin.
Remaining bottleneck: ~20 ms/page for 500+ pages (layout + shaping, single-threaded in Chromium).

## Not finished (labelled honestly)
- Pages are one continuous flow with page guides; text can cross a guide line on screen. PDF/print paginate correctly.
- Text frames, linked frames, character styles, not built (paragraph styles exist since 0.6).
- Traditional (InPage-style) keyboard layout: not built; use the Windows Urdu keyboard. 
- Virtualized rendering for 500-page docs is not built; measure before trusting large files.
- Performance targets (reference PC, to be measured): cold start ≤ 2 s, key→paint ≤ 16 ms, open 100 pages ≤ 1 s, PDF 100 pages ≤ 10 s.
- Legacy InPage `.inp`: no import. Migrate by exporting Unicode text from InPage, then Save As `.udani`; originals are never modified.

## Branding & credits
Name: UrduOfDani. Splash, About, footer, icon (`build/icon.*`), and installer (`UrduOfDani-Setup-<version>.exe`, publisher DaniLabs) carry the credit. To use a full name instead of "Dani": `node scripts/set-creator.js "Full Name"`.
Third-party licenses (Noto fonts under SIL OFL 1.1, Electron/Chromium) are in `THIRD_PARTY_NOTICES.md` and `fonts/OFL-*.txt` and are shipped with the installer.
This project has no open-source license chosen yet; add a `LICENSE` file for how you want others to use it.
