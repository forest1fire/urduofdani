# Third-party notices — UrduOfDani

UrduOfDani is designed and developed by Muhammad Danish [Dani] (DaniLabs). It includes or depends on the following third-party software. Their licenses apply to those components only.

## Noto Nastaliq Urdu and Noto Naskh Arabic (fonts)
Copyright 2022 The Noto Project Authors (https://github.com/notofonts/nastaliq, https://github.com/notofonts/arabic).
Licensed under the SIL Open Font License, Version 1.1. Full text: `fonts/OFL-NotoNastaliqUrdu.txt` and `fonts/OFL-NotoNaskhArabic.txt`.
The fonts are redistributed unmodified and are not sold by themselves.

## Electron (runtime)
Copyright (c) Electron contributors; Copyright (c) 2013-2020 GitHub Inc. Licensed under the MIT License.

## Chromium and its dependencies (bundled inside Electron)
Chromium is licensed under BSD-style and other open-source licenses. Packaged builds include `LICENSE.electron.txt` and `LICENSES.chromium.html`; keep them in the installed app folder.

## Build tooling (development only, not shipped)
electron-builder (MIT).

## Independence notice
UrduOfDani is an independent application. It is inspired by the Urdu publishing workflow of InPage but is not affiliated with, endorsed by, or a product of InPage or its owners. "InPage" is referenced only to describe that inspiration. No InPage code, fonts, or files are included.
