const { app, BrowserWindow, ipcMain, dialog, session, shell } = require('electron');
const fs = require('fs'); const path = require('path'); const os = require('os');
const F = require('./lib/format'); const LY = require('./lib/layouts'); const PH = require('./renderer/phonetic'); const EPUB = require('./lib/epub'); const PL = require('./lib/plugins'); const PDF = require('./lib/pdf'); const FS = require('./lib/fontstore');
let win, pendingOpen = null;
const ud = (...a) => path.join(app.getPath('userData'), ...a);
const rec = () => ud('recovery.udani');
const plugins = () => (plugins.p = plugins.p || PL.create(ud('plugins'), path.join(__dirname, 'plugins')));
const fonts = () => (fonts.s = fonts.s || FS.create(ud('fonts')));

// ---- single instance + "open with" (double-click a .udani in Explorer) ----
const fileFromArgv = argv => argv.slice(app.isPackaged ? 1 : 2).find(a => /\.udani$/i.test(a) && fs.existsSync(a));
if (!app.requestSingleInstanceLock()) app.quit();
app.on('second-instance', (_e, argv) => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } const f = fileFromArgv(argv); if (f) sendOpen(f); });
app.on('open-file', (e, p) => { e.preventDefault(); if (win && win.webContents && !win.webContents.isLoading()) sendOpen(p); else pendingOpen = p; }); // macOS
pendingOpen = fileFromArgv(process.argv);

// ---- recent files ----
const recentFile = () => ud('recent.json');
const getRecent = () => { try { return JSON.parse(fs.readFileSync(recentFile(), 'utf8')).filter(p => fs.existsSync(p)); } catch { return []; } };
function addRecent(p) { if (!p) return; const r = [p, ...getRecent().filter(x => x !== p)].slice(0, 10); try { fs.writeFileSync(recentFile(), JSON.stringify(r)); } catch {} }
function readDoc(p) { const t = fs.readFileSync(p, 'utf8'); return { path: p, doc: F.parse(t) }; }
function sendOpen(p) { try { const r = readDoc(p); addRecent(p); win.webContents.send('open-doc', r); } catch (e) { dialog.showErrorBox('Cannot open', e.message); } }

function create() {
  win = new BrowserWindow({ width: 1280, height: 820, show: false, backgroundColor: '#1b1d23', title: 'UrduOfDani', icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, spellcheck: false } });
  win.setMenuBarVisibility(false);
  win.webContents.on('will-navigate', e => e.preventDefault()); win.webContents.setWindowOpenHandler(() => ({ action: 'deny' })); // a dropped file or a link must never replace the editor
  win.loadFile('renderer/index.html');
  win.once('ready-to-show', () => win.show());
}
app.setName('UrduOfDani'); app.setAboutPanelOptions({ applicationName: 'UrduOfDani', copyright: 'Designed and Developed by Muhammad Danish [Dani] · DaniLabs — free and open-source' });
app.whenReady().then(() => {
  // lets the font picker list the fonts installed in Windows (window.queryLocalFonts); nothing else is ever allowed
  session.defaultSession.setPermissionRequestHandler((_wc, perm, cb) => cb(perm === 'local-fonts'));
  session.defaultSession.setPermissionCheckHandler((_wc, perm) => perm === 'local-fonts');
  create();
});
app.on('window-all-closed', () => app.quit());

const filt = [{ name: 'UrduOfDani', extensions: ['udani'] }];
ipcMain.handle('startup-file', () => { const p = pendingOpen; pendingOpen = null; if (!p) return null; try { const r = readDoc(p); addRecent(p); return r; } catch (e) { dialog.showErrorBox('Cannot open', e.message); return null; } });
ipcMain.handle('open', async () => {
  const r = await dialog.showOpenDialog(win, { filters: [...filt, { name: 'Text', extensions: ['txt'] }], properties: ['openFile'] });
  if (r.canceled) return null; const p = r.filePaths[0]; const t = fs.readFileSync(p, 'utf8');
  try { if (p.endsWith('.txt')) return { path: null, doc: { html: F.textToHtml(t), page: F.defaults() }, imported: p }; addRecent(p); return { path: p, doc: F.parse(t) }; }
  catch (e) { dialog.showErrorBox('Cannot open', e.message); return null; }
});
ipcMain.handle('open-path', async (_e, p) => { if (!getRecent().includes(p)) return null; try { addRecent(p); return readDoc(p); } catch (e) { dialog.showErrorBox('Cannot open', e.message); return null; } });
ipcMain.handle('recent', () => getRecent());
ipcMain.handle('save', async (_e, { path: p, doc, as }) => {
  if (!p || as) { const r = await dialog.showSaveDialog(win, { filters: filt, defaultPath: 'Untitled.udani' }); if (r.canceled) return null; p = r.filePath; }
  const tmp = p + '.tmp'; await fs.promises.writeFile(tmp, F.serialize(doc)); await fs.promises.rename(tmp, p); // atomic, non-blocking write
  try { fs.unlinkSync(rec()); } catch {} addRecent(p); return p;
});
ipcMain.handle('export-txt', async (_e, text) => {
  const r = await dialog.showSaveDialog(win, { filters: [{ name: 'Text', extensions: ['txt'] }], defaultPath: 'Untitled.txt' });
  if (r.canceled) return null; fs.writeFileSync(r.filePath, '﻿' + text, 'utf8'); return r.filePath;
});
ipcMain.handle('export-html', async (_e, html) => {
  const r = await dialog.showSaveDialog(win, { filters: [{ name: 'Web page', extensions: ['html'] }], defaultPath: 'Untitled.html' });
  if (r.canceled) return null; await fs.promises.writeFile(r.filePath, html, 'utf8'); return r.filePath;
});
ipcMain.handle('export-epub', async (_e, o) => {
  const r = await dialog.showSaveDialog(win, { filters: [{ name: 'EPUB e-book', extensions: ['epub'] }], defaultPath: (String(o.title || 'Untitled').replace(/[\\/:*?"<>|]/g, '_')) + '.epub' });
  if (r.canceled) return null; await fs.promises.writeFile(r.filePath, EPUB.build(o)); return r.filePath;
});
async function makePdf(o) {
  const t = PDF.templates(o);
  await win.webContents.executeJavaScript("document.body.classList.add('pdfexport')");
  try {
    return await win.webContents.printToPDF({ pageSize: o.size, landscape: !!o.landscape, printBackground: true, preferCSSPageSize: true, // page size AND margins come from the CSS @page rule (a CSS @page margin overrides API margins)
      displayHeaderFooter: t.display, headerTemplate: t.headerTemplate, footerTemplate: t.footerTemplate, });
  } finally { await win.webContents.executeJavaScript("document.body.classList.remove('pdfexport')"); }
}
ipcMain.handle('export-pdf', async (_e, o) => {
  const r = await dialog.showSaveDialog(win, { filters: [{ name: 'PDF', extensions: ['pdf'] }], defaultPath: 'Untitled.pdf' });
  if (r.canceled) return null; fs.writeFileSync(r.filePath, await makePdf(o)); return r.filePath;
});
ipcMain.handle('preview-pdf', async (_e, o) => { // renders the real export to a temp file and shows it (what you see = what you export)
  const p = path.join(os.tmpdir(), 'urduofdani-preview-' + process.pid + '.pdf'); fs.writeFileSync(p, await makePdf(o));
  const w = new BrowserWindow({ width: 900, height: 900, title: 'UrduOfDani — Print preview', icon: path.join(__dirname, 'build', 'icon.png'), webPreferences: { plugins: true, sandbox: true } });
  w.setMenuBarVisibility(false); w.loadURL(require('url').pathToFileURL(p).href); w.on('closed', () => { try { fs.unlinkSync(p); } catch {} }); return true;
});
ipcMain.handle('autosave', async (_e, doc) => { await fs.promises.writeFile(rec(), F.serialize(doc)); return true; });
ipcMain.handle('recovery', () => { try { return F.parse(fs.readFileSync(rec(), 'utf8')); } catch { return null; } });
ipcMain.handle('clear-recovery', () => { try { fs.unlinkSync(rec()); } catch {} });
ipcMain.handle('print', () => win.webContents.print({ printBackground: true }));

// ---- fonts ----
ipcMain.handle('font-list', () => fonts().list());
ipcMain.handle('font-data', async (_e, id) => new Uint8Array(await fonts().read(id)));
ipcMain.handle('font-add-bytes', async (_e, { name, bytes }) => { try { return { ok: true, ...(await fonts().addBytes(bytes, name)) }; } catch (e) { return { ok: false, error: e.message }; } });
ipcMain.handle('font-pick', async () => { // "Install font…" button
  const r = await dialog.showOpenDialog(win, { title: 'Install fonts', filters: [{ name: 'Fonts', extensions: ['ttf', 'otf', 'woff'] }], properties: ['openFile', 'multiSelect'] });
  if (r.canceled) return [];
  const out = []; for (const p of r.filePaths) { try { out.push({ ok: true, ...(await fonts().addFile(p)) }); } catch (e) { out.push({ ok: false, error: e.message }); } } return out;
});
const BUNDLED_FONTS = { 'Noto Nastaliq Urdu': 'NotoNastaliqUrdu.ttf', 'Noto Naskh Arabic': 'NotoNaskhArabic.ttf' };
ipcMain.handle('font-bundled', async (_e, name) => BUNDLED_FONTS[name] ? new Uint8Array(await fs.promises.readFile(path.join(__dirname, 'fonts', BUNDLED_FONTS[name]))) : null);
ipcMain.handle('font-remove', (_e, id) => fonts().remove(id));

// ---- Python plugins (see plugins/urduofdani_plugin.py) ----
ipcMain.handle('plugin-status', () => { try { plugins(); return plugins().status(); } catch (e) { return { python: false, error: e.message }; } });
ipcMain.handle('plugin-list', () => plugins().list());
ipcMain.handle('plugin-run', (_e, req) => plugins().run(req || {}));
ipcMain.handle('plugin-folder', async () => { plugins(); return shell.openPath(ud('plugins')); });

// ---- custom keyboard layouts + spelling word lists (both live in the user's data folder) ----
ipcMain.handle('layout-list', () => { try { LY.ensureExample(ud('layouts'), PH.MAP); } catch {} return LY.list(ud('layouts')); });
ipcMain.handle('layout-folder', async () => { LY.ensureExample(ud('layouts'), PH.MAP); return shell.openPath(ud('layouts')); });
const dictDir = () => { const d = ud('dictionary'); fs.mkdirSync(d, { recursive: true }); const r = path.join(d, 'README.txt');
  if (!fs.existsSync(r)) fs.writeFileSync(r, 'UrduOfDani spelling word lists\r\n\r\nPut one or more UTF-8 text files (.txt) in this folder: one Urdu word per line.\r\nUrduOfDani does not include a word list; use one you are allowed to use (check its licence).\r\nWords you add from the right-click menu are saved in user-words.txt.\r\nRestart spell-check (turn it off and on) after changing files.\r\n'); return d; };
ipcMain.handle('dict-load', async () => { const d = dictDir(), words = []; let files = 0, bytes = 0;
  for (const f of fs.readdirSync(d).filter(f => /\.txt$/i.test(f) && f !== 'README.txt')) { const st = fs.statSync(path.join(d, f)); bytes += st.size; if (bytes > 80 * 1024 * 1024) break; files++; for (const l of fs.readFileSync(path.join(d, f), 'utf8').split(/\r?\n/)) { const w = l.trim().split(/\s+/)[0]; if (w) words.push(w); } }
  return { words, files, folder: d }; });
ipcMain.handle('dict-add', async (_e, w) => { if (typeof w !== 'string' || !w || w.length > 40 || /\s/.test(w)) return false; await fs.promises.appendFile(path.join(dictDir(), 'user-words.txt'), w + '\r\n', 'utf8'); return true; });
ipcMain.handle('dict-folder', async () => shell.openPath(dictDir()));
