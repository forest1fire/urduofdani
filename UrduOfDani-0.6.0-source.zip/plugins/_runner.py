"""UrduOfDani plugin runner (internal). Executed by the app as a separate process, so a crashing or hanging plugin cannot take the editor down.
  python _runner.py list <plugins-dir>        -> JSON list of the plugins found
  python _runner.py run  <file.py> <ClassName> -> reads {"text":..., "context":...} on stdin, prints {"ok":true,"text":...} or {"ok":false,"error":...}
Created by Muhammad Danish [Dani] · DaniLabs — free and open-source."""
import io, json, os, sys, traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from urduofdani_plugin import UrduOfDaniPlugin  # noqa: E402

REAL_OUT = sys.stdout
MAX_OUT = 64 * 1024 * 1024


def _emit(obj):
    REAL_OUT.write(json.dumps(obj, ensure_ascii=False))
    REAL_OUT.flush()


def _load(path):
    """Execute a plugin file and return the UrduOfDaniPlugin subclasses it defines."""
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()
    ns = {"__name__": "urduofdani_user_plugin", "__file__": path, "UrduOfDaniPlugin": UrduOfDaniPlugin}
    exec(compile(src, path, "exec"), ns)
    return [v for v in ns.values() if isinstance(v, type) and issubclass(v, UrduOfDaniPlugin) and v is not UrduOfDaniPlugin]


def cmd_list(directory):
    out = []
    for fn in sorted(os.listdir(directory)):
        if not fn.endswith(".py") or fn.startswith("_") or fn == "urduofdani_plugin.py":
            continue
        path = os.path.join(directory, fn)
        try:
            classes = []
            for cls in _load(path):
                try:
                    inst = cls()
                    classes.append(dict(inst.info(), cls=cls.__name__))
                except Exception as e:  # a plugin whose __init__ fails is reported, not fatal
                    classes.append({"cls": cls.__name__, "name": cls.__name__, "error": "init failed: %s" % e})
            out.append({"file": fn, "plugins": classes, "error": None if classes else "no UrduOfDaniPlugin subclass found"})
        except BaseException as e:  # SyntaxError, import errors, even SystemExit inside the plugin file
            out.append({"file": fn, "plugins": [], "error": "%s: %s" % (type(e).__name__, e)})
    _emit(out)


def cmd_run(path, cls_name):
    try:
        req = json.loads(sys.stdin.read() or "{}")
        text = req.get("text", "")
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        sys.stdout = sys.stderr  # plugin print() output must not corrupt our JSON reply
        classes = {c.__name__: c for c in _load(path)}
        if cls_name not in classes:
            raise LookupError("plugin class %s not found in %s" % (cls_name, os.path.basename(path)))
        result = classes[cls_name]().execute(text, req.get("context") or {})
        if not isinstance(result, str):
            raise TypeError("execute() must return a str, got %s" % type(result).__name__)
        if len(result) > MAX_OUT:
            raise ValueError("plugin output is too large")
        sys.stdout = REAL_OUT
        _emit({"ok": True, "text": result})
    except BaseException as e:
        sys.stdout = REAL_OUT
        _emit({"ok": False, "error": "%s: %s" % (type(e).__name__, e), "trace": traceback.format_exc(limit=4)})


if __name__ == "__main__":
    for s in (sys.stdin, sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass
    REAL_OUT = sys.stdout
    try:
        if len(sys.argv) >= 3 and sys.argv[1] == "list":
            cmd_list(sys.argv[2])
        elif len(sys.argv) >= 4 and sys.argv[1] == "run":
            cmd_run(sys.argv[2], sys.argv[3])
        else:
            _emit({"ok": False, "error": "usage: _runner.py list <dir> | run <file> <class>"})
    except BaseException as e:
        _emit({"ok": False, "error": str(e)})
