import unicodedata


class AerabRemover(UrduOfDaniPlugin):
    def __init__(self):
        self.name = "Aerab (Diacritics) Remover"
        self.version = "1.0.0"
        self.author = "DaniLabs"
        self.description = "Removes zabar, zer, pesh, shadda, jazm and other marks, leaving the plain letters."

    def execute(self, text: str, context=None) -> str:
        try:
            marks = set(range(0x064B, 0x0660)) | {0x0670}
            modified_text = "".join(ch for ch in unicodedata.normalize("NFC", text) if ord(ch) not in marks)
            return modified_text
        except Exception:
            return text
