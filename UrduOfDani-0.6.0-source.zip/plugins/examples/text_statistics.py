class TextStatistics(UrduOfDaniPlugin):
    def __init__(self):
        self.name = "Text Statistics (appends a report)"
        self.version = "1.0.0"
        self.author = "DaniLabs"
        self.description = "Keeps your text and adds a line with word, letter and line counts."

    def execute(self, text: str, context=None) -> str:
        try:
            words = len(text.split())
            letters = sum(1 for ch in text if "؀" <= ch <= "ۿ")
            lines = len([l for l in text.split("\n") if l.strip()])
            modified_text = text + "\n\n[%d words · %d Urdu letters · %d lines]" % (words, letters, lines)
            return modified_text
        except Exception as e:
            return text
