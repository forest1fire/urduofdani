class UrduHackNormalizer(UrduOfDaniPlugin):
    def __init__(self):
        self.name = "Urdu Hack Normalizer (optional)"
        self.version = "1.0.0"
        self.author = "DaniLabs"
        self.description = "Cleans text with the free Urdu Hack library (normalises odd characters, fixes spaces). Needs: pip install urduhack"

    def execute(self, text: str, context=None) -> str:
        try:
            try:
                from urduhack.normalization import normalize  # optional third-party library
            except ImportError:
                raise RuntimeError("Urdu Hack is not installed. Open a Command Prompt and run: pip install urduhack")
            modified_text = normalize(text)
            return modified_text
        except RuntimeError:
            raise  # shown to the user; the document is not changed
        except Exception:
            return text
