import re


class UrduPunctuationFixer(UrduOfDaniPlugin):
    def __init__(self):
        self.name = "Urdu Punctuation Fixer"
        self.version = "1.0.0"
        self.author = "DaniLabs"
        self.description = "Turns Latin , ? ; and a closing full stop into Urdu ، ؟ ؛ ۔ after Urdu text."

    def execute(self, text: str, context=None) -> str:
        try:
            urdu = "؀-ۿ"
            modified_text = re.sub("([%s])\\s*," % urdu, "\\1،", text)
            modified_text = re.sub("([%s])\\s*\\?" % urdu, "\\1؟", modified_text)
            modified_text = re.sub("([%s])\\s*;" % urdu, "\\1؛", modified_text)
            modified_text = re.sub("([%s])\\s*\\.(?=\\s|$)" % urdu, "\\1۔", modified_text)
            return modified_text
        except Exception:
            return text  # never break the document because of a bug here
