"""UrduOfDani plugin API  (free and open-source — created by Muhammad Danish [Dani], DaniLabs).

A plugin is one .py file in the UrduOfDani plugins folder. It defines a class that inherits from UrduOfDaniPlugin
(the name is already available to your file — no import needed, though `from urduofdani_plugin import UrduOfDaniPlugin` also works):

    class YourPluginName(UrduOfDaniPlugin):
        def __init__(self):
            self.name = "Exact Plugin Name"
            self.version = "1.0.0"
            self.author = "Developer Name (or DaniLabs)"
            self.description = "A concise explanation of what this tool does."

        def execute(self, text: str, context=None) -> str:
            # Perform custom Unicode operations on the text string here
            modified_text = text
            return modified_text

`text` is plain Unicode (UTF-8). `context` is a dict: {"mode": "selection" | "document", "app": "UrduOfDani", "version": "...", "page": {...}}.
Return the new text. If your code raises, UrduOfDani shows the error and leaves the document untouched; a buggy plugin cannot crash the app.
"""


class UrduOfDaniPlugin:
    """Base class for every UrduOfDani plugin."""
    name = "Unnamed plugin"
    version = "0.0.0"
    author = "Unknown"
    description = ""

    def execute(self, text: str, context=None) -> str:
        """Override this. The default does nothing."""
        return text

    def info(self) -> dict:
        return {"name": str(self.name), "version": str(self.version), "author": str(self.author), "description": str(self.description)}
