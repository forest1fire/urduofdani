const { contextBridge, ipcRenderer } = require('electron');
const i = (c) => (...a) => ipcRenderer.invoke(c, ...a);
contextBridge.exposeInMainWorld('api', { open: i('open'), openPath: i('open-path'), recent: i('recent'), startupFile: i('startup-file'), save: i('save'), exportTxt: i('export-txt'), exportHtml: i('export-html'), exportEpub: i('export-epub'),
  exportPdf: i('export-pdf'), previewPdf: i('preview-pdf'), autosave: i('autosave'), recovery: i('recovery'), clearRecovery: i('clear-recovery'), print: i('print'),
  fontList: i('font-list'), fontData: i('font-data'), fontAddBytes: i('font-add-bytes'), fontPick: i('font-pick'), fontRemove: i('font-remove'), bundledFont: i('font-bundled'), pluginStatus: i('plugin-status'), pluginList: i('plugin-list'), pluginRun: i('plugin-run'), pluginFolder: i('plugin-folder'), layoutList: i('layout-list'), layoutFolder: i('layout-folder'), dictLoad: i('dict-load'), dictAdd: i('dict-add'), dictFolder: i('dict-folder'),
  onOpen: cb => ipcRenderer.on('open-doc', (_e, r) => cb(r)) });
