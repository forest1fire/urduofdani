'use strict';
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const ed = $('#editor'), sheet = $('#sheet');
const SIZES = { A4: [210, 297], A5: [148, 210], A3: [297, 420], Letter: [215.9, 279.4], Legal: [215.9, 355.6] };
const MM = 96 / 25.4;
const DEFAULT_PAGE = { size: 'A4', orient: 'portrait', margin: 20, columns: 1, header: '', footer: '', pageNumbers: true, font: '', fontSize: 18, lineHeight: 1.8, embedFonts: true };
let state = { path: null, dirty: false, kb: 'off', digits: 'urdu', styles: {}, page: { ...DEFAULT_PAGE } };

// ---------- setup ----------
Fonts.refreshPicker(); Styles.refreshSelect();
$('#size').innerHTML = [12, 14, 16, 18, 20, 24, 28, 36, 48, 72].map(s => `<option ${s == 18 ? 'selected' : ''}>${s}</option>`).join('');
ed.innerHTML = '<p><br></p>';
function dims() {
  const [w, h] = SIZES[state.page.size], L = state.page.orient === 'landscape';
  const H = (L ? w : h) * MM, m = state.page.margin * MM; return { w: (L ? h : w) * MM, h: H, m, ch: H - 2 * m };
}
function applyPage() {
  const d = dims(), p = state.page;
  sheet.style.width = d.w + 'px'; sheet.style.padding = d.m + 'px';
  sheet.style.setProperty('--ch', d.ch + 'px'); sheet.style.setProperty('--mp', d.m + 'px'); sheet.style.setProperty('--m', p.margin + 'mm');
  ed.style.minHeight = d.ch + 'px'; ed.style.columnCount = p.columns;
  ed.style.fontFamily = p.font ? `${Fonts.cssFam(p.font)},"Noto Nastaliq Urdu","Noto Naskh Arabic",serif` : ''; ed.style.fontSize = (p.fontSize || 18) + 'pt'; ed.style.lineHeight = p.lineHeight || 1.8; setLh(p.lineHeight || 1.8);
  let st = $('#pagecss'); if (!st) { st = document.createElement('style'); st.id = 'pagecss'; document.head.append(st); }
  st.textContent = `@page{size:${p.size} ${p.orient};margin:${p.margin}mm}`;
  $('#psize').value = p.size; $('#margin').value = p.margin; $('#cols').value = p.columns; $('#orient').checked = p.orient === 'landscape'; $('#pnum').checked = p.pageNumbers !== false;
  layoutSoon();
}
// ---------- layout / thumbnails (cheap: derived from scrollHeight, debounced) ----------
const CHUNK = 25; // paragraphs per layout group (see README: cuts 500-page typing cost ~5x)
function chunkify() { // group top-level paragraphs into <section class="chunk"> so each group is its own layout/paint boundary
  const ps = [...ed.children]; if (ps.length < CHUNK * 4 || ps[0].classList.contains('chunk')) return;
  const f = document.createDocumentFragment();
  for (let i = 0; i < ps.length; i += CHUNK) { const sec = document.createElement('section'); sec.className = 'chunk'; sec.append(...ps.slice(i, i + CHUNK)); f.append(sec); }
  ed.replaceChildren(f);
}
const stripChunks = html => html.replace(/<section class="chunk"[^>]*>/g, '').replace(/<\/section>/g, ''); // saved files never contain chunk wrappers
function autoCv(allowChunk) {
  const on = ed.textContent.length > 150000 && state.page.columns === 1, was = ed.classList.contains('cv');
  if (on && allowChunk) chunkify(); // only at load time: re-parenting nodes mid-session would disturb the undo stack
  ed.classList.toggle('cv', on);
  if (on && !was) { // calibrate the off-screen paragraph height estimate from a few really rendered paragraphs
    const first = ed.firstElementChild, sec = first && first.classList.contains('chunk') ? first : null;
    const k = sec ? [sec] : [...ed.children].slice(0, 10); k.forEach(c => c.style.contentVisibility = 'visible');
    const h = k.reduce((s, c) => s + c.offsetHeight, 0) / (sec ? sec.children.length || 1 : k.length || 1); k.forEach(c => c.style.contentVisibility = '');
    if (h > 10) ed.style.setProperty('--est', Math.round(h) + 'px');
  }
}
let lt; function layoutSoon() { clearTimeout(lt); lt = setTimeout(() => (window.requestIdleCallback || setTimeout)(layout, { timeout: 600 }), 150); }
function layout() {
  const d = dims(); const len = ed.textContent.length;
  // Big documents: let Chromium skip rendering off-screen paragraphs (large win for 100-500 pages). Single column only.
  autoCv(false); ed.querySelectorAll('section.chunk:empty').forEach(n => n.remove());
  const pages = Math.max(1, Math.ceil((ed.offsetHeight - 1) / d.ch)); // content height / printable page height (matches PDF, approx.)
  sheet.style.minHeight = (pages * d.ch + 2 * d.m) + 'px';
  $('#st-pages').textContent = (ed.classList.contains('cv') ? '~' : '') + pages + (pages === 1 ? ' page' : ' pages');
  const tl = $('#tlist'); if (tl.children.length !== pages) {
    const ar = d.h / d.w, f = document.createDocumentFragment();
    for (let i = 0; i < pages; i++) { const t = document.createElement('div'); t.className = 'th'; t.style.height = 64 * ar + 'px'; t.textContent = i + 1; t.dataset.i = i; f.append(t); }
    tl.replaceChildren(f);
  }
  $('#st-words').textContent = (len < 400000 ? (ed.textContent.match(/\S+/g) || []).length : Math.round(len / 5.5)) + (len < 400000 ? ' words' : ' words (est.)');
}
$('#tlist').addEventListener('click', e => { const t = e.target.closest('.th'); if (t) $('#canvas').scrollTo({ top: sheet.offsetTop + t.dataset.i * dims().ch * zoom() - 12 }); });
const zoom = () => $('#zoom').value / 100;
$('#zoom').oninput = () => { $('#zoomer').style.transform = `scale(${zoom()})`; $('#zv').textContent = $('#zoom').value + '%'; };
$('#canvas').addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); const z = $('#zoom'); z.value = Math.min(250, Math.max(30, +z.value - Math.sign(e.deltaY) * 10)); z.oninput(); } }, { passive: false });

// ---------- dirty / autosave / recovery ----------
const getDoc = () => ({ html: stripChunks(ed.innerHTML), page: { ...state.page, header: $('#hdr').innerHTML, footer: $('#ftr').innerHTML }, styles: state.styles }); // autosave: no fonts (too heavy every 3 s)
async function getDocFull() { // saving: also embed the user's fonts that the text uses (licence permitting)
  const d = getDoc(); if (state.page.embedFonts === false) return d; const e = await Fonts.embedPayload(); d.fonts = e.fonts;
  if (e.blocked.length) UI.toast('Not embedded (font licence forbids it): ' + e.blocked.join(', '), 7000); return d;
}
let at; function markDirty() { state.dirty = true; $('#dirty').textContent = ' '; clearTimeout(at); at = setTimeout(() => (window.requestIdleCallback || setTimeout)(async () => { await api.autosave(getDoc()); $('#st-save').textContent = 'Autosaved ' + new Date().toLocaleTimeString(); }, { timeout: 4000 }), 3000); layoutSoon(); }
function loadDoc(d, path) {
  ed.innerHTML = d.html || '<p><br></p>'; state.page = { ...DEFAULT_PAGE, ...d.page }; Styles.load(d.styles); Fonts.loadSession(d.fonts).then(() => { checkFonts(); layoutSoon(); }); autoCv(true); $('#hdr').innerHTML = d.page?.header || ''; $('#ftr').innerHTML = d.page?.footer || '';
  state.path = path; state.dirty = false; $('#dirty').textContent = ''; $('#docname').textContent = path ? path.split(/[\\/]/).pop() : 'Untitled'; applyPage();
  checkFonts();
}
// missing-font warning (document fonts not available on this machine)
function checkFonts() {
  const miss = Fonts.missing(), st = $('#st-save');
  if (miss.length) { st.textContent = '⚠ Missing fonts: ' + miss.join(', ') + ' (fallback in use) — click here to install'; st.classList.add('warn'); }
  else if (st.classList.contains('warn')) { st.textContent = ''; st.classList.remove('warn'); }
}
$('#st-save').addEventListener('click', () => { if ($('#st-save').classList.contains('warn')) Fonts.open(); });
// remember the editor selection while a dialog / colour picker has focus
let savedRange = null, reflectQ = 0;
document.addEventListener('selectionchange', () => { if (window.__selLock) return; const s = getSelection(); if (s.rangeCount && ed.contains(s.anchorNode)) { savedRange = s.getRangeAt(0).cloneRange(); if (!reflectQ) reflectQ = requestAnimationFrame(() => { reflectQ = 0; Styles.reflect(); }); } });
function restoreSel() { ed.focus(); if (savedRange) { const s = getSelection(); s.removeAllRanges(); s.addRange(savedRange); } }
ed.addEventListener('input', () => { markDirty(); });
$$('#hdr,#ftr').forEach(e => e.addEventListener('input', markDirty));

// ---------- latency probe ----------
ed.addEventListener('beforeinput', () => { const t = performance.now(); requestAnimationFrame(() => { $('#st-lat').textContent = 'key→paint ' + (performance.now() - t).toFixed(1) + ' ms'; }); });

// ---------- paste: Unicode plain text only (predictable, clean) ----------
ed.addEventListener('paste', e => { e.preventDefault(); const t = (e.clipboardData.getData('text/plain') || '').replace(/\r\n?/g, '\n'); document.execCommand('insertText', false, t); });

// ---------- phonetic keyboards (phon = 1 key -> 1 letter, smart = + Roman-Urdu digraphs) ----------
let smart = Phon.createSmart(), lastKey = 0;
const resetSmart = () => { smart = Phon.createSmart({ digits: state.digits }); };
ed.addEventListener('keydown', e => {
  if (state.kb === 'off' || e.ctrlKey || e.metaKey || e.altKey) { if (state.kb === 'smart') smart.reset(); return; }
  if (e.key.length !== 1) { smart.reset(); return; } // arrows, Backspace, Enter, … break the current word
  const now = performance.now(); if (now - lastKey > 1200) smart.reset(); lastKey = now;
  if (state.kb.startsWith('layout:')) { const m = state.layoutMap && state.layoutMap[e.key]; if (m) { e.preventDefault(); document.execCommand('insertText', false, m); } return; } // user layout (JSON file)
  if (state.kb === 'phon') { if (state.digits === 'latin' && /\d/.test(e.key)) return; const m = Phon.MAP[e.key]; if (m) { e.preventDefault(); document.execCommand('insertText', false, m); } return; }
  const r = smart.feed(e.key); if (!r) return; e.preventDefault();
  if (r.del) { const sel = getSelection(); for (let i = 0; i < r.del; i++) sel.modify('extend', 'backward', 'character'); } // replace the previous letters in one step
  document.execCommand('insertText', false, r.ins);
});
ed.addEventListener('mousedown', () => smart.reset()); ed.addEventListener('blur', () => smart.reset());
$('#kb').onchange = e => { state.kb = e.target.value; state.layoutMap = state.kb.startsWith('layout:') ? ((window.__layouts || {})[state.kb] || null) : null; if (state.kb !== 'off') state.lastKb = state.kb; resetSmart(); $('#st-kb').textContent = state.kb === 'off' ? '' : 'Urdu keys: ' + (state.kb === 'smart' ? 'smart' : state.kb === 'phon' ? 'phonetic' : ((window.__layoutNames || {})[state.kb] || 'layout')); };
$('#digits').onchange = e => { state.digits = e.target.value; resetSmart(); };
window.addEventListener('keydown', e => { if (e.altKey && e.key.toLowerCase() === 'k') { const s = $('#kb'); s.value = s.value === 'off' ? (state.lastKb || 'smart') : 'off'; s.onchange({ target: s }); } });
// ---------- formatting ----------
$$('[data-c]').forEach(b => b.onmousedown = e => { e.preventDefault(); document.execCommand(b.dataset.c); });
function wrapStyle(prop, val) { const s = getSelection(); if (!s.rangeCount || s.isCollapsed) return; const r = s.getRangeAt(0); const sp = document.createElement('span'); sp.style[prop] = val; sp.append(r.extractContents()); r.insertNode(sp); markDirty(); checkFonts(); }
function applyFont(fam) { // range -> span (works with chunk wrappers); caret only -> typing style
  const s = getSelection(); if (!s.rangeCount || s.isCollapsed) { ed.focus(); document.execCommand('styleWithCSS', false, true); document.execCommand('fontName', false, fam); document.execCommand('styleWithCSS', false, false); markDirty(); checkFonts(); return; }
  wrapStyle('fontFamily', `${Fonts.cssFam(fam)},serif`);
}
$('#font').onchange = e => { const v = e.target.value; if (v === '__more') { e.target.value = ''; Fonts.open(); return; } if (!v) return; applyFont(v); ed.focus(); };
$('#size').onchange = e => { wrapStyle('fontSize', e.target.value + 'pt'); ed.focus(); };
$('#pstyle').onchange = e => { const v = e.target.value; restoreSel(); if (v === '__edit') { Styles.reflect(); Styles.open(); return; } Styles.applyTo(v); };
function setLh(v) { const sel = $('#lh'); if (![...sel.options].some(o => +o.value === +v)) sel.append(new Option('Line ' + v, v)); sel.value = String(v); }
$('#lh').onchange = e => { state.page.lineHeight = +e.target.value; ed.style.lineHeight = e.target.value; markDirty(); };
$('#psize').onchange = e => { state.page.size = e.target.value; applyPage(); markDirty(); };
$('#margin').onchange = e => { state.page.margin = Math.min(50, Math.max(5, +e.target.value || 20)); applyPage(); markDirty(); };
$('#cols').onchange = e => { state.page.columns = +e.target.value; applyPage(); markDirty(); };
$('#pnum').onchange = e => { state.page.pageNumbers = e.target.checked; markDirty(); };
$('#orient').onchange = e => { state.page.orient = e.target.checked ? 'landscape' : 'portrait'; applyPage(); markDirty(); };
function setDir(d) { const s = getSelection(); let n = s.anchorNode; while (n && n.parentNode !== ed) n = n.parentNode; if (n && n.nodeType === 1) { n.dir = d; if (!n.style.textAlign) n.style.textAlign = d === 'rtl' ? 'right' : 'left'; markDirty(); } }

// ---------- find / replace ----------
function find(back) { const q = $('#fq').value; if (q) window.find(q, false, !!back, true); }
function replaceOne() { const s = getSelection(); if (s.toString() === $('#fq').value && s.rangeCount) { document.execCommand('insertText', false, $('#fr').value); } find(); }
function replaceAll() { // each match is a normal edit, so Ctrl+Z undoes them one by one
  const q = $('#fq').value, r = $('#fr').value; if (!q) return; ed.focus();
  const sel = getSelection(); sel.removeAllRanges(); const rg = document.createRange(); rg.selectNodeContents(ed); rg.collapse(true); sel.addRange(rg);
  let n = 0; while (n < 5000 && window.find(q, false, false, false)) { document.execCommand('insertText', false, r); n++; }
  $('#st-save').textContent = `Replaced ${n} match${n === 1 ? '' : 'es'} (undo with Ctrl+Z)`; markDirty();
}
// ---------- templates (starter content) ----------
const TPL = {
  urdu: { page: { size: 'A4', columns: 1, margin: 25 }, html: '<h1>عنوان یہاں لکھیں</h1><p>یہاں اپنا متن لکھیں۔</p>' },
  book: { page: { size: 'A5', columns: 1, margin: 22 }, html: '<h1>کتاب کا نام</h1><h2>باب اول</h2><p>متن شروع کریں۔</p><hr><h2>باب دوم</h2><p><br></p>' },
  news: { page: { size: 'A3', columns: 3, margin: 12 }, html: '<h1>اخبار کی سرخی</h1><p>خبر کا متن یہاں لکھیں۔ کالم خودکار طور پر تقسیم ہوں گے۔</p>' },
  invite: { page: { size: 'A5', orient: 'landscape', columns: 1, margin: 20 }, html: '<h1>دعوتِ ولیمہ</h1><p style="text-align:center">تاریخ، وقت اور مقام یہاں درج کریں</p>' },
  poetry: { page: { size: 'A5', columns: 1, margin: 22 }, html: '<h1>غزل</h1><div class="sher"><div>پہلا مصرع یہاں لکھیں</div><div>دوسرا مصرع یہاں لکھیں</div></div><div class="sher"><div>پہلا مصرع</div><div>دوسرا مصرع</div></div>' },
  poster: { page: { size: 'A3', columns: 1, margin: 15 }, html: '<h1 style="font-size:4em">پوسٹر کی سرخی</h1><p style="text-align:center;font-size:1.5em">تفصیل</p>' }
};
$('#tpl').onchange = e => { const t = TPL[e.target.value]; if (t && confirm('Replace current content with this template?')) { loadDoc({ html: t.html, page: { ...t.page }, styles: {} }, null); markDirty(); } e.target.value = ''; };

const pdfOpts = () => ({ size: state.page.size, landscape: state.page.orient === 'landscape', margin: state.page.margin, pageNumbers: state.page.pageNumbers !== false, header: $('#hdr').innerHTML, footer: $('#ftr').innerHTML });
// ---------- actions ----------
const A = {
  async new() { if (state.dirty && !confirm('Discard unsaved changes?')) return; loadDoc({ html: '<p><br></p>', page: {}, styles: {} }, null); api.clearRecovery(); },
  async open() { if (state.dirty && !confirm('Discard unsaved changes?')) return; const r = await api.open(); if (r) { loadDoc(r.doc, r.path); if (r.imported) { state.dirty = true; $('#st-save').textContent = 'Imported text — use Save As to create a .udani (original untouched)'; } } },
  async save() { const p = await api.save({ path: state.path, doc: await getDocFull() }); if (p) { state.path = p; state.dirty = false; $('#dirty').textContent = ''; $('#docname').textContent = p.split(/[\\/]/).pop(); $('#st-save').textContent = 'Saved'; } },
  async saveas() { const p = await api.save({ path: state.path, doc: await getDocFull(), as: true }); if (p) { state.path = p; state.dirty = false; $('#dirty').textContent = ''; $('#docname').textContent = p.split(/[\\/]/).pop(); } },
  async pdf() { const t = performance.now(); const p = await api.exportPdf(pdfOpts()); if (p) $('#st-save').textContent = `PDF exported in ${((performance.now() - t) / 1000).toFixed(1)} s`; },
  async preview() { $('#st-save').textContent = 'Building preview…'; await api.previewPdf(pdfOpts()); $('#st-save').textContent = 'Preview opened (same engine as PDF export)'; },
  async txt() { const p = await api.exportTxt(ed.innerText); if (p) $('#st-save').textContent = 'Text exported'; },
  print() { api.print(); },
  undo() { ed.focus(); document.execCommand('undo'); }, redo() { ed.focus(); document.execCommand('redo'); },
  find() { $('#findbar').hidden = false; $('#fq').focus(); }, fclose() { $('#findbar').hidden = true; }, fnext() { find(); }, fone: replaceOne, fall: replaceAll,
  theme() { const b = document.body; b.dataset.theme = b.dataset.theme === 'dark' ? 'light' : 'dark'; },
  rtl() { setDir('rtl'); }, ltr() { setDir('ltr'); }, osk() { osk.hidden = !osk.hidden; },
  hr() { ed.focus(); document.execCommand('insertHTML', false, '<hr><p><br></p>'); },
  async table() { const v = await UI.form('Insert table', [{ id: 'n', label: 'Columns', type: 'number', value: 3, min: 1, max: 12 }, { id: 'r', label: 'Rows', type: 'number', value: 3, min: 1, max: 200 }], 'Insert'); if (!v) return; // (window.prompt does not exist in Electron)
    const n = Math.min(12, Math.max(1, v.n | 0 || 3)), r = Math.min(200, Math.max(1, v.r | 0 || 3)); restoreSel(); document.execCommand('insertHTML', false, '<table>' + ('<tr>' + '<td><br></td>'.repeat(n) + '</tr>').repeat(r) + '</table><p><br></p>'); },
  image() { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.onchange = () => { const f = i.files[0]; if (!f) return; const fr = new FileReader(); fr.onload = () => { ed.focus(); document.execCommand('insertImage', false, fr.result); }; fr.readAsDataURL(f); }; i.click(); }
};
$$('[data-a]').forEach(b => b.onclick = () => A[b.dataset.a]());
window.addEventListener('keydown', e => {
  if (!e.ctrlKey) return; const k = e.key.toLowerCase();
  if (k === 's') { e.preventDefault(); e.shiftKey ? A.saveas() : A.save(); } else if (k === 'f' && e.shiftKey) { /* focus mode: features.js */ return; } else if (k === 'o') { e.preventDefault(); A.open(); } else if (k === 'n') { e.preventDefault(); A.new(); } else if (k === 'f') { e.preventDefault(); A.find(); } else if (k === 'p') { e.preventDefault(); A.print(); }
  else if (k === 'e') { e.preventDefault(); document.execCommand('justifyCenter'); }
});
$('#fq').onkeydown = e => { if (e.key === 'Enter') find(e.shiftKey); };
window.addEventListener('beforeunload', e => { if (state.dirty) { api.autosave(getDoc()); } });

// ---------- branding ----------
const B = window.BRAND; document.title = B.app;
$('#sp-by').textContent = B.splash(B.creator); $('#sp-lab').textContent = B.studio;
$('#ab-by').textContent = B.about(B.creator); $('#ab-ver').textContent = `Version ${B.version} · © ${B.creator} / ${B.studio}`; $('#ab-disc').textContent = B.disclaimer;
$('#brandfoot').textContent = B.footer(B.creator);
A.about = () => { $('#about').hidden = false; }; A.aboutclose = () => { $('#about').hidden = true; };
$$('[data-a=aboutclose]').forEach(b => b.onclick = A.aboutclose);
$('#about').addEventListener('mousedown', e => { if (e.target.id === 'about') A.aboutclose(); });
const t0 = performance.now(); document.fonts.ready.then(() => setTimeout(() => { $('#splash').classList.add('hide'); setTimeout(() => $('#splash').remove(), 250); }, Math.max(0, 450 - (performance.now() - t0))));
// ---------- startup ----------
(async () => {
  applyPage(); $('#zoom').oninput();
  Fonts.init().then(() => { checkFonts(); layoutSoon(); }).catch(() => {});
  const sf = await api.startupFile(); // a .udani double-clicked in Explorer
  if (sf) { loadDoc(sf.doc, sf.path); ed.focus(); performance.mark('ready'); return; }
  const r = await api.recovery();
  if (r && r.html && r.html.replace(/<[^>]*>/g, '').trim() && confirm('UrduOfDani found an autosaved document from an earlier session. Recover it?')) { loadDoc(r, null); state.dirty = true; $('#dirty').textContent = ' '; }
  else if (r) api.clearRecovery();
  ed.focus(); performance.mark('ready'); $('#st-lat').textContent = 'ready ' + performance.now().toFixed(0) + ' ms';
})();
