// Single source of truth for branding. Change CREATOR via: node scripts/set-creator.js "Full Name"
window.BRAND = {
  app: 'UrduOfDani', creator: 'Muhammad Danish [Dani]', studio: 'DaniLabs', version: '0.6.0',
  splash: c => `Created by ${c}`, about: c => `UrduOfDani — Designed and Developed by ${c}`, footer: c => `An Urdu publishing application by ${c}`,
  disclaimer: 'UrduOfDani is an independent application. It is inspired by the Urdu publishing workflow of InPage but is not affiliated with, endorsed by, or a product of InPage or its owners.'
};
