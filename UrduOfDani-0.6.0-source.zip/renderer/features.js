'use strict';
// v0.6 features that sit on top of app.js: keys & symbols panel, sher blocks, colours, command palette, focus mode,
// recent files, font drag-and-drop, HTML export. (app.js owns the document; this file only adds actions.)
(() => {
  const { el } = UI;

  // ---------- keys & symbols panel ----------
  const osk = $('#osk'); let oskTab = 'letters';
  const COMBINING = cp => (cp >= 0x610 && cp <= 0x61A) || (cp >= 0x64B && cp <= 0x65F) || cp === 0x670;
  function buildOsk() {
    const tabs = el('div', { class: 'otabs' }, ...[['letters', 'Letters'], ['marks', 'Marks & symbols']].map(([k, t]) => el('button', { class: k === oskTab ? 'on' : '', text: t, tabindex: -1, onclick: () => { oskTab = k; buildOsk(); } })));
    let body;
    if (oskTab === 'letters') body = el('div', { class: 'oletters' }, ...Phon.KB_ROWS.map(r => el('div', { class: 'krow' }, ...[...r].map(c => el('button', { tabindex: -1, text: c })))), el('div', { class: 'krow' }, el('button', { tabindex: -1, 'data-sp': '1', style: 'min-width:240px', text: 'space' })));
    else body = el('div', { class: 'omarks' }, ...Phon.MARKS.map(g => el('div', { class: 'mgroup' }, el('small', { text: g.name }), el('div', { class: 'krow wrap' }, ...g.items.map(i => el('button', { tabindex: -1, title: i.label, 'data-ins': i.ch, text: (COMBINING(i.cp) ? '◌' : '') + i.ch }))))));
    osk.replaceChildren(tabs, body);
  }
  osk.addEventListener('mousedown', e => { e.preventDefault(); const b = e.target.closest('.krow button'); if (!b) return; restoreSel(); document.execCommand('insertText', false, b.dataset.sp ? ' ' : (b.dataset.ins || b.textContent)); });
  buildOsk();
  A.osk = () => { osk.hidden = !osk.hidden; };

  // ---------- fonts / styles actions ----------
  A.fonts = () => Fonts.open(); A.styles = () => { restoreSel(); Styles.reflect(); Styles.open(); };

  // ---------- sher (couplet) ----------
  A.sher = () => {
    restoreSel(); const sel = getSelection(), bl = selectedBlocks().filter(b => b.localName !== 'table' && !b.classList.contains('sher'));
    const inner = b => b.innerHTML.replace(/<br>$/, '') || '<br>';
    if (bl.length >= 2) { // every two selected lines become one couplet
      let html = ''; for (let i = 0; i < bl.length; i += 2) html += `<div class="sher"><div>${inner(bl[i])}</div><div>${bl[i + 1] ? inner(bl[i + 1]) : '<br>'}</div></div>`;
      const last = bl[bl.length - 1], r = document.createRange(); r.setStart(bl[0], 0); r.setEnd(last, last.childNodes.length); sel.removeAllRanges(); // end INSIDE the last block: ending after it makes Chromium merge the next paragraph into the couplet
      sel.addRange(r); document.execCommand('insertHTML', false, html);
    } else {
      document.execCommand('insertHTML', false, '<div class="sher" data-new="1"><div>مصرع اول</div><div>مصرع ثانی</div></div><p><br></p>');
      const n = ed.querySelector('.sher[data-new]'); if (n) { n.removeAttribute('data-new'); const r = document.createRange(); r.selectNodeContents(n.firstElementChild); sel.removeAllRanges(); sel.addRange(r); }
    }
    markDirty();
  };

  // ---------- colours ----------
  const colour = (cmd, input) => input.addEventListener('change', () => { restoreSel(); document.execCommand('styleWithCSS', false, true); document.execCommand(cmd, false, input.value); document.execCommand('styleWithCSS', false, false); markDirty(); });
  colour('foreColor', $('#fcolor')); colour('hiliteColor', $('#hcolor'));

  // ---------- focus mode ----------
  A.focus = () => { const on = document.body.classList.toggle('focusmode'); $('#unfocus').hidden = !on; if (on) { restoreSel(); } };
  $('#unfocus').onclick = A.focus;
  window.addEventListener('keydown', e => { if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'f') { e.preventDefault(); A.focus(); } else if (e.key === 'Escape' && document.body.classList.contains('focusmode') && !$('#modals').children.length) A.focus(); });

  // ---------- recent files / open from outside ----------
  const rec = $('#recent');
  const fillRecent = async () => { const list = await api.recent(); rec.replaceChildren(el('option', { value: '', text: list.length ? 'Recent…' : 'Recent (none)' }), ...list.map(p => el('option', { value: p, title: p, text: p.split(/[\\/]/).pop() }))); };
  rec.addEventListener('mousedown', fillRecent); rec.addEventListener('focus', fillRecent);
  rec.onchange = async () => { const p = rec.value; rec.value = ''; if (!p) return; if (state.dirty && !confirm('Discard unsaved changes?')) return; const r = await api.openPath(p); if (r) loadDoc(r.doc, r.path); };
  if (api.onOpen) api.onOpen(r => { if (state.dirty && !confirm('Discard unsaved changes and open ' + r.path.split(/[\\/]/).pop() + '?')) return; loadDoc(r.doc, r.path); });

  // ---------- drag fonts onto the window ----------
  const dz = $('#dropzone'), hasFiles = e => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
  window.addEventListener('dragenter', e => { if (hasFiles(e)) { e.preventDefault(); dz.hidden = false; } });
  window.addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); });
  window.addEventListener('dragleave', e => { if (!e.relatedTarget) dz.hidden = true; });
  window.addEventListener('drop', e => { e.preventDefault(); dz.hidden = true; const fs = [...(e.dataTransfer?.files || [])]; if (fs.length) Fonts.installFiles(fs); });

  // ---------- HTML export (self-contained page with the fonts it needs) ----------
  const MIME = { ttf: 'font/ttf', otf: 'font/otf', woff: 'font/woff' };
  const EXPORT_CSS = 'body{margin:0;background:#eceef1}article{box-sizing:border-box;max-width:var(--w);margin:24px auto;background:#fff;color:#111;padding:var(--m);overflow-wrap:anywhere}article p{margin:0 0 .4em}article h1{font-size:1.8em;margin:.2em 0;text-align:center}article h2{font-size:1.3em;margin:.2em 0}article blockquote{margin:.4em 1.5em;border-inline-start:3px solid #bbb;padding-inline-start:.8em}article table{border-collapse:collapse;width:100%}article td,article th{border:1px solid #888;padding:6px}article img{max-width:100%}article hr{border:0;border-top:1px dashed #aaa}.sher{display:flex;justify-content:center;gap:3em;margin:.5em 0}.sher>div{flex:0 1 42%;text-align:center}@media print{body{background:#fff}article{margin:0;max-width:none;padding:0}}';
  function sanitize(html) { // the document may come from a file: drop scripts, event handlers and javascript: links before writing a web page
    const t = document.createElement('template'); t.innerHTML = html;
    t.content.querySelectorAll('script,iframe,object,embed,link,meta,base,form').forEach(n => n.remove());
    t.content.querySelectorAll('*').forEach(n => { for (const a of [...n.attributes]) if (/^on/i.test(a.name) || (/^(href|src|xlink:href|action|formaction)$/i.test(a.name) && /^\s*javascript:/i.test(a.value))) n.removeAttribute(a.name); });
    return t.innerHTML;
  }
  // every font the document needs, as {family, weight, italic, ext, data(base64)} — bundled + installed + embedded; licence-restricted ones are skipped
  async function gatherFonts() {
    const out = [], blocked = [], fams = Fonts.usedFamilies();
    if (fams.some(f => Fonts.installed.some(i => i.family === f && i.urdu && i.urdu.known && !i.urdu.ok)) && !fams.includes(Fonts.BUNDLED[0])) fams.push(Fonts.BUNDLED[0]); // Urdu fallback
    for (const fam of fams) {
      if (Fonts.BUNDLED.includes(fam)) { const u8 = await api.bundledFont(fam); if (u8) out.push({ family: fam, weight: '400 700', italic: false, ext: 'ttf', data: Fonts.b64(u8) }); continue; }
      const inst = Fonts.installed.filter(i => i.family === fam);
      for (const i of inst) { if (!i.embeddable) { blocked.push(fam); continue; } out.push({ family: fam, weight: i.weight, italic: i.italic, ext: i.ext.replace('.', ''), data: Fonts.b64(await api.fontData(i.id)) }); }
      if (!inst.length) Fonts.session.filter(s => s.family === fam).forEach(s => out.push({ family: fam, weight: s.weight, italic: s.italic, ext: (s.ext || 'ttf').replace('.', ''), data: s.data }));
    }
    return { fonts: out, blocked: [...new Set(blocked)] };
  }
  window.gatherFonts = gatherFonts; window.sanitizeHtml = sanitize; window.EXPORT_CSS = EXPORT_CSS;
  async function buildHtml() {
    const d = dims(), p = state.page, g = await gatherFonts(), faces = g.fonts.map(f => `@font-face{font-family:"${f.family.replace(/"/g, '')}";src:url(data:${MIME[f.ext] || 'font/ttf'};base64,${f.data}) format("${f.ext === 'otf' ? 'opentype' : f.ext === 'woff' ? 'woff' : 'truetype'}");font-weight:${f.weight};font-style:${f.italic ? 'italic' : 'normal'}}`), blocked = g.blocked;
    const fam = p.font ? `"${p.font.replace(/"/g, '')}",` : '', css = faces.join('\n') + `\narticle{--w:${Math.round(d.w)}px;--m:${p.margin}mm;font-family:${fam}"Noto Nastaliq Urdu","Noto Naskh Arabic",serif;font-size:${p.fontSize || 18}pt;line-height:${p.lineHeight || 1.8};column-count:${p.columns || 1};column-gap:12mm}\n` + EXPORT_CSS + '\n' + StyleCss.build(state.styles, ['article']);
    const title = ($('#docname').textContent || 'Untitled').replace(/\.udani$/, '').replace(/[<>&]/g, '');
    return { blocked, html: `<!doctype html>\n<html lang="ur" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="generator" content="UrduOfDani ${window.BRAND.version}"><title>${title}</title><style>${css}</style></head><body><article>${sanitize(stripChunks(ed.innerHTML))}</article></body></html>` };
  }
  A.html = async () => { UI.toast('Building web page…', 1500); const r = await buildHtml(); if (r.blocked.length) UI.toast('Fonts that forbid embedding were left out: ' + r.blocked.join(', '), 8000); const p = await api.exportHtml(r.html); if (p) UI.toast('Web page exported — fonts are embedded, open it in any browser'); };

  // ---------- command palette (Ctrl+K) ----------
  const ACTIONS = [['New document', 'new'], ['Open…', 'open'], ['Save', 'save'], ['Save as…', 'saveas'], ['Export PDF', 'pdf'], ['Print preview', 'preview'], ['Export web page (HTML)', 'html'], ['Export EPUB e-book', 'epub'], ['Text tools: Roman→Urdu, Imla, Prose, Poetry', 'texttools'], ['Python plugins', 'plugins'], ['Export plain text', 'txt'], ['Print', 'print'],
    ['Find & replace', 'find'], ['Insert table', 'table'], ['Insert image', 'image'], ['Insert page break', 'hr'], ['Insert sher (couplet) / make couplets from selected lines', 'sher'], ['Fonts: install & manage', 'fonts'], ['Paragraph styles: create & edit', 'styles'],
    ['Keys & symbols panel (harakat, ﷺ ﷲ ؓ ؑ)', 'osk'], ['Focus mode (hide toolbars)', 'focus'], ['Switch dark / light theme', 'theme'], ['Right-to-left paragraph', 'rtl'], ['Left-to-right paragraph', 'ltr'], ['About UrduOfDani', 'about']];
  function commands() {
    const c = ACTIONS.map(([t, a]) => ({ t, run: () => A[a]() }));
    for (const [v, t] of [['off', 'system'], ['smart', 'smart Roman-Urdu'], ['phon', 'phonetic']]) c.push({ t: `Keyboard: ${t}`, run: () => { const s = $('#kb'); s.value = v; s.onchange({ target: s }); } });
    c.push({ t: 'Digits: Urdu ۱۲۳', run: () => { $('#digits').value = 'urdu'; $('#digits').onchange({ target: $('#digits') }); } }, { t: 'Digits: Western 123', run: () => { $('#digits').value = 'latin'; $('#digits').onchange({ target: $('#digits') }); } });
    for (const s of ['A4', 'A5', 'A3', 'Letter', 'Legal']) c.push({ t: `Page size: ${s}`, run: () => { $('#psize').value = s; $('#psize').onchange({ target: $('#psize') }); } });
    for (const z of [50, 75, 100, 125, 150, 200]) c.push({ t: `Zoom ${z}%`, run: () => { $('#zoom').value = z; $('#zoom').oninput(); } });
    for (const [k, t] of [...$('#tpl').options].filter(o => o.value).map(o => [o.value, o.textContent])) c.push({ t: `Template: ${t}`, run: () => { $('#tpl').value = k; $('#tpl').onchange({ target: $('#tpl') }); } });
    [...new Set([...Fonts.BUNDLED, ...Fonts.installed.map(i => i.family), ...Fonts.session.map(i => i.family)])].forEach(f => c.push({ t: `Font: ${f}`, run: () => applyFont(f) }));
    Object.entries(state.styles).forEach(([id, s]) => c.push({ t: `Style: ${s.name}`, run: () => Styles.applyTo('ps:' + id) }));
    return c;
  }
  A.palette = () => {
    const all = commands(); let shown = all, idx = 0;
    const input = el('input', { type: 'search', placeholder: 'Type a command… (fonts, styles, page size, export…)', 'aria-label': 'Command' }), list = el('div', { class: 'plist', role: 'listbox' });
    const draw = () => { list.replaceChildren(...shown.slice(0, 40).map((c, i) => el('div', { class: 'pitem' + (i === idx ? ' on' : ''), text: c.t, onmousedown: e => { e.preventDefault(); run(c); } }))); const on = list.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest' }); };
    const run = c => { UI.modal.close(); setTimeout(() => { restoreSel(); c.run(); }, 0); };
    input.oninput = () => { const w = input.value.toLowerCase().split(/\s+/).filter(Boolean); shown = all.filter(c => w.every(x => c.t.toLowerCase().includes(x))); idx = 0; draw(); };
    input.onkeydown = e => { if (e.key === 'ArrowDown') { idx = Math.min(idx + 1, Math.min(shown.length, 40) - 1); draw(); e.preventDefault(); } else if (e.key === 'ArrowUp') { idx = Math.max(0, idx - 1); draw(); e.preventDefault(); } else if (e.key === 'Enter' && shown[idx]) { e.preventDefault(); e.stopPropagation(); run(shown[idx]); } };
    draw(); UI.modal({ title: 'Commands', body: el('div', { class: 'pal' }, input, list), buttons: [], cls: 'palette' });
  };
  window.addEventListener('keydown', e => { if (e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 'k') { e.preventDefault(); if (!$('#modals').children.length) A.palette(); } });
})();
