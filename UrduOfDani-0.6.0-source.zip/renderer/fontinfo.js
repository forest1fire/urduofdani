// Font inspector (TrueType / OpenType / WOFF). Works in Node (main process) and in the browser (renderer).
// It only reads the few tables it needs (name, OS/2, cmap) through a `source`, so even a 20 MB system font costs a few KB of I/O.
//   source = { size, read(offset, length) -> Promise<Uint8Array>, inflate?(u8) -> Promise<u8> }
// Reports: family / style, CSS weight + italic, whether the licence allows embedding (OS/2 fsType), and Urdu glyph coverage.
(function (root, factory) { if (typeof module !== 'undefined' && module.exports) module.exports = factory(); else root.FontInfo = factory(); })(this, function () {
  'use strict';
  // Letters a font needs for ordinary Urdu text. `core` are the Urdu-specific forms that plain Arabic fonts usually lack.
  const URDU_CORE = { 'ٹ': 'ٹ', 'پ': 'پ', 'چ': 'چ', 'ڈ': 'ڈ', 'ڑ': 'ڑ', 'ژ': 'ژ', 'ک': 'ک', 'گ': 'گ', 'ں': 'ں', 'ھ': 'ھ', 'ہ': 'ہ', 'ی': 'ی', 'ے': 'ے' };
  const URDU_BASE = 'ابتثجحخدذرزسشصضطظعغفقلمنوءآأؤئ'; // Arabic block letters used in Urdu
  const URDU_PUNCT = '۔،؟'; // full stop, comma, question mark
  const URDU_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

  const u16 = (b, o) => (b[o] << 8) | b[o + 1];
  const u32 = (b, o) => ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
  const tagOf = (b, o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);

  async function readTables(src) {
    const head = await src.read(0, 14); if (head.length < 12) throw new Error('File is too small to be a font');
    const sig = tagOf(head, 0);
    if (sig === 'ttcf') throw new Error('Font collections (.ttc) are not supported - extract a single font first');
    if (sig === 'wOF2') return { kind: 'woff2', tables: null };
    const isWoff = sig === 'wOFF';
    if (!isWoff && !(u32(head, 0) === 0x00010000 || sig === 'OTTO' || sig === 'true')) throw new Error('Not a TrueType/OpenType/WOFF font file');
    const n = isWoff ? u16(head, 12) : u16(head, 4); if (!n || n > 200) throw new Error('Corrupt font table directory');
    const entry = isWoff ? 20 : 16, dir = await src.read(isWoff ? 44 : 12, n * entry), tables = {};
    for (let i = 0; i < n; i++) {
      const o = i * entry, tag = tagOf(dir, o);
      if (isWoff) tables[tag] = { offset: u32(dir, o + 4), length: u32(dir, o + 8), orig: u32(dir, o + 12) };
      else tables[tag] = { offset: u32(dir, o + 8), length: u32(dir, o + 12), orig: u32(dir, o + 12) };
    }
    const get = async (tag, max) => {
      const t = tables[tag]; if (!t) return null;
      if (isWoff && t.length < t.orig) { if (!src.inflate) return null; return src.inflate(await src.read(t.offset, t.length)); }
      return src.read(t.offset, Math.min(t.length, max || t.length));
    };
    return { kind: isWoff ? 'woff' : (sig === 'OTTO' ? 'otf' : 'ttf'), tables, get };
  }

  function decodeName(b, o, len, platform) {
    if (platform === 3 || platform === 0) { let s = ''; for (let i = 0; i + 1 < len; i += 2) s += String.fromCharCode(u16(b, o + i)); return s; }
    let s = ''; for (let i = 0; i < len; i++) s += String.fromCharCode(b[o + i]); return s;
  }
  function parseName(b) {
    const count = u16(b, 2), so = u16(b, 4), best = {};
    for (let i = 0; i < count; i++) {
      const r = 6 + i * 12, plat = u16(b, r), lang = u16(b, r + 4), id = u16(b, r + 6), len = u16(b, r + 8), off = so + u16(b, r + 10);
      if (off + len > b.length) continue;
      const score = (plat === 3 ? 2 : plat === 0 ? 1 : 0) * 10 + (lang === 0x409 || lang === 0 ? 5 : 0);
      if (!best[id] || score > best[id].score) best[id] = { score, v: decodeName(b, off, len, plat).replace(/\0/g, '').trim() };
    }
    const g = id => best[id] && best[id].v;
    return { family: g(16) || g(1), style: g(17) || g(2), full: g(4), ps: g(6) };
  }

  // cmap -> function(codepoint) -> boolean. Supports formats 4 and 12, the two used by practically every font.
  function parseCmap(b) {
    const n = u16(b, 2); let pick = null;
    for (let i = 0; i < n; i++) {
      const plat = u16(b, 4 + i * 8), enc = u16(b, 6 + i * 8), off = u32(b, 8 + i * 8);
      const fmt = off + 2 <= b.length ? u16(b, off) : -1; if (fmt !== 4 && fmt !== 12) continue;
      const rank = (plat === 3 && enc === 10 ? 4 : plat === 0 && fmt === 12 ? 3 : plat === 3 && enc === 1 ? 2 : plat === 0 ? 1 : 0);
      if (!pick || rank > pick.rank) pick = { rank, off, fmt };
    }
    if (!pick) return null;
    const o = pick.off;
    if (pick.fmt === 12) {
      const ng = u32(b, o + 12);
      return cp => { let lo = 0, hi = ng - 1; while (lo <= hi) { const m = (lo + hi) >> 1, g = o + 16 + m * 12, s = u32(b, g), e = u32(b, g + 4); if (cp < s) hi = m - 1; else if (cp > e) lo = m + 1; else return u32(b, g + 8) + (cp - s) !== 0; } return false; };
    }
    const sc = u16(b, o + 6) >> 1, endO = o + 14, startO = endO + sc * 2 + 2, deltaO = startO + sc * 2, rangeO = deltaO + sc * 2;
    return cp => {
      if (cp > 0xFFFF) return false;
      for (let i = 0; i < sc; i++) {
        if (u16(b, endO + i * 2) < cp) continue;
        const s = u16(b, startO + i * 2); if (s > cp) return false;
        const ro = u16(b, rangeO + i * 2), d = u16(b, deltaO + i * 2);
        if (ro === 0) return ((cp + d) & 0xFFFF) !== 0;
        const p = rangeO + i * 2 + ro + (cp - s) * 2; if (p + 2 > b.length) return false;
        const g = u16(b, p); return g !== 0 && ((g + d) & 0xFFFF) !== 0;
      }
      return false;
    };
  }

  function coverage(has) {
    if (!has) return { known: false };
    const miss = s => [...s].filter(c => !has(c.codePointAt(0)));
    const core = miss(Object.keys(URDU_CORE).join('')), base = miss(URDU_BASE), punct = miss(URDU_PUNCT), digits = miss(URDU_DIGITS);
    return { known: true, ok: core.length === 0 && base.length === 0 && punct.length === 0, missing: [...core, ...base, ...punct], digits: digits.length === 0,
      arabic: base.length <= 2, latin: has(0x61) && has(0x41) };
  }

  async function inspect(src) {
    const t = await readTables(src), out = { format: t.kind, family: null, style: null, weight: 400, italic: false, fsType: 0, embeddable: true, urdu: { known: false } };
    if (!t.tables) return out; // woff2: caller falls back to the file name
    const name = await t.get('name', 65536); if (name) Object.assign(out, parseName(name));
    const os2 = await t.get('OS/2', 96);
    if (os2 && os2.length >= 64) { out.weight = Math.min(900, Math.max(100, u16(os2, 4) || 400)); out.fsType = u16(os2, 8); out.italic = !!(u16(os2, 62) & 1); }
    out.embeddable = !(out.fsType & 0x0002); // bit 1 = "Restricted License embedding": the author forbids putting it in documents
    out.urdu = coverage(await t.get('cmap', 1 << 20).then(c => c && parseCmap(c)).catch(() => null));
    return out;
  }

  const fromBytes = (u8, extra) => ({ size: u8.length, read: async (o, l) => u8.subarray(o, o + l), ...(extra || {}) });
  return { inspect, fromBytes, parseName, parseCmap, URDU_CORE: Object.keys(URDU_CORE).join('') };
});
