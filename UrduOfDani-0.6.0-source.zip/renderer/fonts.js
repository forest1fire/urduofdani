'use strict';
// Font manager: install your own fonts, preview them, check Urdu support, embed them in documents.
// Relies on globals from app.js (ed, state, markDirty, restoreSel, applyPage, applyFont) only at call time.
const Fonts = (() => {
  const { el } = UI;
  const BUNDLED = ['Noto Nastaliq Urdu', 'Noto Naskh Arabic'];
  const COMMON = ['Jameel Noori Nastaleeq', 'Alvi Nastaleeq', 'Segoe UI', 'Arial', 'Times New Roman', 'Tahoma'];
  const SAMPLE = 'اردو زبان کی خوبصورتی';
  let ready = false, installed = [], session = [], sys = null /* [{family, fds}] */, sysNames = [], loaded = new Map(), urduCache = new Map(), b64cache = new Map(), managerRender = null;
  try { sysNames = JSON.parse(localStorage.getItem('ud.sysfonts') || '[]'); } catch {}
  const key = f => f.family + '|' + (f.weight || 400) + '|' + (f.italic ? 'i' : 'n');
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const cssFam = f => `"${f.replace(/"/g, '')}"`;

  function register(f, getBytes) { // idempotent, cached by family+weight+style
    const k = key(f); if (loaded.has(k)) return loaded.get(k);
    const p = (async () => { const ff = new FontFace(f.family, await getBytes(), { weight: String(f.weight || 400), style: f.italic ? 'italic' : 'normal' }); await ff.load(); document.fonts.add(ff); return ff; })();
    p.catch(() => loaded.delete(k)); loaded.set(k, p); return p;
  }
  const regInstalled = e => register(e, () => api.fontData(e.id));
  async function init() { installed = await api.fontList(); await Promise.allSettled(installed.map(regInstalled)); ready = true; refreshPicker(); }
  async function reload() { installed = await api.fontList(); await Promise.allSettled(installed.map(regInstalled)); refreshPicker(); if (managerRender) managerRender(); }

  // fonts carried inside an opened document (kept for this session; offer to install)
  function loadSession(list) {
    session = (list || []).filter(f => f && f.family && f.data);
    return Promise.allSettled(session.filter(f => !installed.some(i => key(i) === key(f))).map(f => register(f, async () => unb64(f.data)))).then(refreshPicker);
  }

  function usedFamilies() {
    const set = new Set(), add = f => { f = (f || '').split(',')[0].replace(/["']/g, '').trim(); if (f) set.add(f); };
    add(state.page.font || BUNDLED[0]); Object.values(state.styles).forEach(s => add(s.font));
    ed.querySelectorAll('[style*="font-family"],font[face]').forEach(e => add(e.style.fontFamily || e.getAttribute('face')));
    return [...set];
  }
  // Fonts to embed in a .udani: used + user-installed (never the bundled Noto fonts) + licence permits.
  async function embedPayload() {
    const out = [], blocked = new Set();
    for (const fam of usedFamilies()) {
      if (BUNDLED.includes(fam)) continue;
      for (const e of installed.filter(i => i.family === fam)) {
        if (!e.embeddable) { blocked.add(fam); continue; }
        if (!b64cache.has(e.id)) b64cache.set(e.id, b64(await api.fontData(e.id)));
        out.push({ family: e.family, weight: e.weight, italic: e.italic, ext: e.ext, data: b64cache.get(e.id) });
      }
      if (!installed.some(i => i.family === fam)) session.filter(s => s.family === fam).forEach(s => out.push(s));
    }
    return { fonts: out, blocked: [...blocked] };
  }
  // Is this family usable? (document.fonts.check() says "true" for unknown names, so measure text against generic fallbacks instead)
  let probeCtx = null; const probeCache = new Map();
  function systemHas(fam) {
    if (probeCache.has(fam)) return probeCache.get(fam);
    if (sysNames.includes(fam)) return true;
    probeCtx = probeCtx || document.createElement('canvas').getContext('2d'); let has = false;
    for (const sample of ['mmmmmmmmmmlli', 'ابپتٹجچحخ']) for (const base of ['monospace', 'serif', 'sans-serif']) {
      probeCtx.font = `72px ${base}`; const w0 = probeCtx.measureText(sample).width; probeCtx.font = `72px ${cssFam(fam)},${base}`; if (probeCtx.measureText(sample).width !== w0) has = true;
    }
    probeCache.set(fam, has); return has;
  }
  // fonts used but not available here -> names (for the warning)
  function missing() {
    if (!ready) return [];
    return usedFamilies().filter(f => !BUNDLED.includes(f) && !installed.some(i => i.family === f) && !session.some(s => s.family === f) && !systemHas(f));
  }

  // ---- font picker in the toolbar ----
  function refreshPicker() {
    const sel = document.getElementById('font'), cur = sel.value, g = (label, names, mark) => { if (!names.length) return null; const og = el('optgroup', { label }); names.forEach(n => og.append(el('option', { value: n, text: mark && mark[n] ? n + mark[n] : n, style: `font-family:${cssFam(n)},serif` }))); return og; };
    const mine = [...new Set(installed.map(i => i.family))], emb = [...new Set(session.map(s => s.family))].filter(f => !mine.includes(f));
    const sysList = sysNames.length ? sysNames.filter(n => !BUNDLED.includes(n) && !mine.includes(n)) : COMMON.filter(systemHas);
    sel.replaceChildren(el('option', { value: '', text: 'Font…' }), g('Built in', BUNDLED), g('My fonts', mine), g('In this document', emb), g(sysNames.length ? 'Windows fonts' : 'Common fonts', sysList), el('option', { value: '__more', text: '⋯ Install / manage fonts…' }));
    sel.value = [...sel.options].some(o => o.value === cur) ? cur : '';
  }

  // ---- windows fonts (needs a click: queryLocalFonts requires user activation) ----
  async function loadSystem() {
    if (!window.queryLocalFonts) { UI.toast('Windows font list is not available in this build'); return false; }
    try {
      const list = await window.queryLocalFonts(), by = new Map();
      for (const fd of list) { if (!by.has(fd.family)) by.set(fd.family, []); by.get(fd.family).push(fd); }
      sys = [...by].map(([family, fds]) => ({ family, fds })).sort((a, b) => a.family.localeCompare(b.family));
      sysNames = sys.map(s => s.family); try { localStorage.setItem('ud.sysfonts', JSON.stringify(sysNames)); } catch {}
      refreshPicker(); return true;
    } catch (e) { UI.toast('Could not read Windows fonts: ' + (e && e.message || e)); return false; }
  }
  async function checkSystemUrdu(s) {
    if (urduCache.has(s.family)) return urduCache.get(s.family);
    const fd = s.fds.find(f => /regular|normal/i.test(f.style)) || s.fds[0]; let r = { known: false };
    try { const blob = await fd.blob(); r = (await FontInfo.inspect({ size: blob.size, read: async (o, l) => new Uint8Array(await blob.slice(o, o + l).arrayBuffer()) })).urdu; } catch {}
    urduCache.set(s.family, r); return r;
  }

  // ---- installing ----
  function report(results) {
    let n = 0;
    for (const r of results) {
      if (!r.ok) { UI.toast('⚠ ' + r.error, 7000); continue; }
      if (r.duplicate) { UI.toast(`“${r.entry.family}” is already installed`); continue; }
      n++; const e = r.entry, notes = [];
      if (e.urdu && e.urdu.known && !e.urdu.ok) notes.push('⚠ no Urdu letters — English only');
      if (!e.embeddable) notes.push('licence forbids embedding in documents');
      UI.toast(`Installed “${e.family}” ${e.style}` + (notes.length ? ' — ' + notes.join('; ') : ' ✓'), notes.length ? 8000 : 4200);
    }
    return reload().then(() => n);
  }
  const installDialog = async () => report(await api.fontPick());
  async function installFiles(files) {
    const res = [];
    for (const f of files) { if (!/\.(ttf|otf|woff)$/i.test(f.name)) { res.push({ ok: false, error: `"${f.name}": not a .ttf/.otf/.woff font` }); continue; } res.push(await api.fontAddBytes({ name: f.name, bytes: await f.arrayBuffer() })); }
    return report(res);
  }
  async function remove(e) {
    if (!await UI.confirm('Remove font', `Remove “${e.family} ${e.style}” from UrduOfDani? Documents that use it will fall back to another font (unless it is embedded in the file).`, 'Remove')) return;
    await api.fontRemove(e.id); const p = loaded.get(key(e)); if (p) { try { document.fonts.delete(await p); } catch {} loaded.delete(key(e)); } await reload();
  }

  // ---- manager dialog ----
  function badge(txt, cls) { return el('span', { class: 'bdg ' + (cls || ''), text: txt }); }
  const urduBadge = u => !u || !u.known ? badge('Urdu: unknown', 'warn') : u.ok ? badge('Urdu ✓', 'ok') : badge('No Urdu ✗', 'bad');
  function row(family, sub, prev, badges, actions) {
    return el('div', { class: 'frow' }, el('div', { class: 'fprev', dir: 'rtl', lang: 'ur', style: `font-family:${cssFam(family)},serif;font-weight:${prev.weight || 400};font-style:${prev.italic ? 'italic' : 'normal'}`, text: SAMPLE }),
      el('div', { class: 'finfo' }, el('b', { text: family }), el('span', { class: 'mut', text: sub }), el('div', {}, badges)), el('div', { class: 'facts' }, actions));
  }
  function open() {
    const body = el('div', { class: 'fman' }); let q = '';
    const use = fam => { UI.modal.close && UI.modal.close(); restoreSel(); applyFont(fam); };
    const LH = { 'Jameel Noori Nastaleeq': 2.2, 'Mehr Nastaleeq': 2.2, 'Noto Nastaliq Urdu': 1.8 }; // Nastaliq letters are tall: these line heights keep the marks from colliding (adjust to taste)
    const dflt = fam => { state.page.font = fam; let extra = ''; if (LH[fam] && (state.page.lineHeight || 1.8) < LH[fam]) { state.page.lineHeight = LH[fam]; extra = ` Line spacing set to ${LH[fam]} for this Nastaliq font.`; } applyPage(); markDirty(); UI.toast(`“${fam}” is now the default font of this document.` + extra); render(); };
    const render = () => {
      const kids = [];
      kids.push(el('div', { class: 'ftop' }, el('button', { class: 'primary', text: '＋ Install fonts…', onclick: installDialog }), el('button', { text: sys ? 'Refresh Windows fonts' : 'Show Windows fonts', onclick: async () => { if (await loadSystem()) render(); } }),
        el('label', { class: 'chk' }, el('input', { type: 'checkbox', checked: state.page.embedFonts !== false, onchange: e => { state.page.embedFonts = e.target.checked; markDirty(); } }), 'Embed my fonts when saving'),
        el('span', { class: 'mut', text: 'Tip: drag font files onto the window.' })));
      kids.push(el('details', { class: 'howto' }, el('summary', { text: 'How to add more Urdu fonts — free, 3 steps' }), el('ol', {},
        el('li', { text: 'Get the font file (.ttf, .otf or .woff) from the font’s official free source — for example more Noto fonts at fonts.google.com/noto. For Jameel Noori Nastaleeq or Mehr Nastaleeq, download from a source you trust and read its licence first.' }),
        el('li', { text: 'Click “Install fonts…” and choose the file — or just drag the file onto this window. UrduOfDani checks that it really contains the Urdu letters (look for the green “Urdu ✓”).' }),
        el('li', { text: 'Click “Use” for the selected text or “Default” for the whole document. If the licence allows, the font is saved inside your .udani file so it looks the same on any computer.' })), el('div', { class: 'mut', text: 'Noto Nastaliq Urdu and Noto Naskh Arabic are already built in.' })));
      kids.push(el('div', { class: 'fdef mut' }, 'Document default font: ', el('b', { text: state.page.font || BUNDLED[0] }), state.page.font ? el('button', { class: 'lnk', text: 'reset', onclick: () => { state.page.font = ''; applyPage(); markDirty(); render(); } }) : null));
      // built in
      kids.push(el('h4', { text: 'Built in' }), ...BUNDLED.map(f => row(f, 'Included with UrduOfDani · SIL Open Font Licence', {}, [badge('Urdu ✓', 'ok'), badge('Embeddable', 'ok')], [el('button', { text: 'Use', onclick: () => use(f) }), el('button', { text: 'Default', onclick: () => dflt(f) })])));
      kids.push(el('h4', { text: `My fonts (${installed.length})` }));
      if (!installed.length) kids.push(el('p', { class: 'mut', text: 'No fonts installed yet. Click “Install fonts…” or drop .ttf / .otf / .woff files here.' }));
      for (const e of installed) kids.push(row(e.family, `${e.style} · weight ${e.weight} · ${(e.size / 1024).toFixed(0)} KB`, e, [urduBadge(e.urdu), e.embeddable ? badge('Embeddable', 'ok') : badge('Embedding not allowed', 'bad')],
        [el('button', { text: 'Use', onclick: () => use(e.family) }), el('button', { text: 'Default', onclick: () => dflt(e.family) }), el('button', { class: 'danger', text: 'Remove', onclick: () => remove(e) })]));
      const emb = session.filter(s => !installed.some(i => i.family === s.family));
      if (emb.length) {
        kids.push(el('h4', { text: 'Carried by this document (not installed)' }));
        for (const s of emb) kids.push(row(s.family, 'Embedded in the file you opened', s, [badge('Embedded', 'ok')], [el('button', { text: 'Install', onclick: async () => { report([await api.fontAddBytes({ name: s.family + '.' + (s.ext || 'ttf').replace('.', ''), bytes: unb64(s.data) })]); } })]));
      }
      if (sys) {
        const search = el('input', { type: 'search', placeholder: `Search ${sys.length} Windows fonts…`, value: q, oninput: e => { q = e.target.value; renderSys(); } });
        const list = el('div', { class: 'syslist' });
        const renderSys = () => {
          const items = sys.filter(s => !q || s.family.toLowerCase().includes(q.toLowerCase())).slice(0, 60);
          list.replaceChildren(...items.map(s => { const ub = el('span'); const r = row(s.family, `${s.fds.length} style${s.fds.length > 1 ? 's' : ''}`, {}, [ub], [el('button', { text: 'Use', onclick: () => use(s.family) }), el('button', { text: 'Default', onclick: () => dflt(s.family) }), el('button', { text: 'Check Urdu', onclick: async b => { b.target.disabled = true; ub.replaceChildren(urduBadge(await checkSystemUrdu(s))); } })]); return r; }));
          if (!items.length) list.append(el('p', { class: 'mut', text: 'No match.' }));
        };
        kids.push(el('h4', { text: 'Windows fonts' }), el('div', { class: 'mut', text: 'These are installed in Windows, not in UrduOfDani — documents using them are not portable unless the other computer has them too.' }), search, list); renderSys();
      }
      body.replaceChildren(...kids);
    };
    managerRender = render; render();
    UI.modal({ title: 'Fonts', body, wide: true, cls: 'fontsdlg' }).then(() => { managerRender = null; });
  }

  return { init, reload, loadSession, embedPayload, usedFamilies, missing, refreshPicker, installFiles, installDialog, open, BUNDLED, COMMON, cssFam, b64, unb64, get installed() { return installed; }, get session() { return session; }, fontFaceKey: key };
})();
