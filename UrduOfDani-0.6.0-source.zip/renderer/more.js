'use strict';
// Custom keyboard layouts + spell-check (word list supplied by the user). Created by Muhammad Danish [Dani] · DaniLabs.
(() => {
  const { el } = UI;
  // ---------- keyboard layouts ----------
  window.__layouts = {}; window.__layoutNames = {};
  async function loadLayouts() {
    let list = []; try { list = await api.layoutList(); } catch {}
    const sel = $('#kb'), cur = sel.value; sel.querySelectorAll('optgroup.mine').forEach(o => o.remove()); window.__layouts = {}; window.__layoutNames = {};
    const ok = list.filter(l => !l.error); if (ok.length) { const og = el('optgroup', { label: 'My layouts', class: 'mine' }); ok.forEach(l => { const v = 'layout:' + l.file; window.__layouts[v] = l.map; window.__layoutNames[v] = l.name; og.append(el('option', { value: v, text: 'Keyboard: ' + l.name })); }); sel.append(og); }
    if ([...sel.options].some(o => o.value === cur)) sel.value = cur; else { sel.value = 'off'; sel.onchange({ target: sel }); }
    return list;
  }
  A.layouts = async () => {
    const list = await loadLayouts();
    const rows = list.map(l => el('div', { class: 'frow' }, el('div', { class: 'finfo' }, el('b', { text: l.name || l.file }), el('span', { class: 'mut', text: l.error ? l.file : `${l.file} · ${Object.keys(l.map).length} keys` }), l.error ? el('span', { class: 'bad', text: '⚠ ' + l.error }) : el('span', { text: l.description || '' })), el('div'), el('div', { class: 'facts' }, l.error ? null : el('button', { text: 'Use', onclick: () => { UI.modal.close(); const s = $('#kb'); s.value = 'layout:' + l.file; s.onchange({ target: s }); } }))));
    const body = el('div', { class: 'fman' }, el('div', { class: 'ftop' }, el('button', { class: 'primary', text: 'Open layouts folder', onclick: () => api.layoutFolder() }), el('button', { text: 'Refresh', onclick: () => { UI.modal.close(); setTimeout(A.layouts, 0); } })),
      el('p', { class: 'mut', text: 'A layout is a small .json file: {"name": "...", "map": {"a": "ا", "A": "آ", ...}}. Each key is the character your keyboard types (a and A are different keys); the value is the Urdu text to insert (1–8 characters). Copy the example, change it, press Refresh, then pick it in the Keyboard menu. Share layouts by sharing the file.' }), ...(rows.length ? rows : [el('p', { class: 'mut', text: 'No layouts yet — open the folder; an editable example was created there.' })]));
    UI.modal({ title: 'Keyboard layouts', body, wide: true });
  };
  loadLayouts();

  // ---------- spell-check ----------
  let on = false, set = null, ignore = new Set(), timer = 0, count = 0; const stat = $('#st-spell'), btn = $('#spellbtn');
  const MAXCHARS = 300000, supported = !!(window.CSS && CSS.highlights && window.Highlight);
  function runCheck() {
    if (!on || !set) return; if (ed.textContent.length > MAXCHARS) { stat.textContent = 'Spelling: document too large to check live'; CSS.highlights.delete('ud-misspelled'); return; }
    const ranges = [], sel = getSelection(), w = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT);
    for (let n; (n = w.nextNode());) {
      for (const b of Spell.check(set, n.data)) {
        if (ignore.has(Spell.norm(b.word))) continue;
        if (sel.rangeCount && sel.isCollapsed && sel.anchorNode === n && sel.anchorOffset >= b.start && sel.anchorOffset <= b.end && document.activeElement === ed) continue; // do not flag the word being typed
        const r = new Range(); r.setStart(n, b.start); r.setEnd(n, b.end); ranges.push(r);
      }
    }
    count = ranges.length; CSS.highlights.set('ud-misspelled', new Highlight(...ranges)); stat.textContent = `Spelling: ${count} unknown word${count === 1 ? '' : 's'}`;
  }
  const soon = () => { clearTimeout(timer); if (on) timer = setTimeout(() => (window.requestIdleCallback || setTimeout)(runCheck, { timeout: 1500 }), 700); };
  ed.addEventListener('input', soon); document.addEventListener('selectionchange', () => { if (on && document.activeElement === ed) soon(); });
  const _ld = loadDoc; loadDoc = function (...a) { const r = _ld.apply(this, a); soon(); return r; };
  async function enable() {
    if (!supported) { UI.toast('Spell-check needs a newer engine than this build provides'); return; }
    const d = await api.dictLoad(); set = Spell.build(d.words);
    if (set.size < 1000) {
      const go = await UI.modal({ title: 'Spell-check needs a word list', body: el('div', {}, el('p', { text: set.size ? `Only ${set.size} words were found, so most words would be marked as wrong.` : 'No word list was found.' }), el('p', { class: 'mut', text: 'UrduOfDani does not include one. Put one or more .txt files (one Urdu word per line, UTF-8) into the dictionary folder — use a list you are allowed to use — then turn spell-check on again.' })),
        buttons: [{ label: 'Open dictionary folder', value: 'open' }, { label: 'Turn on anyway', value: 'on' }, { label: 'Cancel', value: false, primary: true }] });
      if (go === 'open') api.dictFolder(); if (go !== 'on') { set = null; return; }
    }
    on = true; btn.classList.add('on'); try { localStorage.setItem('ud.spell', '1'); } catch {} UI.toast(`Spell-check on — ${set.size.toLocaleString()} words`); runCheck();
  }
  function disable() { on = false; btn.classList.remove('on'); stat.textContent = ''; try { CSS.highlights.delete('ud-misspelled'); localStorage.setItem('ud.spell', '0'); } catch {} }
  A.spell = () => on ? disable() : enable();
  // right-click on an unknown word: suggestions / add / ignore
  let menu = null; const closeMenu = () => { if (menu) { menu.remove(); menu = null; } };
  document.addEventListener('mousedown', e => { if (menu && !menu.contains(e.target)) closeMenu(); }); window.addEventListener('blur', closeMenu);
  ed.addEventListener('contextmenu', e => {
    if (!on || !set) return; const pos = document.caretPositionFromPoint ? document.caretPositionFromPoint(e.clientX, e.clientY) : null; if (!pos || pos.offsetNode.nodeType !== 3) return;
    const node = pos.offsetNode, off = pos.offset; let hit = null; for (const b of Spell.check(set, node.data)) if (off >= b.start && off <= b.end && !ignore.has(Spell.norm(b.word))) hit = b; if (!hit) return;
    e.preventDefault(); closeMenu(); const r = new Range(); r.setStart(node, hit.start); r.setEnd(node, hit.end); const sug = Spell.suggest(set, hit.word, 5);
    const item = (t, f, cls) => el('div', { class: 'pitem ' + (cls || ''), text: t, onmousedown: ev => { ev.preventDefault(); closeMenu(); f(); } });
    menu = el('div', { class: 'ctxmenu', dir: 'rtl', style: `left:${Math.min(e.clientX, innerWidth - 230)}px;top:${Math.min(e.clientY, innerHeight - 220)}px` },
      ...(sug.length ? sug.map(s => item(s, () => { ed.focus(); const sl = getSelection(); sl.removeAllRanges(); sl.addRange(r); document.execCommand('insertText', false, s); }, 'sug')) : [el('div', { class: 'mut ctxnone', text: 'No suggestions' })]),
      item(`“${hit.word}” — add to my dictionary`, async () => { await api.dictAdd(hit.word); set.add(Spell.norm(hit.word)); runCheck(); UI.toast('Added to your dictionary'); }), item('Ignore (this session)', () => { ignore.add(Spell.norm(hit.word)); runCheck(); }));
    document.body.append(menu);
  });
  try { if (localStorage.getItem('ud.spell') === '1') enable(); } catch {}
})();
