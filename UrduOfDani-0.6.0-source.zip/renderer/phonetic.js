// Phonetic Latin->Urdu keyboards (original mappings). Single source: lib/phonetic.js re-exports this file.
//  - "phon"  : one key -> one letter (Shift gives alternates).
//  - "smart" : same plus Roman-Urdu digraphs (sh, kh, gh, ch, zh, aa, oo, ee, bh, ph, th, jh, dh, Th, Dh, Rh, chh) and H = do-chashmi he (ھ).
(function (root, factory) { const m = factory(); if (typeof module !== 'undefined' && module.exports) module.exports = m; else root.Phon = m; })(this, function () {
  const MAP = {
    a:'ا', b:'ب', c:'چ', d:'د', e:'ے', f:'ف', g:'گ', h:'ہ', i:'ی', j:'ج', k:'ک', l:'ل', m:'م',
    n:'ن', o:'و', p:'پ', q:'ق', r:'ر', s:'س', t:'ت', u:'ُ', v:'و', w:'و', x:'ش', y:'ی', z:'ز',
    A:'آ', B:'بھ', C:'ث', D:'ڈ', E:'ع', F:'ف', G:'غ', H:'ح', I:'ئ', J:'ض', K:'خ', L:'ل', M:'م',
    N:'ں', O:'ۃ', P:'پھ', Q:'ق', R:'ڑ', S:'ص', T:'ٹ', U:'ؤ', V:'ظ', W:'ؤ', X:'ژ', Y:'ی', Z:'ذ',
    ',':'،', ';':'؛', '?':'؟', '.':'۔', '0':'۰','1':'۱','2':'۲','3':'۳','4':'۴','5':'۵','6':'۶','7':'۷','8':'۸','9':'۹'
  };
  const KB_ROWS = ['ضصثقفغعہخحجچ','شسیبلاتنمکگ','ظطزرذدڑٹپوے','ءآأؤئںۃھ۔،؟'];
  const SMART_ONE = { H: 'ھ' }; // overrides of MAP in smart mode
  const DIGRAPH = {
    oo:'و', ee:'ی', sh:'ش', kh:'خ', gh:'غ', ch:'چ', zh:'ژ', aa:'آ', hh:'ح',
    bh:'بھ', ph:'پھ', th:'تھ', jh:'جھ', dh:'دھ', Th:'ٹھ', Dh:'ڈھ', Rh:'ڑھ', chh:'چھ'
  };
  const isDigit = k => k >= '0' && k <= '9';
  // Stateful engine. feed(key) -> {del, ins} | null. del = Urdu characters (UTF-16 units) to delete before inserting `ins`.
  // Call reset() whenever the typing context breaks (space, caret move, backspace, focus change).
  function createSmart(opts) {
    const o = Object.assign({ digits: 'urdu' }, opts); let buf = []; // items: {k: latin keys, out: urdu}
    const one = k => (o.digits === 'latin' && isDigit(k)) ? null : (SMART_ONE[k] || MAP[k] || null);
    return {
      reset() { buf = []; },
      feed(key) {
        const single = one(key); if (single == null) { buf = []; return null; }
        for (let L = 3; L >= 2; L--) { // longest rule first
          let keys = key, n = 0, i = buf.length;
          while (i > 0 && keys.length < L) { i--; keys = buf[i].k + keys; n++; }
          if (keys.length !== L || !DIGRAPH[keys] || n === 0) continue;
          const del = buf.slice(buf.length - n).reduce((s, x) => s + x.out.length, 0);
          buf.splice(buf.length - n, n, { k: keys, out: DIGRAPH[keys] }); if (buf.length > 4) buf.shift();
          return { del, ins: DIGRAPH[keys] };
        }
        buf.push({ k: key, out: single }); if (buf.length > 4) buf.shift();
        return { del: 0, ins: single };
      }
    };
  }
  // Marks & symbols panel (Unicode code points; names help users search)
  const u = (...c) => c.map(x => String.fromCodePoint(x));
  const MARKS = [
    { name: 'Harakat (اعراب)', items: [['زبر', 0x64E], ['زیر', 0x650], ['پیش', 0x64F], ['شد', 0x651], ['جزم', 0x652], ['تنوین زبر', 0x64B], ['تنوین زیر', 0x64D], ['تنوین پیش', 0x64C], ['کھڑی زبر', 0x670], ['کھڑی زیر', 0x656], ['الٹا پیش', 0x657], ['مدّ', 0x653], ['ہمزہ اوپر', 0x654]] },
    { name: 'Honorifics (درود و دعا)', items: [['ﷲ', 0xFDF2], ['ﷺ', 0xFDFA], ['﷽', 0xFDFD], ['صلی اللہ علیہ وسلم (ؐ)', 0x610], ['علیہ السلام (ؑ)', 0x611], ['رحمتہ اللہ علیہ (ؒ)', 0x612], ['رضی اللہ عنہ (ؓ)', 0x613], ['تخلص (ؔ)', 0x614]] },
    { name: 'Punctuation & signs', items: [['ختمہ ۔', 0x6D4], ['کاما ،', 0x60C], ['؛', 0x61B], ['؟', 0x61F], ['٪', 0x66A], ['٫', 0x66B], ['٬', 0x66C], ['٭', 0x66D], ['کشیدہ ـ', 0x640], ['« ', 0xAB], [' »', 0xBB], ['۞', 0x6DE], ['؏', 0x60F]] },
    { name: 'Urdu digits', items: [...'۰۱۲۳۴۵۶۷۸۹'].map(c => [c, c.codePointAt(0)]) }
  ].map(g => ({ name: g.name, items: g.items.map(([label, cp]) => ({ ch: String.fromCodePoint(cp), cp, label })) }));
  return { MAP, KB_ROWS, DIGRAPH, createSmart, MARKS };
});
