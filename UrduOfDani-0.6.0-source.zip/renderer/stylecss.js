// Paragraph-style -> CSS. Pure (no DOM), shared by the editor, HTML export and tests.
// Styles come from files, so every field is validated before it goes into a stylesheet (no CSS injection).
(function (root, factory) { const m = factory(); if (typeof module !== 'undefined' && module.exports) module.exports = m; else root.StyleCss = m; })(this, function () {
  const ALIGN = ['', 'right', 'center', 'left', 'justify'];
  const num = (v, a, b, d) => { v = parseFloat(v); return isFinite(v) ? Math.min(b, Math.max(a, v)) : d; };
  function clean(s) {
    s = s || {};
    return { name: String(s.name || 'Style').replace(/[<>&"'`]/g, '').slice(0, 40) || 'Style', font: String(s.font || '').replace(/[^\w \-.()؀-ۿݐ-ݿ]/g, '').slice(0, 60),
      size: num(s.size, 4, 400, 0), lh: num(s.lh, 0.8, 6, 0), color: /^#[0-9a-f]{3,8}$/i.test(s.color || '') ? s.color : '', align: ALIGN.includes(s.align) ? s.align : '',
      bold: !!s.bold, italic: !!s.italic, before: num(s.before, 0, 300, 0), after: num(s.after, 0, 300, 0) };
  }
  const validId = id => /^[a-z0-9]{1,12}$/.test(id);
  // scopes: selector prefixes, e.g. ['#editor', '.sprev'] ; '' for a standalone page
  function build(styles, scopes) {
    scopes = scopes || ['#editor'];
    return Object.entries(styles || {}).filter(([id]) => validId(id)).map(([id, raw]) => {
      const s = clean(raw), d = [];
      if (s.font) d.push(`font-family:"${s.font}","Noto Nastaliq Urdu","Noto Naskh Arabic",serif`);
      if (s.size) d.push(`font-size:${s.size}pt`);
      if (s.lh) d.push(`line-height:${s.lh}`);
      if (s.color) d.push(`color:${s.color}`);
      if (s.align) d.push(`text-align:${s.align}`);
      if (s.bold) d.push('font-weight:700');
      if (s.italic) d.push('font-style:italic');
      if (s.before) d.push(`margin-top:${s.before}pt`);
      if (s.after) d.push(`margin-bottom:${s.after}pt`);
      return scopes.map(sc => `${sc} .ps-${id}`.trim()).join(',') + `{${d.join(';')}}`;
    }).join('\n');
  }
  const cleanAll = styles => { const o = {}; for (const [id, s] of Object.entries(styles || {})) if (validId(id)) o[id] = clean(s); return o; };
  return { clean, cleanAll, build, validId, ALIGN };
});
