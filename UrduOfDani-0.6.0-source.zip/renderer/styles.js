'use strict';
// Named paragraph styles: define once, apply to many paragraphs, edit the style and every paragraph follows.
// Stored in the .udani file ("styles"); paragraphs carry class="ps-<id>".
const isBlockHost = n => n.parentNode === ed || (n.parentNode && n.parentNode.classList && n.parentNode.classList.contains('chunk'));
function blockOf(n) { while (n && n !== ed && !isBlockHost(n)) n = n.parentNode; return n && n !== ed && n.nodeType === 1 ? n : null; }
function nextBlock(b) { let n = b.nextElementSibling; if (!n && b.parentNode.classList.contains('chunk')) { let c = b.parentNode.nextElementSibling; while (c && !c.firstElementChild) c = c.nextElementSibling; n = c && c.firstElementChild; } return n; }
function selectedBlocks() { // top-level blocks touched by the selection (works through the big-document chunk wrappers)
  const s = getSelection(); if (!s.rangeCount) return []; const r = s.getRangeAt(0); if (!ed.contains(r.commonAncestorContainer)) return [];
  const pick = (c, o, end) => c.nodeType === 1 ? (c.childNodes[end ? Math.max(0, o - 1) : o] || c) : c;
  const a = blockOf(pick(r.startContainer, r.startOffset, false)); let z = blockOf(pick(r.endContainer, r.endOffset, true)); if (!a) return []; if (!z) z = a;
  const out = []; for (let b = a, g = 0; b && g < 200000; b = nextBlock(b), g++) { out.push(b); if (b === z) break; }
  if (out.length > 1 && !r.collapsed && r.endOffset === 0 && (r.endContainer === z || r.endContainer === z.firstChild)) out.pop(); // selection ends exactly at the start of the next block
  return out;
}
const Styles = (() => {
  const { el } = UI;
  const BUILTIN = [['p', 'Normal'], ['h1', 'Title'], ['h2', 'Heading'], ['blockquote', 'Quote']];
  let tag, n = 0; const SAMPLE = 'یہ ایک نمونہ عبارت ہے — Sample 123';
  const cls = id => 'ps-' + id, clsRe = /(^|\s)ps-[a-z0-9]+(?=\s|$)/g;
  function apply() { if (!tag) { tag = document.createElement('style'); tag.id = 'userstyles'; document.head.append(tag); } tag.textContent = StyleCss.build(state.styles, ['#editor', '.sprev']); }
  function refreshSelect() {
    const sel = $('#pstyle'), cur = sel.value, my = Object.entries(state.styles).sort((a, b) => a[1].name.localeCompare(b[1].name));
    sel.replaceChildren(...BUILTIN.map(([v, t]) => el('option', { value: v, text: t })));
    if (my.length) { const og = el('optgroup', { label: 'My styles' }); my.forEach(([id, s]) => og.append(el('option', { value: 'ps:' + id, text: s.name }))); sel.append(og); }
    sel.append(el('option', { value: '__edit', text: '⋯ Create / edit styles…' })); sel.value = [...sel.options].some(o => o.value === cur) ? cur : 'p';
  }
  const stripCls = b => { b.className = b.className.replace(clsRe, '').trim(); if (!b.className) b.removeAttribute('class'); };
  function applyTo(id) { // id: 'ps:<id>' or built-in tag
    ed.focus();
    if (id.startsWith('ps:')) { const sid = id.slice(3); selectedBlocks().forEach(b => { stripCls(b); b.classList.add(cls(sid)); }); markDirty(); }
    else { document.execCommand('formatBlock', false, id); selectedBlocks().forEach(stripCls); markDirty(); }
  }
  function reflect() { // show the style of the paragraph under the caret
    const s = getSelection(); if (!s.anchorNode || !ed.contains(s.anchorNode)) return; const b = blockOf(s.anchorNode); if (!b) return;
    const m = /(?:^|\s)ps-([a-z0-9]+)/.exec(b.className || ''), sel = $('#pstyle');
    sel.value = m && state.styles[m[1]] ? 'ps:' + m[1] : (BUILTIN.some(x => x[0] === b.localName) ? b.localName : 'p');
  }
  const rgb2hex = c => { const m = /(\d+)[, ]+(\d+)[, ]+(\d+)/.exec(c); return m ? '#' + [m[1], m[2], m[3]].map(x => (+x).toString(16).padStart(2, '0')).join('') : ''; };
  function fromSelection() {
    const b = selectedBlocks()[0]; const cs = b ? getComputedStyle(b) : getComputedStyle(ed), px = parseFloat(cs.fontSize);
    return { name: 'New style', font: cs.fontFamily.split(',')[0].replace(/["']/g, '').trim(), size: Math.round(px * 0.75 * 2) / 2, lh: cs.lineHeight === 'normal' ? 0 : Math.round(parseFloat(cs.lineHeight) / px * 10) / 10,
      color: rgb2hex(cs.color) === '#111111' ? '' : rgb2hex(cs.color), align: ['right', 'center', 'left', 'justify'].includes(cs.textAlign) ? cs.textAlign : '', bold: +cs.fontWeight >= 600, italic: cs.fontStyle === 'italic', before: 0, after: 0 };
  }
  const newId = () => { let id; do { id = 's' + (Date.now() + (n++)).toString(36).slice(-6); } while (state.styles[id]); return id; };

  function open() {
    let cur = Object.keys(state.styles)[0] || null; const body = el('div', { class: 'sted' }), listBox = el('div', { class: 'slist' }), form = el('div', { class: 'sform' });
    const fams = () => [...new Set([...Fonts.BUNDLED, ...Fonts.installed.map(i => i.family), ...Fonts.session.map(i => i.family)])];
    const touch = () => { apply(); refreshSelect(); markDirty(); };
    const renderList = () => { const items = Object.entries(state.styles).map(([id, s]) => el('button', { class: 'sitem' + (id === cur ? ' on' : ''), text: s.name, onclick: () => { cur = id; render(); } }));
      if (!items.length) items.push(el('p', { class: 'mut', text: 'No styles yet. Make one with “New” or “From selection”.' })); listBox.replaceChildren(...items); };
    function renderForm() {
      if (!cur) { form.replaceChildren(el('p', { class: 'mut', text: 'Styles let you format headlines, body text, captions… once, and change them everywhere later.' })); return; }
      const s = state.styles[cur], prev = el('div', { class: 'sprev paper' }, el('div', { class: cls(cur), dir: 'rtl', lang: 'ur', text: SAMPLE }));
      const f = (label, input) => el('label', {}, el('span', { text: label }), input), set = (k, v) => { s[k] = v; touch(); };
      const fontSel = el('select', { onchange: e => set('font', e.target.value) }, el('option', { value: '', text: '(document default)' }), ...fams().map(x => el('option', { value: x, text: x, selected: x === s.font })));
      if (s.font && !fams().includes(s.font)) fontSel.append(el('option', { value: s.font, text: s.font + ' (not installed)', selected: true })); else if (!s.font) fontSel.value = '';
      form.replaceChildren(
        f('Name', el('input', { value: s.name, oninput: e => { s.name = e.target.value.replace(/[<>&"'`]/g, ''); touch(); renderList(); } })), f('Font', fontSel),
        f('Size (pt, 0 = inherit)', el('input', { type: 'number', min: 0, max: 400, step: 0.5, value: s.size || 0, oninput: e => set('size', +e.target.value) })),
        f('Line height (0 = inherit)', el('input', { type: 'number', min: 0, max: 6, step: 0.1, value: s.lh || 0, oninput: e => set('lh', +e.target.value) })),
        f('Colour', el('span', { class: 'inl' }, el('input', { type: 'color', value: s.color || '#111111', oninput: e => set('color', e.target.value) }), el('button', { class: 'lnk', text: 'none', onclick: () => { set('color', ''); renderForm(); } }))),
        f('Alignment', el('select', { onchange: e => set('align', e.target.value) }, ...[['', '(inherit)'], ['right', 'Right'], ['center', 'Centre'], ['left', 'Left'], ['justify', 'Justify']].map(([v, t]) => el('option', { value: v, text: t, selected: v === s.align })))),
        el('div', { class: 'inl' }, el('label', { class: 'chk' }, el('input', { type: 'checkbox', checked: s.bold, onchange: e => set('bold', e.target.checked) }), 'Bold'), el('label', { class: 'chk' }, el('input', { type: 'checkbox', checked: s.italic, onchange: e => set('italic', e.target.checked) }), 'Italic')),
        f('Space before (pt)', el('input', { type: 'number', min: 0, max: 300, value: s.before || 0, oninput: e => set('before', +e.target.value) })), f('Space after (pt)', el('input', { type: 'number', min: 0, max: 300, value: s.after || 0, oninput: e => set('after', +e.target.value) })), prev);
    }
    const render = () => { renderList(); renderForm(); };
    const add = s => { const id = newId(); state.styles[id] = StyleCss.clean(s); cur = id; touch(); render(); };
    const tools = el('div', { class: 'stools' }, el('button', { text: 'New', onclick: () => add({ name: 'New style' }) }), el('button', { text: 'From selection', title: 'Copy the look of the paragraph at the cursor', onclick: () => add(fromSelection()) }),
      el('button', { text: 'Duplicate', onclick: () => { if (cur) add({ ...state.styles[cur], name: state.styles[cur].name + ' copy' }); } }),
      el('button', { class: 'danger', text: 'Delete', onclick: async () => { if (!cur || !await UI.confirm('Delete style', `Delete “${state.styles[cur].name}”? Paragraphs using it return to normal formatting.`, 'Delete')) return; ed.querySelectorAll('.' + cls(cur)).forEach(stripCls); delete state.styles[cur]; cur = Object.keys(state.styles)[0] || null; touch(); render(); } }));
    body.append(el('div', { class: 'scol' }, tools, listBox), form); render();
    return UI.modal({ title: 'Paragraph styles', body, wide: true, buttons: [{ label: 'Apply to selection', value: 'apply' }, { label: 'Done', value: true, primary: true }] }).then(r => { if (r === 'apply' && cur) { restoreSel(); applyTo('ps:' + cur); } layoutSoon(); });
  }
  return { apply, refreshSelect, applyTo, reflect, open, load(styles) { state.styles = StyleCss.cleanAll(styles); apply(); refreshSelect(); } };
})();
