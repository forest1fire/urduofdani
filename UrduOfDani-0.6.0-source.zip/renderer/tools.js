'use strict';
// Text tools (Roman→Urdu, Imla, Prose, Poetry), Python plugins dialog, EPUB export.
// Created by Muhammad Danish [Dani] · DaniLabs — free and open-source.
(() => {
  const { el } = UI, esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const hasSel = () => { const s = getSelection(); return !!(savedRange && !savedRange.collapsed); };
  // Selection.toString() keeps the line breaks between paragraphs (Range.toString() does not); capture it BEFORE a dialog steals focus
  const captureSel = () => { // one line per paragraph (Selection.toString() puts a blank line between <p>s, which poetry mode would read as "new poem")
    restoreSel(); const sel = getSelection(); if (!sel.rangeCount || sel.isCollapsed) return '';
    const frag = sel.getRangeAt(0).cloneContents(), lines = [];
    const walk = n => { if (n.nodeType === 3) { if (n.textContent.trim()) lines.push(n.textContent); return; } if (n.nodeType !== 1) return; if (n.classList.contains('sher')) { [...n.children].forEach(c => lines.push(c.textContent)); return; } if (/^(P|H[1-6]|BLOCKQUOTE|LI|TR)$/.test(n.nodeName)) { lines.push(n.textContent); return; } [...n.childNodes].forEach(walk); };
    [...frag.childNodes].forEach(walk); return lines.length ? lines.join('\n') : sel.toString();
  };
  // Put plain text (or ready HTML) into the document: over the selection, or over everything. One undo step.
  function applyText(text, { whole, html } = {}) {
    restoreSel(); const sel = getSelection();
    if (whole) { const r = document.createRange(); r.selectNodeContents(ed); sel.removeAllRanges(); sel.addRange(r); }
    if (html) document.execCommand('insertHTML', false, html);
    else if (!whole && !text.includes('\n')) document.execCommand('insertText', false, text);
    else document.execCommand('insertHTML', false, text.split('\n').map(l => '<p>' + (esc(l) || '<br>') + '</p>').join(''));
    markDirty();
  }

  // ---------- Text tools ----------
  const MODES = [['roman', 'Roman Urdu → Urdu script'], ['imla', 'Imla clean-up (spelling & punctuation)'], ['prose', 'Prose / Book (paragraphs, ۔ ، ؟)'], ['sher', 'Poetry → couplets (sher layout)'], ['poetry', 'Poetry → one couplet per line (tab separated)']];
  A.texttools = () => {
    const picked = captureSel(); let whole = !picked;
    const mode = el('select', {}, MODES.map(([v, t]) => el('option', { value: v, text: t }))), inp = el('textarea', { rows: 6, placeholder: 'Type or paste text here — or select text in the document first.', dir: 'auto' }),
      out = el('textarea', { rows: 6, readonly: true, dir: 'rtl', lang: 'ur', placeholder: 'Result', class: 'ttout' }), note = el('div', { class: 'mut' }), wholeBox = el('input', { type: 'checkbox', checked: whole });
    inp.value = picked;
    const run = () => {
      const t = wholeBox.checked ? ed.innerText.replace(/\n{3,}/g, '\n\n') : inp.value; if (wholeBox.checked) inp.value = t.length > 20000 ? t.slice(0, 20000) + '…' : t;
      const src = wholeBox.checked ? t : inp.value, m = mode.value; let r = '';
      try { r = m === 'roman' ? UrduText.romanToUrdu(src, { digits: state.digits !== 'latin' }) : m === 'imla' ? UrduText.imla(src) : m === 'prose' ? UrduText.prose(src) : UrduText.poetryText(src); } catch (e) { r = ''; note.textContent = 'Error: ' + e.message; return; }
      out.value = r; note.textContent = m === 'roman' ? 'Common words come from a built-in dictionary; other words are guessed from spelling rules — please proofread. Capital T, D, R mark ٹ ڈ ڑ.' : m === 'imla' ? 'Fixes Arabic-form letters, spacing, punctuation, mark order and a list of common mistakes. Meaning-dependent letters (ہ / ح) are left alone.' : m === 'sher' || m === 'poetry' ? 'Two lines = one couplet. A line with a tab or 3+ spaces in the middle is split there. A blank line starts a new poem.' : 'Joins broken lines into paragraphs and closes long sentences with ۔';
    };
    mode.onchange = inp.oninput = wholeBox.onchange = run; run();
    const copyBtn = el('button', { text: 'Copy result', onclick: async () => { try { await navigator.clipboard.writeText(out.value); UI.toast('Copied — pastes into Word, InDesign, WhatsApp as normal Unicode'); } catch { out.select(); document.execCommand('copy'); UI.toast('Copied'); } } });
    const body = el('div', { class: 'ttools' }, el('label', {}, el('span', { text: 'Tool' }), mode), inp, el('label', { class: 'chk' }, wholeBox, 'Use the whole document'), out, el('div', { class: 'inl' }, copyBtn), note);
    UI.modal({ title: 'Text tools', body, wide: true, buttons: [{ label: 'Close', value: false }, { label: 'Apply to document', value: 'apply', primary: true }] }).then(v => {
      if (v !== 'apply' || !out.value) return; const m = mode.value;
      if (m === 'sher') applyText(out.value, { whole: wholeBox.checked, html: UrduText.poetryHtml(inp.value) });
      else if (m === 'prose') applyText(out.value, { whole: wholeBox.checked, html: UrduText.proseHtml(out.value) });
      else applyText(out.value, { whole: wholeBox.checked });
    });
  };

  // ---------- Python plugins ----------
  A.plugins = async () => {
    const picked = captureSel(); const status = await api.pluginStatus(), list = el('div', { class: 'plist2' }), info = el('div', { class: 'mut' });
    const ctx = mode => ({ mode, app: 'UrduOfDani', version: window.BRAND.version, page: { size: state.page.size, orient: state.page.orient, margin: state.page.margin, columns: state.page.columns } });
    async function runPlugin(file, cls, name, whole) {
      const text = whole ? ed.innerText : picked; if (!whole && !text) { UI.toast('Select some text first, or choose “Whole document”'); return; }
      info.textContent = `Running “${name}”…`; const r = await api.pluginRun({ file, cls, text, context: ctx(whole ? 'document' : 'selection') });
      if (!r || !r.ok) { info.textContent = '⚠ ' + (r && r.error || 'Plugin failed') + ' — your document was not changed.'; info.className = 'mut bad'; return; }
      UI.modal.close(); setTimeout(() => { applyText(r.text, { whole }); UI.toast(`“${name}” applied` + (whole ? ' to the whole document (formatting becomes plain paragraphs; Ctrl+Z undoes)' : '')); }, 0);
    }
    async function load() {
      list.replaceChildren(el('p', { class: 'mut', text: 'Loading…' })); const r = await api.pluginList();
      if (!r.ok) { list.replaceChildren(el('p', { class: 'bad', text: r.error })); return; }
      const rows = [];
      for (const f of r.files) {
        if (f.error && !f.plugins.length) rows.push(el('div', { class: 'frow' }, el('div', { class: 'finfo' }, el('b', { text: f.file }), el('span', { class: 'bad', text: '⚠ ' + f.error })), el('div'), el('div')));
        for (const p of f.plugins) rows.push(el('div', { class: 'frow plug' }, el('div', { class: 'finfo' }, el('b', { text: p.name }), el('span', { class: 'mut', text: `v${p.version || '?'} · ${p.author || 'unknown'} · ${f.file}` }), el('span', { text: p.description || '' }), p.error ? el('span', { class: 'bad', text: '⚠ ' + p.error }) : null), el('div'),
          el('div', { class: 'facts' }, p.error ? null : [el('button', { text: 'Run on selection', onclick: () => runPlugin(f.file, p.cls, p.name, false) }), el('button', { text: 'Whole document', onclick: () => runPlugin(f.file, p.cls, p.name, true) })])));
      }
      list.replaceChildren(...(rows.length ? rows : [el('p', { class: 'mut', text: 'No plugins found. Put .py files in the plugins folder.' })]));
    }
    const head = el('div', { class: 'ftop' }, el('button', { text: 'Open plugins folder', onclick: () => api.pluginFolder() }), el('button', { text: 'Refresh', onclick: load }), el('span', { class: status.python ? 'mut' : 'bad', text: status.python ? status.version + ' found' : 'Python 3 not found — install it free from python.org (tick “Add python.exe to PATH”), then restart.' }));
    const warn = el('p', { class: 'mut', text: 'Plugins are Python programs that run with your Windows permissions. Only use plugins you wrote or trust. Each one runs in its own process with a 15-second limit; if it fails, your document stays untouched.' });
    const guide = el('details', {}, el('summary', { text: 'Write your own plugin' }), el('pre', { class: 'code', text: 'class YourPluginName(UrduOfDaniPlugin):\n    def __init__(self):\n        self.name = "Exact Plugin Name"\n        self.version = "1.0.0"\n        self.author = "Developer Name (or DaniLabs)"\n        self.description = "A concise explanation of what this tool does."\n\n    def execute(self, text: str, context=None) -> str:\n        # Perform custom Unicode operations on the text string here\n        modified_text = text\n        return modified_text' }), el('p', { class: 'mut', text: 'Save it as a .py file in the plugins folder, press Refresh. Wrap risky code in try/except.' }));
    if (status.python) load(); else list.replaceChildren();
    UI.modal({ title: 'Python plugins', body: el('div', { class: 'plug' }, head, warn, list, info, guide), wide: true });
  };

  // ---------- EPUB export ----------
  A.epub = async () => {
    const v = await UI.form('Export EPUB e-book', [{ id: 'title', label: 'Title', value: (state.meta && state.meta.title) || $('#docname').textContent.replace(/\.udani$/, '') }, { id: 'author', label: 'Author', value: (state.meta && state.meta.author) || window.BRAND.creator }], 'Export');
    if (!v) return; state.meta = { ...v }; UI.toast('Building e-book…', 1800);
    const clean = sanitizeHtml(stripChunks(ed.innerHTML)), root = document.createElement('div'); root.innerHTML = clean;
    const images = []; root.querySelectorAll('img').forEach(im => { const m = /^data:(image\/(?:png|jpeg|gif|webp|svg\+xml));base64,(.+)$/.exec(im.getAttribute('src') || ''); if (!m) { im.remove(); return; } const ext = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg' }[m[1]], name = `img${images.length + 1}.${ext}`; images.push({ name, mime: m[1], data: m[2] }); im.setAttribute('src', '../images/' + name); if (!im.hasAttribute('alt')) im.setAttribute('alt', ''); });
    root.querySelectorAll('hr').forEach(h => h.replaceWith(Object.assign(document.createElement('p'), { className: 'pb' }))); // page breaks have no meaning in a reflowable book
    const chapters = []; let cur = null; const ser = new XMLSerializer();
    const strip = html => html.replace(/ xmlns="http:\/\/www\.w3\.org\/1999\/xhtml"/g, '');
    for (const n of [...root.childNodes]) {
      const isH1 = n.nodeType === 1 && n.localName === 'h1';
      if (isH1 || !cur) { cur = { title: isH1 ? n.textContent.trim() || v.title : v.title, parts: [] }; chapters.push(cur); }
      if (n.nodeType === 1) cur.parts.push(strip(ser.serializeToString(n))); else if (n.textContent.trim()) cur.parts.push('<p>' + esc(n.textContent) + '</p>');
    }
    const g = await gatherFonts(), p = state.page, fam = p.font ? `"${p.font.replace(/"/g, '')}",` : '';
    const css = `body{font-family:${fam}"Noto Nastaliq Urdu","Noto Naskh Arabic",serif;line-height:${p.lineHeight || 1.8};margin:5%;text-align:justify}h1{font-size:1.6em;text-align:center;margin:1em 0}h2{font-size:1.25em}p{margin:0 0 .5em}.sher{display:table;margin:.6em auto;width:90%}.sher>div{display:table-cell;text-align:center;width:50%}blockquote{margin:.5em 1.5em}table{border-collapse:collapse;width:100%}td{border:1px solid #888;padding:4px}img{max-width:100%}.pb{page-break-after:always;margin:0}\n` + StyleCss.build(state.styles, ['']);
    const wrap = html => html.replace(/<div xmlns="[^"]*">/, '').replace(/<\/div>$/, '');
    const path = await api.exportEpub({ title: v.title, author: v.author, lang: 'ur', css, fonts: g.fonts, images, chapters: chapters.map(c => ({ title: c.title, body: c.parts.join('\n') })) });
    if (path) UI.toast('E-book exported' + (g.blocked.length ? ' (fonts that forbid embedding were left out: ' + g.blocked.join(', ') + ')' : ' — fonts embedded, right-to-left'), 7000);
  };
})();
