'use strict';
// Small UI helpers: modal dialogs (Electron has no window.prompt) and toasts.
const UI = (() => {
  const el = (tag, attrs, ...kids) => { const n = document.createElement(tag); for (const [k, v] of Object.entries(attrs || {})) { if (k === 'class') n.className = v; else if (k === 'text') n.textContent = v; else if (k.startsWith('on')) n[k] = v; else if (v !== false && v != null) n.setAttribute(k, v === true ? '' : v); } n.append(...kids.flat().filter(x => x != null)); return n; };
  let stack = [];
  // modal({title, body: Node, buttons:[{label, value, primary}], wide, onClose}) -> Promise<value|null>; Esc / backdrop click -> null
  function modal({ title, body, buttons = [{ label: 'Close', value: true, primary: true }], wide, cls }) {
    return new Promise(res => {
      const prevFocus = document.activeElement;
      const done = v => { back.remove(); stack = stack.filter(s => s !== back); document.removeEventListener('keydown', onKey, true); window.__selLock = true; setTimeout(() => { window.__selLock = false; }, 80); // refocusing the editor would overwrite the saved selection (app.js)
      if (prevFocus && prevFocus.focus && prevFocus !== document.body) try { prevFocus.focus({ preventScroll: true }); } catch {} res(v); };
      const onKey = e => { if (stack[stack.length - 1] !== back) return; if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); done(null); } else if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'BUTTON' && e.target.tagName !== 'SELECT') { const p = buttons.find(b => b.primary); if (p) { e.preventDefault(); done(typeof p.value === 'function' ? p.value() : p.value); } } };
      const card = el('div', { class: 'mcard' + (wide ? ' wide' : '') + (cls ? ' ' + cls : ''), role: 'dialog', 'aria-label': title }, el('h3', { text: title }), el('div', { class: 'mbody' }, body),
        buttons.length ? el('div', { class: 'mbtns' }, buttons.map(b => el('button', { class: b.primary ? 'primary' : '', text: b.label, onclick: () => done(typeof b.value === 'function' ? b.value() : b.value) }))) : null);
      const back = el('div', { class: 'mback', onmousedown: e => { if (e.target === back) done(null); } }, card);
      stack.push(back); document.getElementById('modals').append(back); document.addEventListener('keydown', onKey, true);
      const f = card.querySelector('input,select,textarea'); (f || card.querySelector('button.primary') || card).focus && (f || card.querySelector('button.primary') || card).focus();
      modal.close = () => done(null); back.close = done;
    });
  }
  // form('Title', [{id,label,type:'number'|'text'|'select',value,min,max,options}]) -> Promise<{id:value}|null>
  async function form(title, fields, ok = 'OK') {
    const inputs = {}, body = el('div', { class: 'mform' }, fields.map(f => {
      const i = f.type === 'select' ? el('select', {}, f.options.map(o => el('option', { value: o, text: o, selected: String(o) === String(f.value) }))) : el('input', { type: f.type || 'text', value: f.value ?? '', min: f.min, max: f.max });
      inputs[f.id] = i; return el('label', {}, el('span', { text: f.label }), i);
    }));
    const r = await modal({ title, body, buttons: [{ label: 'Cancel', value: false }, { label: ok, primary: true, value: true }] });
    if (!r) return null; const out = {}; for (const f of fields) out[f.id] = f.type === 'number' ? Number(inputs[f.id].value) : inputs[f.id].value; return out;
  }
  function toast(msg, ms = 4200) { const t = el('div', { class: 'toast', text: msg }); const box = document.getElementById('toasts'); box.append(t); while (box.children.length > 4) box.firstChild.remove(); setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, ms); }
  const confirmBox = (title, text, ok = 'OK') => modal({ title, body: el('p', { text }), buttons: [{ label: 'Cancel', value: false }, { label: ok, primary: true, value: true }] });
  return { el, modal, form, toast, confirm: confirmBox };
})();
