// UrduOfDani text engine: Roman→Urdu, Imla clean-up, Prose/Book formatting, Poetry (couplet) layout.
// Pure functions on Unicode strings (no DOM) — used by the editor dialog, the tests, and anything that wants to reuse them.
// Output stays in the Arabic block U+0600–U+06FF (plus ASCII space/newline/tab), so it pastes cleanly into Word, InDesign, Photoshop, WhatsApp…
// Created by Muhammad Danish [Dani] · DaniLabs — free and open-source.
(function (root, factory) { const m = factory(); if (typeof module !== 'undefined' && module.exports) module.exports = m; else root.UrduText = m; })(this, function () {
  'use strict';
  // ---------------- Roman → Urdu ----------------
  // Dictionary of very common words (exact spellings). Anything else goes through the rule engine, which is a best-effort guess:
  // Roman Urdu drops short vowels, so unknown words must be reviewed. Add your own words with the `extra` argument.
  const DICT = {
    hai: 'ہے', hain: 'ہیں', tha: 'تھا', thi: 'تھی', the: 'تھے', ho: 'ہو', hoga: 'ہوگا', hogi: 'ہوگی', hun: 'ہوں', hoon: 'ہوں', hota: 'ہوتا', hoti: 'ہوتی', hote: 'ہوتے',
    kya: 'کیا', kyun: 'کیوں', kyon: 'کیوں', kaise: 'کیسے', kaisa: 'کیسا', kaisi: 'کیسی', kaun: 'کون', kab: 'کب', kahan: 'کہاں', kidhar: 'کدھر', kitna: 'کتنا', kitni: 'کتنی', kitne: 'کتنے',
    main: 'میں', mein: 'میں', mujhe: 'مجھے', mujh: 'مجھ', mera: 'میرا', meri: 'میری', mere: 'میرے', hum: 'ہم', hamara: 'ہمارا', humara: 'ہمارا', hamari: 'ہماری', hamare: 'ہمارے',
    tum: 'تم', tumhara: 'تمہارا', tumhari: 'تمہاری', tumhare: 'تمہارے', tu: 'تو', tera: 'تیرا', teri: 'تیری', tere: 'تیرے', aap: 'آپ', aapka: 'آپ کا', aapki: 'آپ کی', aapke: 'آپ کے',
    wo: 'وہ', woh: 'وہ', ye: 'یہ', yeh: 'یہ', is: 'اس', iss: 'اس', us: 'اس', uss: 'اس', in: 'ان', un: 'ان', unka: 'ان کا', unki: 'ان کی', unke: 'ان کے', iska: 'اس کا', iski: 'اس کی', iske: 'اس کے', uska: 'اس کا', uski: 'اس کی', uske: 'اس کے',
    ka: 'کا', ki: 'کی', ke: 'کے', ko: 'کو', se: 'سے', par: 'پر', pe: 'پر', tak: 'تک', aur: 'اور', ya: 'یا', lekin: 'لیکن', magar: 'مگر', agar: 'اگر', to: 'تو', bhi: 'بھی', hi: 'ہی',
    nahi: 'نہیں', nahin: 'نہیں', na: 'نہ', mat: 'مت', kuch: 'کچھ', sab: 'سب', bahut: 'بہت', bohat: 'بہت', bohot: 'بہت', zyada: 'زیادہ', ziada: 'زیادہ', kam: 'کم',
    acha: 'اچھا', achha: 'اچھا', achi: 'اچھی', achhi: 'اچھی', bura: 'برا', buri: 'بری', naya: 'نیا', nayi: 'نئی', purana: 'پرانا', bara: 'بڑا', bada: 'بڑا', chota: 'چھوٹا', choti: 'چھوٹی',
    ghar: 'گھر', dost: 'دوست', pyar: 'پیار', mohabbat: 'محبت', muhabbat: 'محبت', ishq: 'عشق', dil: 'دل', zindagi: 'زندگی', duniya: 'دنیا', log: 'لوگ', insan: 'انسان', kaam: 'کام', kamaal: 'کمال', kamal: 'کمال',
    shukriya: 'شکریہ', meherbani: 'مہربانی', mehrbani: 'مہربانی', khush: 'خوش', udaas: 'اداس', raat: 'رات', din: 'دن', subah: 'صبح', shaam: 'شام', aaj: 'آج', kal: 'کل', abhi: 'ابھی', phir: 'پھر', kabhi: 'کبھی',
    hamesha: 'ہمیشہ', sirf: 'صرف', bas: 'بس', haan: 'ہاں', ji: 'جی', salam: 'سلام', assalamualaikum: 'السلام علیکم', khuda: 'خدا', allah: 'اللہ', pakistan: 'پاکستان', urdu: 'اردو', zaban: 'زبان', kitab: 'کتاب',
    likhna: 'لکھنا', parhna: 'پڑھنا', dekhna: 'دیکھنا', jana: 'جانا', aana: 'آنا', karna: 'کرنا', kar: 'کر', karo: 'کرو', karta: 'کرتا', karti: 'کرتی', karte: 'کرتے', kiya: 'کیا', gaya: 'گیا', gayi: 'گئی', gaye: 'گئے',
    aaya: 'آیا', aayi: 'آئی', chahiye: 'چاہیے', chahta: 'چاہتا', chahti: 'چاہتی', sakta: 'سکتا', sakti: 'سکتی', sakte: 'سکتے', rahe: 'رہے', raha: 'رہا', rahi: 'رہی', wala: 'والا', wali: 'والی', wale: 'والے',
    naam: 'نام', ab: 'اب', jab: 'جب', tab: 'تب', yahan: 'یہاں', wahan: 'وہاں', andar: 'اندر', bahar: 'باہر', upar: 'اوپر', neeche: 'نیچے', saath: 'ساتھ', liye: 'لیے', lie: 'لیے', bina: 'بغیر', dobara: 'دوبارہ',
    mubarak: 'مبارک', eid: 'عید', ramzan: 'رمضان', dua: 'دعا', shayari: 'شاعری', ghazal: 'غزل', nazm: 'نظم', misra: 'مصرع', shair: 'شاعر', apna: 'اپنا', apni: 'اپنی', apne: 'اپنے', khud: 'خود', kisi: 'کسی', koi: 'کوئی',
    kyunke: 'کیونکہ', kyunki: 'کیونکہ', jaise: 'جیسے', jaisa: 'جیسا', waise: 'ویسے', wese: 'ویسے', bilkul: 'بالکل', theek: 'ٹھیک', thik: 'ٹھیک', sahi: 'صحیح', galat: 'غلط', mushkil: 'مشکل', aasan: 'آسان', sach: 'سچ', jhoot: 'جھوٹ',
    paani: 'پانی', khana: 'کھانا', chai: 'چائے', ek: 'ایک', do: 'دو', teen: 'تین', char: 'چار', panch: 'پانچ', chay: 'چھ', saat: 'سات', aath: 'آٹھ', nau: 'نو', das: 'دس',
    bhai: 'بھائی', behan: 'بہن', chand: 'چاند', sitara: 'ستارہ', dard: 'درد', khwab: 'خواب', raah: 'راہ', tanhai: 'تنہائی', yaad: 'یاد', aankhein: 'آنکھیں', chehra: 'چہرہ', baat: 'بات', waqt: 'وقت', umeed: 'امید', kitaab: 'کتاب',
    // brand / names
    dani: 'ڈانی', labs: 'لیبز', danilabs: 'ڈانی لیبز', urduofdani: 'اردو آف ڈانی', muhammad: 'محمد', danish: 'دانش'
  };
  const DIG = { sh: 'ش', kh: 'خ', gh: 'غ', ch: 'چ', zh: 'ژ', bh: 'بھ', ph: 'پھ', th: 'تھ', jh: 'جھ', dh: 'دھ', rh: 'ڑھ', chh: 'چھ', Th: 'ٹھ', Dh: 'ڈھ', Rh: 'ڑھ' };
  const CONS = { b: 'ب', c: 'ک', d: 'د', f: 'ف', g: 'گ', h: 'ہ', j: 'ج', k: 'ک', l: 'ل', m: 'م', n: 'ن', p: 'پ', q: 'ق', r: 'ر', s: 'س', t: 'ت', v: 'و', w: 'و', x: 'کس', y: 'ی', z: 'ز', T: 'ٹ', D: 'ڈ', R: 'ڑ', S: 'ص', Z: 'ظ', H: 'ح', N: 'ں', K: 'ک', G: 'غ', Q: 'ق' };
  const isV = c => 'aeiou'.includes(c);
  // Rule engine for words that are not in the dictionary (best effort).
  function ruleWord(w) {
    const n = w.length; let i = 0, out = '';
    while (i < n) {
      const c = w[i], lo = c.toLowerCase(), first = i === 0, last = i === n - 1;
      const t3 = w.slice(i, i + 3), t2 = w.slice(i, i + 2);
      if (DIG[t3]) { out += DIG[t3]; i += 3; continue; } if (DIG[t2]) { out += DIG[t2]; i += 2; continue; }
      if (isV(lo)) {
        const v2 = w.slice(i, i + 2).toLowerCase();
        if (v2 === 'aa') { out += first ? 'آ' : 'ا'; i += 2; if (i >= n && !first) { /* kept as ا */ } continue; }
        if (v2 === 'ee' || v2 === 'ii') { out += first ? 'ای' : 'ی'; i += 2; continue; }
        if (v2 === 'oo' || v2 === 'ou') { out += first ? 'او' : 'و'; i += 2; continue; }
        if (v2 === 'ai' || v2 === 'ay' || v2 === 'ae') { out += first ? 'ا' : ''; out += (i + 2 >= n) ? 'ے' : 'ی'; i += 2; continue; }
        if (first) { out += lo === 'o' ? 'او' : 'ا'; i++; continue; }
        if (last) { out += { a: 'ا', e: 'ے', i: 'ی', o: 'و', u: 'و' }[lo]; i++; continue; }
        out += { a: '', e: 'ی', i: '', o: 'و', u: '' }[lo]; i++; continue; // short vowels are not written inside a word
      }
      if (CONS[c] !== undefined || CONS[lo] !== undefined) { const prev = out[out.length - 1]; const ch = CONS[c] !== undefined ? CONS[c] : CONS[lo]; if (ch.length === 1 && prev === ch && (c === lo)) { i++; continue; } out += ch; i++; continue; } // doubled letters collapse
      out += c; i++;
    }
    return out;
  }
  const PUNCT = { ',': '،', '?': '؟', ';': '؛' };
  const DIGITS = '۰۱۲۳۴۵۶۷۸۹';
  function romanToUrdu(text, opts) {
    const o = Object.assign({ extra: {}, digits: true }, opts), dict = Object.assign({}, DICT, lowerKeys(o.extra));
    const camel = /^[A-Z][a-z]{2,}(?:[A-Z][a-z]{2,})+$/;
    return String(text).replace(/[A-Za-z']+/g, w => {
      const parts = camel.test(w) ? w.match(/[A-Z][a-z]+/g) : [w];
      return parts.map(p => { const k = p.toLowerCase().replace(/'/g, ''); return dict[k] !== undefined ? dict[k] : ruleWord(p.replace(/'/g, '')); }).join(' ');
    }).replace(/[,?;]/g, c => PUNCT[c]).replace(/(^|[^\d])\.(?=\s|$)/g, (m, a) => a + '۔').replace(/\d/g, d => o.digits ? DIGITS[+d] : d);
  }
  const lowerKeys = o => { const r = {}; for (const k of Object.keys(o || {})) r[k.toLowerCase()] = o[k]; return r; };

  // ---------------- Imla (spelling & typography clean-up) ----------------
  // Only unambiguous fixes are automatic. Letters that depend on meaning (ہ vs ح, ا vs ع…) cannot be guessed and are left alone.
  const WORDS = { 'اسلئے': 'اس لیے', 'اسلیئے': 'اس لیے', 'کیلئے': 'کے لیے', 'کیلیے': 'کے لیے', 'اسطرح': 'اس طرح', 'جسطرح': 'جس طرح', 'کسطرح': 'کس طرح', 'اسکا': 'اس کا', 'اسکی': 'اس کی', 'اسکے': 'اس کے', 'انکا': 'ان کا', 'انکی': 'ان کی', 'انکے': 'ان کے',
    'انشاءاللہ': 'ان شاء اللہ', 'انشاللہ': 'ان شاء اللہ', 'ماشاءاللہ': 'ماشاء اللہ', 'ماشاللہ': 'ماشاء اللہ', 'کیوںکہ': 'کیونکہ', 'نھیں': 'نہیں', 'اسکو': 'اس کو', 'انکو': 'ان کو' };
  const URDU = '؀-ۿ', MARK_ORDER = [0x651, 0x64E, 0x64F, 0x650, 0x64B, 0x64C, 0x64D, 0x652, 0x670, 0x653, 0x654, 0x655, 0x656, 0x657, 0x658];
  const isMark = c => (c >= 0x64B && c <= 0x65F) || c === 0x670;
  function normalizeMarks(s) { // one canonical order (shadda first) and no doubled marks, so the aerab sits correctly in every font
    return s.replace(/[ً-ٰٟ]{2,}/g, run => { const set = [...new Set([...run].map(c => c.codePointAt(0)))]; set.sort((a, b) => (MARK_ORDER.indexOf(a) + 99 * (MARK_ORDER.indexOf(a) < 0)) - (MARK_ORDER.indexOf(b) + 99 * (MARK_ORDER.indexOf(b) < 0))); return String.fromCodePoint(...set); });
  }
  function imla(text) {
    let s = String(text).normalize('NFC').replace(/​|﻿/g, '');
    s = s.replace(/ي|ى/g, 'ی').replace(/ك/g, 'ک').replace(/ه/g, 'ہ').replace(/ة/g, 'ۃ').replace(/ە/g, 'ہ'); // Arabic ي ى ك ه ة → Urdu ی ک ہ ۃ
    s = s.replace(/[٠-٩]/g, d => DIGITS[d.charCodeAt(0) - 0x660]);
    s = s.replace(new RegExp(`(^|[^${URDU}])\\u06BE(?=[${URDU}])`, 'g'), '$1ہ'); // a word never starts with ھ (do-chashmi he): ھم → ہم
    s = s.replace(new RegExp(`(^|[^${URDU}])(${Object.keys(WORDS).join('|')})(?![${URDU}])`, 'g'), (m, a, w) => a + WORDS[w]);
    s = normalizeMarks(s);
    // punctuation: Latin marks after Urdu text become Urdu marks; no space before, one space after
    s = s.replace(new RegExp(`([${URDU}])\\s*,`, 'g'), '$1،').replace(new RegExp(`([${URDU}])\\s*\\?`, 'g'), '$1؟').replace(new RegExp(`([${URDU}])\\s*;`, 'g'), '$1؛').replace(new RegExp(`([${URDU}\\u064B-\\u0652])\\s*\\.(?=\\s|$)`, 'g'), '$1۔');
    s = s.replace(/[ \t]+([۔،؟؛!:])/g, '$1').replace(/([۔،؟؛])(?=[^\s۔،؟؛"'»”)\]\n])/g, '$1 ').replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+$/gm, '');
    return s;
  }

  // ---------------- Prose / Book mode ----------------
  function prose(text) { // hard-wrapped lines → paragraphs (a blank line separates paragraphs), Urdu punctuation, closing ۔
    const paras = String(text).replace(/\r\n?/g, '\n').split(/\n\s*\n/).map(p => p.split('\n').map(l => l.trim()).filter(Boolean).join(' ')).filter(Boolean);
    return paras.map(p => { p = imla(p); const words = p.split(/\s+/).length; if (words >= 6 && new RegExp(`[${URDU}\\u064B-\\u0652]$`).test(p)) p += '۔'; return p; }).join('\n\n');
  }

  // ---------------- Poetry mode ----------------
  const SPLIT = /\t+|\s{3,}| [|｜] /;
  function poetryPairs(text) { // → [[misra1, misra2], …]; blank line = new poem (gap). A line holding both halves is split at tab / 3+ spaces / " | ".
    const out = []; let pend = null;
    for (const raw of String(text).replace(/\r\n?/g, '\n').split('\n')) {
      const line = raw.trim();
      if (!line) { if (pend !== null) { out.push([pend, '']); pend = null; } if (out.length && out[out.length - 1] !== null) out.push(null); continue; }
      const parts = line.split(SPLIT).map(x => x.trim()).filter(Boolean);
      if (parts.length >= 2) { if (pend !== null) { out.push([pend, '']); pend = null; } out.push([parts[0], parts.slice(1).join(' ')]); }
      else if (pend === null) pend = line; else { out.push([pend, line]); pend = null; }
    }
    if (pend !== null) out.push([pend, '']);
    while (out.length && out[out.length - 1] === null) out.pop();
    return out.map(p => p === null ? null : p.map(imla));
  }
  const poetryText = text => poetryPairs(text).map(p => p === null ? '' : p[1] ? p[0] + '\t' + p[1] : p[0]).join('\n');
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const poetryHtml = text => poetryPairs(text).map(p => p === null ? '<p><br></p>' : `<div class="sher"><div>${esc(p[0]) || '<br>'}</div><div>${esc(p[1]) || '<br>'}</div></div>`).join('');
  const proseHtml = text => text.split('\n\n').map(p => '<p>' + esc(p) + '</p>').join('');
  return { romanToUrdu, imla, prose, poetryPairs, poetryText, poetryHtml, proseHtml, normalizeMarks, DICT };
});
