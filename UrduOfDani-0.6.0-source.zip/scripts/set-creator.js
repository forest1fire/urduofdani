// usage: node scripts/set-creator.js "Full Name"  -> updates creator credit everywhere
const fs = require('fs'); const name = process.argv[2]; if (!name) { console.log('usage: node scripts/set-creator.js "Full Name"'); process.exit(1); }
const sub = (f, re, to) => { const t = fs.readFileSync(f, 'utf8'); fs.writeFileSync(f, t.replace(re, to)); };
sub('renderer/brand.js', /creator: '[^']*'/, `creator: '${name.replace(/'/g, "\\'")}'`);
sub('package.json', /"author": "[^"]*"/, `"author": "${name}, DaniLabs"`);
sub('package.json', /"copyright": "[^"]*"/, `"copyright": "Copyright © ${name} / DaniLabs"`);
sub('README.md', /^(by|Created by) .*$/m, `Created by ${name} · DaniLabs`);
console.log('Creator set to', name, '(review THIRD_PARTY_NOTICES.md and LICENSE manually)');
