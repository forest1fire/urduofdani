# Headless-Chromium benchmark of the real renderer (stubbed Electron API). Usage: python3 test/bench.py 10 100 500
import sys, json, pathlib, time
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
STUB = "window.api={open:async()=>null,save:async()=>null,exportTxt:async()=>null,exportPdf:async()=>null,previewPdf:async()=>null,autosave:async()=>true,recovery:async()=>null,clearRecovery:async()=>null,print:async()=>null};"
SENT = 'یہ ایک آزمائشی جملہ ہے جو اردو متن کی رفتار جانچنے کے لیے لکھا گیا ہے، with some English 123 mixed in۔ '
JS = """async ([pages, sent]) => {
  const para = '<p>' + sent.repeat(3) + '</p>';
  const html = para.repeat(pages * 5);                      // ~5 paragraphs per A4 page (calibrated: gives ~n real pages) at 18pt Nastaliq
  const t0 = performance.now(); loadDoc({html, page:{}}, null); const t1 = performance.now();
  const h = document.getElementById('sheet').scrollHeight;    // forces full layout
  const tLayout = performance.now() - t1;
  await new Promise(r => setTimeout(r, 400));
  const ed = document.getElementById('editor'); ed.focus();
  const ps = ed.querySelectorAll('p'); const mid = ps[Math.floor(ps.length / 2)]; mid.scrollIntoView(); await new Promise(r => setTimeout(r, 200)); const rg = document.createRange(); rg.setStart(mid.firstChild, 5); rg.collapse(true);
  const s = getSelection(); s.removeAllRanges(); s.addRange(rg);
  const lat = []; let sel_rect;
  for (let i = 0; i < 40; i++) { const a = performance.now(); document.execCommand('insertText', false, 'ا'); ed.getBoundingClientRect(); sel_rect = getSelection().getRangeAt(0).getBoundingClientRect(); lat.push(performance.now() - a); }
  lat.sort((x, y) => x - y);
  const roundTrip = getDoc().html.replace(/ا/g,'') .length > 0 && !/<section/.test(getDoc().html); const t2 = performance.now(); const out = ed.innerHTML.length; const tSer = performance.now() - t2;
  return { pages, loadDoc_ms: +(t1 - t0).toFixed(0), firstLayout_ms: +tLayout.toFixed(0), real_pages: Math.ceil(ed.offsetHeight / (1123 - 152)), type_median_ms: +lat[20].toFixed(1), type_p95_ms: +lat[37].toFixed(1), innerHTML_ms: +tSer.toFixed(1), save_has_no_chunks: roundTrip, dom_nodes: document.getElementsByTagName('*').length };
}"""
with sync_playwright() as p:
    b = p.chromium.launch()
    for n in [int(a) for a in sys.argv[1:]] or [10, 100]:
        pg = b.new_page(viewport={'width': 1280, 'height': 800}); pg.add_init_script(STUB)
        t = time.time(); pg.goto('file://' + str(ROOT / 'renderer' / 'index.html')); pg.wait_for_function('document.fonts.status==="loaded"'); startup = (time.time() - t) * 1000
        r = pg.evaluate(JS, [n, SENT]); r['cold_start_ms'] = round(startup); print(json.dumps(r, ensure_ascii=False)); pg.close()
    b.close()
