# Drives the REAL Electron app (main process + preload + renderer) through its debugging port. See README "Testing".
import base64, pathlib, sys, json
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent; FIX = ROOT / 'test' / 'fixtures'; OUT = pathlib.Path('/tmp/ft')
fails = []
def check(n, c, i=''):
    print(('PASS ' if c else 'FAIL ') + n + ('' if c else '  -> ' + str(i)))
    if not c: fails.append(n)
with sync_playwright() as p:
    b = p.chromium.connect_over_cdp('http://127.0.0.1:9333'); pg = [pg for c in b.contexts for pg in c.pages if 'index.html' in pg.url][0]; ev = pg.evaluate
    pg.wait_for_timeout(1500)
    check('opened the .udani passed on the command line (double-click / "open with")', ev("$('#editor').textContent") == 'کھلی ہوئی فائل' and ev("$('#docname').textContent") == 'udtest.udani', ev("$('#editor').textContent"))
    check('window is sandboxed + isolated (no node in renderer)', ev("typeof require === 'undefined' && typeof process === 'undefined' && typeof api.fontPick === 'function'"))
    b64 = base64.b64encode((FIX / 'DaniTest.ttf').read_bytes()).decode(); lat = base64.b64encode((FIX / 'Latin-only.ttf').read_bytes()).decode()
    ev("async ([a, l]) => { const mk = (n, s) => new File([Uint8Array.from(atob(s), c => c.charCodeAt(0))], n); await Fonts.installFiles([mk('DaniTest.ttf', a), mk('Latin-only.ttf', l)]); }", [b64, lat]); pg.wait_for_timeout(800)
    check('fonts installed through real IPC into userData', ev("Fonts.installed.length") == 2 and ev("document.fonts.check('16px \"Dani Test Font\"')"), ev("Fonts.installed.length"))
    check('installed fonts are files on disk', len(list(pathlib.Path('/tmp/udtest/fonts').glob('*.ttf'))) == 2 and pathlib.Path('/tmp/udtest/fonts/fonts.json').exists())
    ev("""() => { $('#editor').innerHTML = '<p>اردو متن</p>'; const r = document.createRange(); r.selectNodeContents($('#editor').firstChild); getSelection().removeAllRanges(); getSelection().addRange(r); applyFont('Dani Test Font'); }""")
    d = ev("async () => { const d = await getDocFull(); return [d.fonts.length, d.fonts[0].family]; }"); check('document embeds the used font', d == [1, 'Dani Test Font'], d)
    # real save + reopen via main process (atomic write, recent list, .udani v2)
    ev("async () => { await api.save({ path: '/tmp/udtest-out.udani', doc: await getDocFull() }); }"); raw = json.loads(pathlib.Path('/tmp/udtest-out.udani').read_text()); check('.udani written as version 2 with embedded font', raw['version'] == 2 and raw['fonts'][0]['family'] == 'Dani Test Font')
    check('recent list updated', '/tmp/udtest-out.udani' in ev("api.recent()"))
    r = ev("async () => { const r = await api.openPath('/tmp/udtest-out.udani'); return r && r.doc.fonts.length; }"); check('open from recent list works', r == 1, r)
    check('openPath refuses files not in the recent list', ev("api.openPath('/etc/hostname')") is None)
    # fonts removal frees disk
    ev("async () => { for (const f of Fonts.installed.slice()) await api.fontRemove(f.id); await Fonts.reload(); }"); check('remove deletes the font file', len(list(pathlib.Path('/tmp/udtest/fonts').glob('*.ttf'))) == 0)
    # bad font through IPC
    r = ev("async () => (await api.fontAddBytes({ name: 'bad.ttf', bytes: new Uint8Array(40) })).ok"); check('corrupt font rejected by main process', r is False)
    # bundled font IPC
    check('bundled font bytes available for HTML export', ev("async () => (await api.bundledFont('Noto Nastaliq Urdu')).length") > 100000 and ev("api.bundledFont('../../etc/passwd')") is None)
    # real Python plugin host through IPC
    st = ev("api.pluginStatus()"); check('plugin host finds Python', st['python'] is True, st)
    L = ev("api.pluginList()"); check('plugins folder was created in userData with the examples', L['ok'] and {'UrduPunctuationFixer', 'AerabRemover', 'TextStatistics', 'UrduHackNormalizer'} <= {p['cls'] for f in L['files'] for p in f['plugins']} and pathlib.Path('/tmp/udtest/plugins/urduofdani_plugin.py').exists(), L)
    r = ev("api.pluginRun({file:'urdu_punctuation_fixer.py', cls:'UrduPunctuationFixer', text:'اردو, کیا حال ہے?', context:{mode:'selection'}})"); check('real plugin run returns Unicode text', r == {'ok': True, 'text': 'اردو، کیا حال ہے؟'}, r)
    r = ev("api.pluginRun({file:'../../etc/passwd', cls:'X', text:'x'})"); check('plugin path traversal refused', r['ok'] is False)
    r = ev("api.pluginRun({file:'urdu_hack_normalizer.py', cls:'UrduHackNormalizer', text:'x'})"); check('optional Urdu Hack plugin reports a clear message when the library is missing (or runs when installed)', r['ok'] or 'pip install urduhack' in r['error'], r)
    # layouts + dictionary through the real main process
    L = ev("api.layoutList()"); check('layouts folder created with an editable example', any(l['file'] == 'phonetic-editable-example.json' and not l.get('error') and l['map']['a'] == 'ا' for l in L), L)
    pathlib.Path('/tmp/udtest/layouts/bad.json').write_text('{"name":"x","map":{"ab":"ا"}}'); L = ev("api.layoutList()"); check('invalid layout reported, not loaded', any(l['file'] == 'bad.json' and 'one character' in l.get('error', '') for l in L))
    ev("api.dictFolder()"); pathlib.Path('/tmp/udtest/dictionary/words.txt').write_text('کتاب\nپانی 12\n\n', encoding='utf-8'); d = ev("api.dictLoad()"); check('word list files are loaded (first token per line)', d['words'] == ['کتاب', 'پانی'] and d['files'] == 1, d)
    check('dictionary add appends to user-words.txt; rejects junk', ev("api.dictAdd('نیا')") is True and ev("api.dictAdd('two words')") is False and ev("api.dictAdd('x'.repeat(50))") is False and pathlib.Path('/tmp/udtest/dictionary/user-words.txt').read_text(encoding='utf-8').strip() == 'نیا')
    # real PDF + preview path (printToPDF via main)
    n = ev("async () => { const o = pdfOpts(); const t = performance.now(); try { await api.previewPdf(o); } catch (e) { return 'err ' + e.message; } return Math.round(performance.now() - t); }"); check('print preview (printToPDF) works in real Electron', isinstance(n, (int, float)), n)
    pg.screenshot(path=str(OUT / 'electron_main.png'))
    b.close()
print('\n%d failed' % len(fails) if fails else '\nELECTRON SMOKE PASSED'); sys.exit(1 if fails else 0)
