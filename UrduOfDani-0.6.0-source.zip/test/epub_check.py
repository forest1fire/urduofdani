# Structural validation of an EPUB produced by lib/epub.js (no epubcheck available offline): zip rules + well-formed XML + manifest/spine consistency.
import sys, zipfile, xml.etree.ElementTree as ET, posixpath
z = zipfile.ZipFile(sys.argv[1]); names = z.namelist(); bad = []
def need(c, m):
    if not c: bad.append(m)
need(names[0] == 'mimetype', 'mimetype must be first'); i0 = z.infolist()[0]; need(i0.compress_type == 0 and z.read('mimetype') == b'application/epub+zip', 'mimetype must be stored, exact')
need(z.testzip() is None, 'zip CRC errors')
cont = ET.fromstring(z.read('META-INF/container.xml')); ns = {'c': 'urn:oasis:names:tc:opendocument:xmlns:container'}; opf_path = cont.find('.//c:rootfile', ns).attrib['full-path']
opf = ET.fromstring(z.read(opf_path)); o = {'o': 'http://www.idpf.org/2007/opf', 'dc': 'http://purl.org/dc/elements/1.1/'}
base = posixpath.dirname(opf_path); man = {i.attrib['id']: i.attrib for i in opf.findall('.//o:manifest/o:item', o)}
for i in man.values(): need(posixpath.join(base, i['href']) in names, 'manifest item missing from zip: ' + i['href'])
for r in opf.findall('.//o:spine/o:itemref', o): need(r.attrib['idref'] in man, 'spine idref unknown')
need(opf.find('.//dc:title', o) is not None and opf.find('.//dc:language', o).text == 'ur', 'title/language')
need(opf.find('.//o:spine', o).attrib.get('page-progression-direction') == 'rtl', 'rtl spine')
need(any('nav' in i.get('properties', '') for i in man.values()), 'nav item')
for n in names:
    if n.endswith('.xhtml') or n.endswith('.opf') or n.endswith('.xml'):
        try: ET.fromstring(z.read(n))
        except Exception as e: bad.append('not well-formed XML: %s (%s)' % (n, e))
print('EPUB OK: %d files, %d chapters, %d fonts' % (len(names), sum(1 for n in names if '/text/c' in n), sum(1 for n in names if '/fonts/' in n)) if not bad else 'EPUB BAD: ' + '; '.join(bad)); sys.exit(1 if bad else 0)
