# PDF export benchmark: same Chromium print engine + options as main.js makePdf(). Usage: python3 test/pdfbench.py 10 100 500
import sys, json, pathlib, time, subprocess, re
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
STUB = "window.api={open:async()=>null,save:async()=>null,exportTxt:async()=>null,exportPdf:async()=>null,previewPdf:async()=>null,autosave:async()=>true,recovery:async()=>null,clearRecovery:async()=>null,print:async()=>null};"
SENT = 'یہ ایک آزمائشی جملہ ہے جو اردو متن کی رفتار جانچنے کے لیے لکھا گیا ہے، with some English 123 mixed in۔ '
FOOT = '<div dir="auto" style="font-size:9px;width:100%;text-align:center"><span class="pageNumber"></span> / <span class="totalPages"></span></div>'
with sync_playwright() as p:
    b = p.chromium.launch()
    for n in [int(a) for a in sys.argv[1:]] or [10, 100]:
        pg = b.new_page(viewport={'width': 1280, 'height': 800}); pg.add_init_script(STUB)
        pg.goto('file://' + str(ROOT / 'renderer' / 'index.html')); pg.wait_for_function('document.fonts.status==="loaded"')
        pg.evaluate("([n,s]) => { loadDoc({html:('<p>'+s.repeat(3)+'</p>').repeat(n*5), page:{}}, null); }", [n, SENT]); pg.wait_for_timeout(500)
        pg.evaluate("document.body.classList.add('pdfexport')")
        t = time.time()
        pg.pdf(path='/tmp/o.pdf', format='A4', print_background=True, prefer_css_page_size=True, display_header_footer=True,
               header_template='<div></div>', footer_template=FOOT)
        ms = (time.time() - t) * 1000
        info = subprocess.run(['pdfinfo', '/tmp/o.pdf'], capture_output=True, text=True).stdout
        pages = int(re.search(r'Pages:\s+(\d+)', info).group(1))
        bb = subprocess.run(['pdftotext','-f','2','-l','2','-bbox','/tmp/o.pdf','-'],capture_output=True,text=True).stdout; xs=[float(x) for x in re.findall(r'xMin="([0-9.]+)"',bb)]; xmin=round(min(xs),1) if xs else None
        txt = subprocess.run(['pdftotext', '-f', '1', '-l', '1', '/tmp/o.pdf', '-'], capture_output=True, text=True).stdout
        print(json.dumps({'doc_pages': n, 'pdf_ms': round(ms), 'pdf_pages': pages, 'pdf_MB': round(pathlib.Path('/tmp/o.pdf').stat().st_size / 1e6, 2),
                          'has_urdu_text_p1': bool(re.search('[\u0600-\u06FF]', txt)), 'xmin_pt': xmin, 'footer_p1': re.findall(r'\d+ / \d+', txt)[:1]}, ensure_ascii=False)); pg.close()
    b.close()
