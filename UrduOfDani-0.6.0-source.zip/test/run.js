const assert = require('assert'); const F = require('../lib/format'); const P = require('../lib/phonetic');
// round trip with mixed Urdu/English + diacritics
const html = '<p>اردو کا متن، with English 123 — زَبر زِیر</p><table><tr><td>۱</td></tr></table>';
const back = F.parse(F.serialize({ html, page: { size: 'A5', columns: 2 } }));
assert.strictEqual(back.html, html); assert.strictEqual(back.page.size, 'A5'); assert.strictEqual(back.page.margin, 20); assert.strictEqual(back.version, 1);
assert.throws(() => F.parse('{"format":"x"}')); assert.throws(() => F.parse(JSON.stringify({ format: 'urduofdani', version: 99 })));
assert.strictEqual(F.textToHtml('a<b\n\nج'), '<p>a&lt;b</p><p><br></p><p>ج</p>');
// every phonetic output is Urdu/Arabic-block, no stray Latin
for (const [k, v] of Object.entries(P.MAP)) assert(/^[\u0600-\u06FF]+$/.test(v), k + ' -> ' + v);
// perf: serialize/parse a ~500-page synthetic doc
const para = '<p>' + 'یہ ایک آزمائشی جملہ ہے جو اردو متن کی رفتار جانچنے کے لیے لکھا گیا ہے۔ '.repeat(8) + '</p>';
const big = para.repeat(500 * 20); let t = Date.now(); const s = F.serialize({ html: big }); F.parse(s);
console.log(`500-page synthetic round trip: ${(s.length / 1e6).toFixed(1)} MB in ${Date.now() - t} ms`); console.log('all tests passed');

const PDF = require('../lib/pdf'); const tp = PDF.templates({ header: '<b>عنوان</b><script>x</script>', footer: 'A & B', pageNumbers: true });
assert(tp.display && tp.footerTemplate.includes('pageNumber') && tp.footerTemplate.includes('A &amp; B') && !/<script|<b>/.test(tp.headerTemplate));
assert.strictEqual(PDF.templates({ header: '', footer: '', pageNumbers: false }).display, false); console.log('pdf template tests passed');
// chunk wrapper stripping must round-trip to the original paragraphs
const strip = html => html.replace(/<section class="chunk"[^>]*>/g, '').replace(/<\/section>/g, '');
assert.strictEqual(strip('<section class="chunk" style=""><p>أ</p><p>ب</p></section><section class="chunk"><p>ج</p></section>'), '<p>أ</p><p>ب</p><p>ج</p>'); console.log('chunk strip test passed');

// ---- v0.6: fonts, styles, smart keyboard, format v2 ----
(async () => {
  const fs = require('fs'), os = require('os'), path = require('path'), zlib = require('zlib');
  const FI = require('../lib/fontinfo'), FS = require('../lib/fontstore'), SC = require('../renderer/stylecss'), PH = require('../lib/phonetic');
  const inflate = async u => new Uint8Array(zlib.inflateSync(u));
  // font inspector
  const nas = await FI.inspect(FI.fromBytes(new Uint8Array(fs.readFileSync(path.join(__dirname, '../fonts/NotoNaskhArabic.ttf'))), { inflate }));
  assert.strictEqual(nas.family, 'Noto Naskh Arabic'); assert(nas.urdu.ok && nas.embeddable);
  const lat = await FI.inspect(FI.fromBytes(new Uint8Array(fs.readFileSync(path.join(__dirname, 'fixtures/Latin-only.ttf')))));
  assert.strictEqual(lat.urdu.ok, false); assert.strictEqual(lat.weight, 700);
  await assert.rejects(FI.inspect(FI.fromBytes(new Uint8Array(200))), /Not a TrueType/);
  await assert.rejects(FI.inspect(FI.fromBytes(Uint8Array.from([0x74, 0x74, 0x63, 0x66, 0, 0, 0, 0, 0, 0, 0, 0]))), /collections/);
  // font store: install, dedupe, reject, read back, remove
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'udfonts-')), st = FS.create(dir);
  const a = await st.addFile(path.join(__dirname, 'fixtures/DaniTest.ttf')); assert(!a.duplicate && a.entry.family === 'Dani Test Font' && a.entry.urdu.ok);
  assert((await st.addFile(path.join(__dirname, 'fixtures/DaniTest.ttf'))).duplicate);
  await assert.rejects(st.addBytes(Buffer.from('hello'), 'x.woff2'), /only .ttf/); await assert.rejects(st.addBytes(Buffer.alloc(100), 'x.ttf'), /Not a TrueType/);
  assert.strictEqual(st.list().length, 1); assert((await st.read(a.entry.id)).length > 1000);
  assert.strictEqual(FS.create(dir).list().length, 1, 'manifest survives restart'); assert(await st.remove(a.entry.id)); assert.strictEqual(st.list().length, 0); assert(!fs.existsSync(path.join(dir, a.entry.file)));
  // format v2: fonts embedded only when present; v1 otherwise
  const F2 = require('../lib/format'); const noF = JSON.parse(F2.serialize({ html: '<p>x</p>', styles: { s1: { name: 'A' } } })); assert.strictEqual(noF.version, 1); assert.strictEqual(noF.fonts, undefined);
  const withF = F2.parse(F2.serialize({ html: '<p>x</p>', fonts: [{ family: 'F', weight: 400, italic: false, ext: '.ttf', data: 'QUJD' }], styles: { s1: { name: 'A' } } })); assert.strictEqual(withF.version, 2); assert.strictEqual(withF.fonts[0].family, 'F'); assert.strictEqual(withF.styles.s1.name, 'A');
  assert.strictEqual(F2.parse(F2.serialize({ html: '' })).page.lineHeight, 1.8); assert.strictEqual(F2.parse('{"format":"urduofdani","version":1,"html":"","styles":5,"fonts":"x"}').fonts.length, 0);
  // style css: validated, no injection
  const css = SC.build({ a1: { name: 'N', font: 'Foo";}body{x:', size: 30, color: 'red', bold: true }, 'bad id': { size: 9 } }, ['#editor']);
  assert(css.includes('font-size:30pt') && css.includes('font-weight:700') && !css.includes('}body') && !css.includes('color:red') && !css.includes('bad id'));
  assert.strictEqual(SC.clean({ size: 99999, lh: -4 }).size, 400); assert.strictEqual(SC.clean({ align: 'evil' }).align, '');
  // smart keyboard
  const typ = (s, o) => { const e = PH.createSmart(o); let out = ''; for (const k of s) { if (k === ' ') { e.reset(); out += ' '; continue; } const r = e.feed(k); if (!r) { out += k; continue; } out = out.slice(0, out.length - r.del) + r.ins; } return out; };
  assert.strictEqual(typ('shukriya'), 'شُکرییا'); assert.strictEqual(typ('chhaata'), 'چھآتا'); assert.strictEqual(typ('kheer'), 'خیر'); assert.strictEqual(typ('bhai th Th'), 'بھای تھ ٹھ'); assert.strictEqual(typ('pH'), 'پھ');
  assert.strictEqual(typ('a1', { digits: 'latin' }), 'ا1'); assert.strictEqual(typ('a1'), 'ا۱'); assert.strictEqual(typ('s h'), 'س ہ', 'space breaks a digraph');
  for (const v of Object.values(PH.DIGRAPH)) assert(/^[؀-ۿ]+$/.test(v));
  assert(PH.MARKS.some(g => g.items.some(i => i.cp === 0xFDFA)));
  console.log('v0.6 tests passed');
})().catch(e => { console.error(e); process.exit(1); });

// ---- v0.6+: text engine, plugins, EPUB ----
(async () => {
  const fs = require('fs'), os = require('os'), path = require('path'), cp = require('child_process');
  const U = require('../renderer/urdutext'), EP = require('../lib/epub'), PL = require('../lib/plugins');
  // Roman -> Urdu (the example from the product brief) and rules
  assert.strictEqual(U.romanToUrdu('DaniLabs kamaal hai'), 'ڈانی لیبز کمال ہے');
  assert.strictEqual(U.romanToUrdu('Aap kaise hain? Main theek hoon, shukriya.'), 'آپ کیسے ہیں؟ میں ٹھیک ہوں، شکریہ۔');
  assert.strictEqual(U.romanToUrdu('kitaab 2026'), 'کتاب ۲۰۲۶'); assert.strictEqual(U.romanToUrdu('2026', { digits: false }), '2026'); assert.strictEqual(U.romanToUrdu('xyz', { extra: { xyz: 'ایکس' } }), 'ایکس');
  assert(/^[؀-ۿ\s]+$/.test(U.romanToUrdu('baRa ghar chai paani sher')), 'output stays inside the Arabic block');
  // Imla
  assert.strictEqual(U.imla('اسلئے ھم نے كيا ديكھا , انشاءاللہ ھے .'), 'اس لیے ہم نے کیا دیکھا، ان شاء اللہ ہے۔');
  assert.strictEqual(U.imla('بھائی'), 'بھائی', 'do-chashmi he inside a word is kept'); assert.strictEqual(U.imla('ہے   ۔'), 'ہے۔'); assert.strictEqual(U.imla('٠١٢'), '۰۱۲');
  assert.strictEqual(U.imla('بَّ'), 'بَّ', 'shadda is put before the vowel mark'); assert.strictEqual(U.imla('بََ'), 'بَ');
  assert.strictEqual(U.imla('hello, world.'), 'hello, world.', 'Latin text is not touched');
  // Prose, poetry
  assert.strictEqual(U.prose('یہ ایک بہت لمبا جملہ ہے جو\nدو لائنوں میں لکھا گیا ہے\n\nعنوان'), 'یہ ایک بہت لمبا جملہ ہے جو دو لائنوں میں لکھا گیا ہے۔\n\nعنوان');
  assert.strictEqual(U.poetryText('الف\nب\n\nج   د'), 'الف\tب\n\nج\tد'); assert.deepStrictEqual(U.poetryPairs('الف\nب\nج'), [['الف', 'ب'], ['ج', '']]);
  assert(U.poetryHtml('الف\nب').startsWith('<div class="sher"><div>الف</div><div>ب</div></div>')); assert(!U.poetryHtml('<b>\nx').includes('<b>'), 'html is escaped');
  // EPUB: zip + structure validated by an independent reader
  const buf = EP.build({ title: 'کتاب', author: 'Dani', css: 'p{margin:0}', fonts: [{ family: 'F', weight: 400, italic: false, ext: 'ttf', data: fs.readFileSync(path.join(__dirname, 'fixtures/DaniTest.ttf')).toString('base64') }], images: [{ name: 'img1.png', mime: 'image/png', data: 'iVBORw0KGgo=' }],
    chapters: [{ title: 'باب ایک', body: '<h1>باب ایک</h1><p>متن &amp; text<img src="../images/img1.png" alt=""/></p>' }, { title: 'باب دو', body: '<p>دوسرا</p>' }] });
  const ef = path.join(os.tmpdir(), 'ud-test.epub'); fs.writeFileSync(ef, buf); const r = cp.spawnSync('python3', [path.join(__dirname, 'epub_check.py'), ef], { encoding: 'utf8' }); assert.strictEqual(r.status, 0, r.stdout + r.stderr);
  assert.strictEqual(EP.crc32(Buffer.from('123456789')), 0xCBF43926, 'CRC-32 check value');
  // Python plugins (skipped if no Python): list, run, error isolation, timeout
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'udplug-')), host = PL.create(dir, path.join(__dirname, '../plugins'), { timeoutMs: 2500 });
  if (!host.status().python) { console.log('(python not found - plugin tests skipped)'); }
  else {
    const L = await host.list(); assert(L.ok); const names = L.files.flatMap(f => f.plugins.map(p => p.cls)); assert(names.includes('UrduPunctuationFixer') && names.includes('AerabRemover') && names.includes('TextStatistics'));
    let x = await host.run({ file: 'urdu_punctuation_fixer.py', cls: 'UrduPunctuationFixer', text: 'اردو, کیا حال ہے?', context: {} }); assert(x.ok && x.text === 'اردو، کیا حال ہے؟', JSON.stringify(x));
    x = await host.run({ file: 'aerab_remover.py', cls: 'AerabRemover', text: 'زَبَر', context: {} }); assert(x.ok && x.text === 'زبر');
    fs.writeFileSync(path.join(dir, 'bad.py'), 'class Bad(UrduOfDaniPlugin):\n    def execute(self, text, context=None):\n        raise ValueError("boom")\n');
    fs.writeFileSync(path.join(dir, 'hang.py'), 'import time\nclass Hang(UrduOfDaniPlugin):\n    def execute(self, text, context=None):\n        time.sleep(60)\n');
    fs.writeFileSync(path.join(dir, 'syntax.py'), 'class Oops(UrduOfDaniPlugin)\n    pass\n');
    fs.writeFileSync(path.join(dir, 'exit.py'), 'import sys\nclass Ex(UrduOfDaniPlugin):\n    def execute(self, text, context=None):\n        print("noise on stdout")\n        sys.exit(3)\n');
    fs.writeFileSync(path.join(dir, 'wrongtype.py'), 'class W(UrduOfDaniPlugin):\n    def execute(self, text, context=None):\n        return 42\n');
    x = await host.run({ file: 'bad.py', cls: 'Bad', text: 'x' }); assert(!x.ok && /boom/.test(x.error), JSON.stringify(x));
    x = await host.run({ file: 'exit.py', cls: 'Ex', text: 'x' }); assert(!x.ok, 'sys.exit inside a plugin is contained'); x = await host.run({ file: 'wrongtype.py', cls: 'W', text: 'x' }); assert(!x.ok && /str/.test(x.error));
    const t0 = Date.now(); x = await host.run({ file: 'hang.py', cls: 'Hang', text: 'x' }); assert(!x.ok && /longer than/.test(x.error) && Date.now() - t0 < 6000, JSON.stringify(x));
    const L2 = await host.list(); assert(L2.files.find(f => f.file === 'syntax.py').error, 'syntax error reported, other plugins still listed'); assert(L2.files.find(f => f.file === 'aerab_remover.py').plugins.length === 1);
    for (const bad of ['../x.py', '_runner.py', 'urduofdani_plugin.py', 'a/b.py', 'x.txt']) assert(!(await host.run({ file: bad, cls: 'A', text: 'x' })).ok, 'rejects ' + bad);
    assert(!(await host.run({ file: 'bad.py', cls: 'Bad; rm', text: 'x' })).ok);
  }
  // every file in the repo's plugins/examples follows the mandated template
  for (const f of fs.readdirSync(path.join(__dirname, '../plugins/examples'))) { const t = fs.readFileSync(path.join(__dirname, '../plugins/examples', f), 'utf8'); assert(/class \w+\(UrduOfDaniPlugin\):/.test(t) && /def __init__\(self\):/.test(t) && /self\.name =/.test(t) && /self\.version =/.test(t) && /self\.author =/.test(t) && /self\.description =/.test(t) && /def execute\(self, text: str, context=None\) -> str:/.test(t), f + ' follows the template'); }
  console.log('text engine / plugin / epub tests passed');
})().catch(e => { console.error(e); process.exit(1); });

// ---- layouts + spell core ----
(() => {
  const L = require('../lib/layouts'), S = require('../renderer/spell'), PHN = require('../renderer/phonetic'), fs = require('fs'), os = require('os'), path = require('path');
  assert.strictEqual(Object.keys(L.validate({ name: 'x', map: PHN.MAP }).map).length, Object.keys(PHN.MAP).length);
  for (const bad of [null, [], { name: 'x' }, { name: 'x', map: { ab: 'ا' } }, { name: 'x', map: { a: '<img>' } }, { name: 'x', map: { a: 'ابابابابا' } }, { name: '', map: { a: 'ا' } }, { name: 'x', map: {} }]) assert.throws(() => L.validate(bad));
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'udlay-')); L.ensureExample(d, PHN.MAP); fs.writeFileSync(path.join(d, 'broken.json'), '{nope'); fs.writeFileSync(path.join(d, 'big.json'), ' '.repeat(200000));
  const ls = L.list(d); assert(ls.find(x => x.file === 'phonetic-editable-example.json').map.a === 'ا' && ls.find(x => x.file === 'broken.json').error && ls.find(x => x.file === 'big.json').error);
  const set = S.build(['کتاب', 'پانی', 'ہے', 'یہ']);
  assert.deepStrictEqual(S.check(set, 'یہ کتاب ہے ۔ پانی، 123 ۱۲۳ hello کتبا').map(b => b.word), ['کتبا'], 'digits, Latin and punctuation are never flagged');
  assert(S.known(set, 'كِتاب') && S.known(set, 'کِتاب'), 'marks and Arabic-form letters do not matter'); assert.deepStrictEqual(S.suggest(set, 'کتبا'), ['کتاب']); assert.deepStrictEqual(S.suggest(set, 'کتاب'), []);
  assert.strictEqual(S.check(set, 'کتاب'.repeat(1)).length, 0);
  const big = S.build(Array.from({ length: 300000 }, (_, i) => 'ک' + i.toString(36))); let t = Date.now(); S.suggest(big, 'کتبا'); assert(Date.now() - t < 200, 'suggestions are fast even with a 300k list');
  console.log('layouts + spell tests passed');
})();
