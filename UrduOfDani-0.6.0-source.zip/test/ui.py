# Browser tests of the real renderer with an in-memory stand-in for the Electron API.  python3 test/ui.py  (needs playwright + chromium)
import sys, pathlib, json, base64
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent; FIX = ROOT / 'test' / 'fixtures'; OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/tmp/ft')
STUB = """
window.__calls = []; window.__fonts = []; window.__html = null;
const inflate = null;
window.api = {
  fontList: async () => window.__fonts.map(f => f.entry), fontData: async id => window.__fonts.find(f => f.entry.id === id).bytes,
  fontAddBytes: async ({name, bytes}) => { const u8 = new Uint8Array(bytes); const id = String(u8.length) + name.length;
    if (window.__fonts.some(f => f.entry.id === id)) return {ok:true, duplicate:true, entry: window.__fonts.find(f => f.entry.id === id).entry};
    try { const i = await FontInfo.inspect(FontInfo.fromBytes(u8)); const entry = {id, ext: '.' + name.split('.').pop(), family: i.family, style: i.style, weight: i.weight, italic: i.italic, embeddable: i.embeddable, urdu: i.urdu, size: u8.length};
      window.__fonts.push({entry, bytes: u8}); return {ok:true, duplicate:false, entry}; } catch (e) { return {ok:false, error: e.message}; } },
  fontRemove: async id => { window.__fonts = window.__fonts.filter(f => f.entry.id !== id); return true; },
  bundledFont: async n => Uint8Array.from(atob(window.__bundled[n]), c => c.charCodeAt(0)),
  recent: async () => ['C:\\\\docs\\\\a.udani'], startupFile: async () => null, recovery: async () => null, autosave: async () => true, clearRecovery: async () => null, onOpen: () => {},
  exportHtml: async h => { window.__html = h; return 'x.html'; }, save: async d => { window.__saved = d; return 'C:\\\\t.udani'; }, openPath: async () => null,
  pluginStatus: async () => ({python: true, version: 'Python 3.12', dir: 'x'}), pluginFolder: async () => '',
  pluginList: async () => ({ok: true, files: [{file: 'a.py', plugins: [{cls: 'A', name: 'Test Plugin', version: '1', author: 'tester', description: 'upper-cases'}], error: null}, {file: 'broken.py', plugins: [], error: 'SyntaxError: x'}]}),
  pluginRun: async r => { window.__pluginReq = r; return r.text.includes('FAIL') ? {ok: false, error: 'ValueError: boom'} : {ok: true, text: r.text.toUpperCase() + '!'}; },
  layoutList: async () => [{file: 'a.json', name: 'Test layout', description: 'd', map: {z: 'ژژ', Z: 'ذ'}}, {file: 'bad.json', error: 'key "ab" must be exactly one character'}], layoutFolder: async () => '',
  dictLoad: async () => ({words: ['کتاب', 'پانی', 'ہے', 'یہ', 'میں', ...Array.from({length: 1200}, (_, i) => 'لفظ' + String.fromCharCode(0x0621 + (i % 26)) + String.fromCharCode(0x0621 + ((i / 26) | 0) % 26) + String.fromCharCode(0x0621 + ((i / 676) | 0)))], files: 1, folder: 'x'}), dictAdd: async w => { (window.__added = window.__added || []).push(w); return true; }, dictFolder: async () => '',
  exportEpub: async o => { window.__epub = o; return 'x.epub'; },
  exportPdf: async () => null, previewPdf: async () => null, exportTxt: async () => null, print: async () => null, open: async () => null, fontPick: async () => []
};"""
fails = []
def check(name, cond, info=''):
    print(('PASS ' if cond else 'FAIL ') + name + (('  -> ' + str(info)) if (info != '' and not cond) else '')); 
    if not cond: fails.append(name)
with sync_playwright() as p:
    b = p.chromium.launch(args=['--allow-file-access-from-files']); ctx = b.new_context(viewport={'width': 1400, 'height': 900}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'inline event handler' not in m.text and 'ERR_FILE_NOT_FOUND' not in m.text and 'evil.example' not in m.text else None)  # those two come from the deliberate <img onerror> injection test (CSP blocks it = good)
    pg.add_init_script(STUB); pg.goto('file://' + str(ROOT / 'renderer' / 'index.html')); pg.wait_for_function('document.fonts.status==="loaded"'); pg.wait_for_timeout(500)
    ev = pg.evaluate
    ev('b => { window.__bundled = b; }', {n: base64.b64encode((ROOT / 'fonts' / f).read_bytes()).decode() for n, f in [('Noto Nastaliq Urdu', 'NotoNastaliqUrdu.ttf'), ('Noto Naskh Arabic', 'NotoNaskhArabic.ttf')]} if False else {n: base64.b64encode((ROOT / 'fonts' / f).read_bytes()).decode() for n, f in [('Noto Nastaliq Urdu', 'NotoNastaliqUrdu.ttf'), ('Noto Naskh Arabic', 'NotoNaskhArabic.ttf')]})
    check('findbar + on-screen keyboard hidden at start', ev("$('#findbar').offsetParent===null && $('#osk').offsetParent===null"))
    pg.wait_for_timeout(800); check('splash removed', ev("!document.getElementById('splash')"))
    # ---- fonts ----
    ev("""async (b64) => { const mk = (n, s) => new File([Uint8Array.from(atob(s), c => c.charCodeAt(0))], n); await Fonts.installFiles([mk('DaniTest.ttf', b64[0]), mk('Latin-only.ttf', b64[1])]); }""",
       [base64.b64encode((FIX / 'DaniTest.ttf').read_bytes()).decode(), base64.b64encode((FIX / 'Latin-only.ttf').read_bytes()).decode()])
    pg.wait_for_timeout(600)
    inst = ev("Fonts.installed.map(f => ({family: f.family, urdu: f.urdu.ok, emb: f.embeddable}))")
    check('two fonts installed', len(inst) == 2, inst)
    check('Urdu support detected (yes for Dani Test, no for DejaVu)', any(f['family'] == 'Dani Test Font' and f['urdu'] for f in inst) and any(f['family'] == 'DejaVu Serif' and not f['urdu'] for f in inst), inst)
    check('font picker lists installed fonts under My fonts', ev("[...document.querySelectorAll('#font optgroup[label=\"My fonts\"] option')].map(o=>o.value).includes('Dani Test Font')"))
    check('font face registered with the browser', ev("document.fonts.check('16px \"Dani Test Font\"')"))
    check('duplicate install is detected', ev("""async () => { const f = window.__fonts[0]; const r = await api.fontAddBytes({name: 'DaniTest.ttf', bytes: f.bytes}); return r.duplicate; }"""))
    r = ev("""async () => { const bad = await api.fontAddBytes({name:'x.ttf', bytes:new Uint8Array(50)}); return bad.ok; }"""); check('garbage font file rejected', r is False)
    # apply font to selected text
    ev("""() => { $('#editor').innerHTML = '<p>اردو متن</p><p>دوسرا</p>'; const r = document.createRange(); r.selectNodeContents($('#editor').firstChild); getSelection().removeAllRanges(); getSelection().addRange(r); }""")
    ev("applyFont('Dani Test Font')")
    check('font applied as inline style', ev("$('#editor').firstChild.innerHTML.includes('Dani Test Font')"), ev("$('#editor').innerHTML"))
    check('used families include custom font', ev("Fonts.usedFamilies().includes('Dani Test Font')"))
    d = ev("async () => { const d = await getDocFull(); return {n: d.fonts.length, fam: d.fonts[0] && d.fonts[0].family, len: d.fonts[0] && d.fonts[0].data.length}; }")
    check('save embeds only the used font (not unused DejaVu, not bundled Noto)', d['n'] == 1 and d['fam'] == 'Dani Test Font' and d['len'] > 1000, d)
    ev("state.page.embedFonts=false"); check('embed switch off -> nothing embedded', ev("async () => (await getDocFull()).fonts === undefined")); ev("state.page.embedFonts=true")
    # round trip in a "fresh machine": remove installed font, load doc carrying it
    doc = ev("async () => await getDocFull()")
    ev("async () => { window.__fonts = []; await Fonts.reload(); }")
    ev("async (d) => { loadDoc(d, null); await Fonts.loadSession(d.fonts); }", doc); pg.wait_for_timeout(300)
    check('embedded font works on a machine without it', ev("document.fonts.check('16px \"Dani Test Font\"') && Fonts.session.length === 1 && Fonts.missing().length === 0"), ev("Fonts.missing()"))
    check('missing font is reported when not embedded', ev("async () => { Fonts.loadSession([]); state.page.font='Nonexistent Fancy'; const m = Fonts.missing(); state.page.font=''; return m.includes('Nonexistent Fancy'); }"))
    # reinstall for later tests
    ev("""async (b64) => { await Fonts.installFiles([new File([Uint8Array.from(atob(b64), c => c.charCodeAt(0))], 'DaniTest.ttf')]); }""", base64.b64encode((FIX / 'DaniTest.ttf').read_bytes()).decode()); pg.wait_for_timeout(300)
    # font manager UI
    ev("A.fonts()"); pg.wait_for_timeout(300)
    check('font manager lists my font with Urdu badge', ev("document.querySelector('.fman').textContent.includes('Dani Test Font') && document.querySelector('.fman .bdg.ok') !== null"))
    pg.screenshot(path=str(OUT / 'ui_fonts.png')); pg.keyboard.press('Escape'); pg.wait_for_timeout(100)
    check('Esc closes dialog', ev("document.querySelectorAll('.mback').length===0"))
    # ---- styles ----
    ev("""() => { $('#editor').innerHTML = '<p>پہلا</p><p>دوسرا</p><p>تیسرا</p>'; const r = document.createRange(); r.setStart($('#editor').children[0].firstChild, 1); r.setEnd($('#editor').children[1].firstChild, 2); getSelection().removeAllRanges(); getSelection().addRange(r); }""")
    ev("A.styles()"); pg.wait_for_timeout(200)
    pg.click('.stools button:has-text("New")'); pg.fill('.sform label:first-child input', 'Headline'); pg.wait_for_timeout(100)
    pg.select_option('.sform select >> nth=0', 'Dani Test Font'); pg.fill('.sform input[type=number] >> nth=0', '30'); pg.wait_for_timeout(100)
    pg.screenshot(path=str(OUT / 'ui_styles.png'))
    pg.click('button:has-text("Apply to selection")'); pg.wait_for_timeout(200)
    sid = ev("Object.keys(state.styles)[0]")
    check('style created and saved in state', ev("Object.values(state.styles)[0].name") == 'Headline' and ev("Object.values(state.styles)[0].size") == 30)
    check('style applied to both selected paragraphs only', ev("[...$('#editor').children].map(c => c.className)") == ['ps-' + sid, 'ps-' + sid, ''], ev("$('#editor').innerHTML"))
    fs = ev("[...$('#editor').children].map(c => getComputedStyle(c).fontSize)")
    check('style size applies (30pt = 40px)', fs[0] == '40px' and fs[1] == '40px' and fs[2] == '24px', fs)
    ev("state.styles[Object.keys(state.styles)[0]].size = 40; Styles.apply()")
    check('editing the style updates every paragraph', ev("getComputedStyle($('#editor').children[1]).fontSize") == '53.3333px')
    check('style appears in paragraph-style list', ev("[...$('#pstyle').options].some(o => o.textContent === 'Headline')"))
    check('caret in styled paragraph shows its style in the list', (ev("(() => { const r = document.createRange(); r.setStart($('#editor').children[0].firstChild, 1); r.collapse(true); getSelection().removeAllRanges(); getSelection().addRange(r); return 1; })()"), pg.wait_for_timeout(150), ev("$('#pstyle').value"))[2] == 'ps:' + sid)
    ev("Styles.applyTo('p')"); check('Normal removes the custom style', ev("$('#editor').children[0].className") == '', ev("$('#editor').innerHTML"))
    sdoc = ev("async () => JSON.stringify(await getDocFull())"); check('styles are written to the document', '"Headline"' in sdoc)
    ev("async (s) => { const d = JSON.parse(s); loadDoc(d, null); }", sdoc); check('styles restored when the document is reopened', ev("Object.values(state.styles)[0].name") == 'Headline' and ev("[...$('#pstyle').options].some(o => o.textContent === 'Headline')"))
    # ---- sher ----
    ev("""() => { $('#editor').innerHTML = '<p>لائن ایک</p><p>لائن دو</p><p>لائن تین</p><p>لائن چار</p><p>باقی</p>'; const e = $('#editor'); const r = document.createRange(); r.setStart(e.children[0].firstChild, 0); r.setEnd(e.children[3].firstChild, 3); getSelection().removeAllRanges(); getSelection().addRange(r); }""")
    ev("A.sher()")
    h = ev("$('#editor').innerHTML"); n = ev("document.querySelectorAll('#editor .sher').length")
    check('4 selected lines become 2 couplets, other text untouched', n == 2 and 'باقی' in h and h.count('<div class="sher">') == 2, h)
    print(ev("$('#editor').innerHTML")); check('couplet halves hold the right lines', ev("[...document.querySelectorAll('#editor .sher')].map(s => [...s.children].map(c => c.textContent.trim()))") == [['لائن ایک', 'لائن دو'], ['لائن تین', 'لائن چار']])
    check('couplet halves sit side by side', ev("(() => { const a = document.querySelector('#editor .sher').children; const x = a[0].getBoundingClientRect(), y = a[1].getBoundingClientRect(); return Math.abs(x.top - y.top) < 8 && x.left !== y.left; })()"))
    ev("$('#editor').innerHTML = '<p><br></p>'; $('#editor').focus()"); ev("A.sher()"); check('insert empty couplet with placeholder text selected', ev("document.querySelectorAll('#editor .sher').length") == 1 and ev("getSelection().toString().trim()") == 'مصرع اول', ev("getSelection().toString()"))
    pg.screenshot(path=str(OUT / 'ui_sher.png'))
    # ---- smart keyboard (real key events) ----
    ev("$('#editor').innerHTML = '<p><br></p>'; $('#editor').focus(); const s=$('#kb'); s.value='smart'; s.onchange({target:s})")
    pg.keyboard.type('shukriya'); t = ev("$('#editor').textContent"); check('smart keyboard: shukriya', t == 'شُکرییا', t)
    pg.keyboard.press('Space'); pg.keyboard.type('chhaata kheer bhai'); t = ev("$('#editor').textContent"); check('smart keyboard digraphs (chh, aa, kh, ee, bh)', t.endswith('چھآتا خیر بھای') if hasattr(t, 'endswith') else t.endswith('چھآتا خیر بھای'), t)
    ev("document.execCommand('undo')"); 
    ev("$('#editor').innerHTML = '<p><br></p>'; $('#editor').focus(); state.digits='latin'; resetSmart()"); pg.keyboard.type('a1'); t = ev("$('#editor').textContent"); check('digits switch: Western digit kept', t == 'ا1', t)
    ev("state.digits='urdu'; resetSmart(); $('#editor').innerHTML = '<p><br></p>'; $('#editor').focus()"); pg.keyboard.type('a1'); t = ev("$('#editor').textContent"); check('digits switch: Urdu digit', t == 'ا۱', t)
    ev("const s=$('#kb'); s.value='off'; s.onchange({target:s}); $('#editor').innerHTML = '<p><br></p>'"); ev("$('#editor').focus()"); pg.keyboard.type('sh'); check('keyboard off = normal typing', ev("$('#editor').textContent") == 'sh')
    # ---- symbols panel ----
    ev("A.osk()"); pg.click('#osk .otabs button:has-text("Marks")'); pg.wait_for_timeout(100)
    check('symbols panel shows honorific marks', ev("[...document.querySelectorAll('#osk [data-ins]')].some(b => b.dataset.ins === '\\ufdfa')"))
    ev("$('#editor').innerHTML = '<p><br></p>'; $('#editor').focus()"); pg.click('#osk [data-ins="\ufdfa"]'); check('clicking a symbol inserts it at the cursor', ev("$('#editor').textContent") == '\ufdfa', ev("$('#editor').textContent"))
    pg.screenshot(path=str(OUT / 'ui_symbols.png')); ev("A.osk()")
    # ---- table dialog (window.prompt does not exist in Electron) ----
    ev("$('#editor').innerHTML = '<p><br></p>'; $('#editor').focus()"); ev("A.table(); 0"); pg.wait_for_timeout(100)
    pg.fill('.mform label:nth-child(1) input', '2'); pg.fill('.mform label:nth-child(2) input', '4'); pg.click('.mbtns button:has-text("Insert")'); pg.wait_for_timeout(150)
    check('table dialog inserts 2x4 table', ev("[document.querySelectorAll('#editor tr').length, document.querySelectorAll('#editor td').length]") == [4, 8], ev("$('#editor').innerHTML"))
    # ---- colours ----
    ev("""() => { $('#editor').innerHTML = '<p>رنگ</p>'; const r = document.createRange(); r.selectNodeContents($('#editor').firstChild); getSelection().removeAllRanges(); getSelection().addRange(r); }""")
    ev("const c=$('#fcolor'); c.value='#0000ff'; c.dispatchEvent(new Event('change'))"); check('text colour applied', 'rgb(0, 0, 255)' in ev("$('#editor').innerHTML") or '#0000ff' in ev("$('#editor').innerHTML"), ev("$('#editor').innerHTML"))
    # ---- command palette ----
    pg.keyboard.press('Escape'); ev("$('#editor').focus()"); pg.keyboard.press('Control+k'); pg.wait_for_timeout(150)
    check('Ctrl+K opens palette', ev("!!document.querySelector('.pal input')")); pg.keyboard.type('page size a3'); pg.screenshot(path=str(OUT / 'ui_palette.png')); pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
    check('palette command changes page size', ev("state.page.size") == 'A3' and ev("$('#psize').value") == 'A3', ev("state.page.size"))
    ev("() => { const r = document.createRange(); r.selectNodeContents($('#editor').firstChild); getSelection().removeAllRanges(); getSelection().addRange(r); }"); pg.keyboard.press('Control+k'); pg.wait_for_timeout(100); pg.keyboard.type('font dani'); pg.keyboard.press('Enter'); pg.wait_for_timeout(200)
    check('palette lists installed fonts', ev("$('#editor').innerHTML").count('Dani Test Font') >= 1, ev("$('#editor').innerHTML"))
    # ---- focus mode ----
    ev("A.focus()"); check('focus mode hides toolbars', ev("$('#top').offsetParent === null && !$('#unfocus').hidden")); pg.keyboard.press('Escape'); check('Esc leaves focus mode', ev("$('#top').offsetParent !== null"))
    # ---- recent ----
    ev("$('#recent').dispatchEvent(new Event('mousedown'))"); pg.wait_for_timeout(100); check('recent list populated', ev("[...$('#recent').options].some(o => o.text === 'a.udani')"))
    # ---- html export ----
    ev("""() => { $('#editor').innerHTML = '<p>ہیلو<script>alert(1)</script><img src=x onerror="alert(2)"><a href="javascript:alert(3)">x</a></p>'; state.page.font = 'Dani Test Font'; }""")
    ev("async () => { await A.html(); }"); html = ev("window.__html")
    check('HTML export produced a page', html and html.startswith('<!doctype html>'))
    check('HTML export embeds the font the document uses', html.count('@font-face') == 1 and 'Dani Test Font' in html, [html.count('@font-face'), 'Dani Test Font' in html, 'Noto Nastaliq Urdu' in html, (html or '')[:300]])
    check('HTML export strips scripts/handlers/javascript: links', '<script>alert' not in html and 'onerror' not in html and 'javascript:' not in html)
    ev("state.page.font = ''"); ev("async () => { await A.html(); }"); h2 = ev("window.__html"); check('HTML export embeds the bundled Urdu font when it is the default', 'font-family:"Noto Nastaliq Urdu";src' in h2, h2.count('@font-face'))
    # ---- defaults persisted (line spacing used to be lost on save) ----
    ev("$('#lh').value='2.2'; $('#lh').onchange({target:$('#lh')})"); sv = ev("async () => (await getDocFull()).page.lineHeight"); check('line spacing is saved in the document', sv == 2.2, sv)
    ev("loadDoc({html:'<p>x</p>', page:{}, styles:{}}, null)"); check('New document does not inherit previous font/line settings', ev("state.page.font") == '' and ev("state.page.lineHeight") == 1.8)
    # ---- text tools dialog ----
    ev("""() => { const e = $('#editor'); e.innerHTML = '<p>DaniLabs kamaal hai</p><p>baqi</p>'; e.focus(); const r = document.createRange(); r.selectNodeContents(e.firstChild); getSelection().removeAllRanges(); getSelection().addRange(r); }""")
    ev("A.texttools(); 0"); pg.wait_for_timeout(200)
    check('text tools: selection is pre-filled and converted live', ev("document.querySelector('.ttools textarea').value") == 'DaniLabs kamaal hai' and ev("document.querySelector('.ttout').value") == 'ڈانی لیبز کمال ہے', ev("document.querySelector('.ttout').value"))
    pg.screenshot(path=str(OUT / 'ui_texttools.png')); pg.click('.mbtns button:has-text("Apply to document")'); pg.wait_for_timeout(250)
    check('Apply replaces only the selected paragraph', ev("[...$('#editor').children].map(c => c.textContent)") == ['ڈانی لیبز کمال ہے', 'baqi'], ev("$('#editor').innerHTML"))
    ev("""() => { const e = $('#editor'); e.innerHTML = '<p>پہلا مصرع</p><p>دوسرا مصرع</p>'; e.focus(); const r = document.createRange(); r.setStart(e.firstChild, 0); r.setEnd(e.lastChild, e.lastChild.childNodes.length); getSelection().removeAllRanges(); getSelection().addRange(r); }""")
    ev("A.texttools(); 0"); pg.wait_for_timeout(150); pg.select_option('.ttools select', 'sher'); pg.wait_for_timeout(100); pg.click('.mbtns button:has-text("Apply to document")'); pg.wait_for_timeout(250)
    check('poetry tool turns two lines into one couplet block', ev("document.querySelectorAll('#editor .sher').length") == 1 and ev("[...document.querySelector('#editor .sher').children].map(c => c.textContent)") == ['پہلا مصرع', 'دوسرا مصرع'], ev("$('#editor').innerHTML"))
    ev("$('#editor').innerHTML = '<p>اسلئے ھم, جی .</p><p>ایک</p>'"); ev("savedRange = null; A.texttools(); 0"); pg.wait_for_timeout(150); pg.select_option('.ttools select', 'imla'); pg.wait_for_timeout(100)
    check('whole-document mode when nothing is selected', ev("document.querySelector('.ttools input[type=checkbox]').checked") is True and 'اس لیے ہم' in ev("document.querySelector('.ttout').value"), ev("document.querySelector('.ttout').value"))
    pg.click('.mbtns button:has-text("Apply to document")'); pg.wait_for_timeout(250); check('imla applied to the whole document', ev("$('#editor').textContent").startswith('اس لیے ہم، جی۔'), ev("$('#editor').textContent"))
    # ---- plugins dialog ----
    ev("""() => { const e = $('#editor'); e.innerHTML = '<p>abc</p>'; e.focus(); const r = document.createRange(); r.selectNodeContents(e.firstChild); getSelection().removeAllRanges(); getSelection().addRange(r); }""")
    ev("A.plugins(); 0"); pg.wait_for_timeout(300)
    check('plugins dialog lists plugins and shows load errors', 'Test Plugin' in ev("document.querySelector('.plug').textContent") and 'SyntaxError' in ev("document.querySelector('.plug').textContent") and 'upper-cases' in ev("document.querySelector('.plug').textContent"))
    pg.screenshot(path=str(OUT / 'ui_plugins.png')); pg.click('button:has-text("Run on selection")'); pg.wait_for_timeout(400)
    check('plugin result replaces the selection', ev("$('#editor').textContent") == 'ABC!' and ev("window.__pluginReq.cls") == 'A' and ev("window.__pluginReq.context.mode") == 'selection' and ev("window.__pluginReq.context.app") == 'UrduOfDani', ev("$('#editor').textContent"))
    ev("""() => { $('#editor').innerHTML = '<p>FAIL me</p>'; const e = $('#editor'); e.focus(); const r = document.createRange(); r.selectNodeContents(e.firstChild); getSelection().removeAllRanges(); getSelection().addRange(r); }""")
    ev("A.plugins(); 0"); pg.wait_for_timeout(300); pg.click('button:has-text("Run on selection")'); pg.wait_for_timeout(300)
    check('a failing plugin leaves the document untouched and shows the error', ev("$('#editor').textContent") == 'FAIL me' and 'boom' in ev("document.querySelector('.plug').textContent"), ev("$('#editor').textContent")); pg.keyboard.press('Escape')
    # ---- EPUB payload ----
    ev("""() => { $('#editor').innerHTML = '<h1>باب ایک</h1><p>متن &amp; <b>bold</b><br>x</p><hr><h1>باب دو</h1><p>دوسرا<img src="data:image/png;base64,iVBORw0KGgo="></p><div class="sher"><div>الف</div><div>ب</div></div><p><img src="http://evil.example/x.png"></p>'; }""")
    ev("A.epub(); 0"); pg.wait_for_timeout(150); pg.click('.mbtns button:has-text("Export")'); pg.wait_for_timeout(500)
    e = ev("window.__epub"); check('EPUB payload: two chapters split at headings', e and [c['title'] for c in e['chapters']] == ['باب ایک', 'باب دو'], e and [c['title'] for c in e['chapters']])
    check('EPUB: image extracted to a file, remote image dropped', e and len(e['images']) == 1 and 'images/img1.png' in e['chapters'][1]['body'] and 'evil.example' not in json.dumps(e), e and e['images'])
    bad = ev("""(c) => c.map(x => { const d = new DOMParser().parseFromString('<root xmlns="http://www.w3.org/1999/xhtml">' + x.body + '</root>', 'application/xml'); return d.querySelector('parsererror') ? 'BAD' : 'ok'; })""", e['chapters'])
    check('EPUB chapters are well-formed XHTML', bad == ['ok', 'ok'], bad); check('EPUB embeds the Urdu font and metadata', e['fonts'] and e['fonts'][0]['family'] == 'Noto Nastaliq Urdu' and e['lang'] == 'ur' and e['title'] and e['author'] == 'Muhammad Danish [Dani]', (e['title'], e['author']))
    check('credit shown in the brand', ev("BRAND.creator") == 'Muhammad Danish [Dani]' and ev("BRAND.studio") == 'DaniLabs')
    # ---- custom keyboard layouts ----
    check('layouts: valid file appears in the keyboard menu', ev("[...$('#kb').options].some(o => o.value === 'layout:a.json')"))
    ev("const s=$('#kb'); s.value='layout:a.json'; s.onchange({target:s}); $('#editor').innerHTML='<p><br></p>'; $('#editor').focus()"); pg.keyboard.type('zZ?'); t = ev("$('#editor').textContent")
    check('layouts: typing uses the mapped text; unmapped keys type normally', t == 'ژژذ?', t)
    ev("A.layouts(); 0"); pg.wait_for_timeout(300); check('layouts dialog shows the error of an invalid file', 'exactly one character' in ev("document.querySelector('.fman').textContent")); pg.keyboard.press('Escape')
    ev("const s=$('#kb'); s.value='off'; s.onchange({target:s})")
    # ---- spell-check ----
    ev("$('#editor').innerHTML = '<p>یہ کتاب پانی ہے کتبا</p>'; $('#editor').blur()"); ev("A.spell(); 0"); pg.wait_for_timeout(900)
    n = ev("CSS.highlights.get('ud-misspelled') ? CSS.highlights.get('ud-misspelled').size : -1"); check('spell-check underlines exactly the unknown word', n == 1 and 'کتبا' == ev("[...CSS.highlights.get('ud-misspelled')][0].toString()"), n)
    check('status bar counts unknown words', '1 unknown' in ev("$('#st-spell').textContent"), ev("$('#st-spell').textContent"))
    pos = ev("(() => { const r = [...CSS.highlights.get('ud-misspelled')][0].getBoundingClientRect(); return [r.x + r.width / 2, r.y + r.height / 2]; })()"); pg.mouse.click(pos[0], pos[1], button='right'); pg.wait_for_timeout(200)
    check('right-click shows suggestion + add + ignore', ev("!!document.querySelector('.ctxmenu')") and ev("document.querySelector('.ctxmenu .sug').textContent") == 'کتاب' and 'dictionary' in ev("document.querySelector('.ctxmenu').textContent"), ev("document.querySelector('.ctxmenu') && document.querySelector('.ctxmenu').textContent"))
    pg.screenshot(path=str(OUT / 'ui_spell.png')); pg.dispatch_event('.ctxmenu .sug', 'mousedown'); pg.wait_for_timeout(900)
    check('choosing a suggestion fixes the word and clears the underline', ev("$('#editor').textContent") == 'یہ کتاب پانی ہے کتاب' and ev("CSS.highlights.get('ud-misspelled').size") == 0, ev("$('#editor').textContent"))
    ev("$('#editor').innerHTML = '<p>پانی نیالفظ</p>'"); ev("$('#editor').dispatchEvent(new Event('input'))"); pg.wait_for_timeout(900)
    pos = ev("(() => { const r = [...CSS.highlights.get('ud-misspelled')][0].getBoundingClientRect(); return [r.x + r.width / 2, r.y + r.height / 2]; })()"); pg.mouse.click(pos[0], pos[1], button='right'); pg.wait_for_timeout(150)
    pg.dispatch_event('.ctxmenu .pitem:has-text("add to my dictionary")', 'mousedown'); pg.wait_for_timeout(900)
    check('adding a word saves it and removes the underline', ev("window.__added") == ['نیاlفظ'.replace('l', 'ل')] and ev("CSS.highlights.get('ud-misspelled').size") == 0, ev("window.__added"))
    ev("A.spell(); 0"); check('spell-check can be turned off', ev("CSS.highlights.has('ud-misspelled')") is False and ev("$('#st-spell').textContent") == '')
    check('no console / page errors during the whole run', not errs, errs)
    b.close()
print('\n%d failed' % len(fails) if fails else '\nALL UI TESTS PASSED'); sys.exit(1 if fails else 0)
